<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "camping";

// اتصال به پایگاه‌داده
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// بررسی لاگین بودن
if (!isset($_SESSION['id'])) {
    header('location: index.php');
    exit;
}

// گرفتن id منطقه برای ویرایش
if (isset($_GET['id'])) {
    $edit_id = intval($_GET['id']);
    $sql = "SELECT * FROM forest_areas WHERE id = $edit_id";
    $result = $conn->query($sql);
    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        $forest_id = $row['forest_id'];  // دریافت forest_id از جدول forest_areas
    } else {
        echo "منطقه مورد نظر یافت نشد.";
        exit;
    }

    // دریافت اطلاعات location و name از جدول forests با استفاده از forest_id
    $sql_forest = "SELECT location, name FROM forests WHERE id = $forest_id";
    $result_forest = $conn->query($sql_forest);
    if ($result_forest->num_rows == 1) {
        $forest_row = $result_forest->fetch_assoc();
        $location = $forest_row['location'];  // دریافت location از جدول forests
        $forest_name = $forest_row['name'];  // دریافت name از جدول forests
    } else {
        echo "جنگل مربوطه یافت نشد.";
        exit;
    }

} else {
    echo "هیچ منطقه ای برای ویرایش انتخاب نشده است.";
    exit;
}

// ذخیره تغییرات
if (isset($_POST["editsubmit"])) {
    $forest_id = $_POST["forest_id"];
    $area_name = $_POST["area_name"];
    $price = $_POST["price"];
    $description = $_POST["description"];
    $location = $_POST["location"];
    $name = $_POST["forest_name"];  // دریافت نام جنگل از فرم

    $sql = "UPDATE forest_areas SET forest_id='$forest_id', area_name='$area_name', price='$price', description='$description', location='$location' WHERE id = $edit_id";
    $conn->query($sql);
    header('location: Account.admin.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <title>کمپینگ</title>
    <link rel="stylesheet" href="Account.css">
    <link rel="icon" type="img/download.jpg" sizes="192x192" href="img/camping_1f3d5 1.png">
</head>
<body>
<form method="post">
    <div class="row pl-5 pr-5 mt-5">
        <div class="col-md-12">
            <div class="cr-abie">
                <div class="inner-box">
                    <div class="row">
                        <div class="col-md-10 text-center" style="padding-right: 200px;">
                            <h4>اطلاعات شخصی</h4>
                        </div>
                        <div class="col-md-2">
                            <div class="action-btns">
                                <button class="edit">
                                    <i class="fas fa-edit"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                    <img src="img/Line long.png" width="100%" height="100%" alt="">

                    <div class="col-md-12">
                        <div class="row text-right mt-4">
                            <div class="col-md-2">نام جنگل:</div>
                            <div class="col-md-2"><input type="text" name="forest_name" id="forest_name" class="form-control" value="<?php echo $forest_name; ?>"></div> <!-- نمایش نام جنگل -->
                            <div class="col-md-2">منطقه:</div>
                            <div class="col-md-2"><input type="text" name="area_name" id="area_name" class="form-control" value="<?php echo $row['area_name']; ?>"></div>
                            <div class="col-md-2">قیمت:</div>
                            <div class="col-md-2"><input type="phone" name="price" id="price" class="form-control" value="<?php echo $row['price']; ?>"></div>
                        </div>
                        <div class="row text-right mt-5">
                            <div class="col-md-2">توضیحات:</div>
                            <div class="col-md-2"><input type="text" name="description" id="description" class="form-control" value="<?php echo $row["description"]; ?>"></div>
                            <div class="col-md-3"></div>
                            <div class="col-md-2">شهر:</div>
                            <div class="col-md-2"><input type="text" name="location" id="location" class="form-control" value="<?php echo $location; ?>"></div>
                        </div>

                        <div class="col-md-12">
                            <input type="submit" class="btn btn-warning" value="ذخیره تغیرات" id="editsubmit" name="editsubmit">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>
</body>
</html>
