<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "camping";

// اتصال به پایگاه‌داده
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// بررسی لاگین بودن
if (!isset($_SESSION['id'])) {
    header('location: index.php');
    exit;
}

// گرفتن id رزرو
if (isset($_GET['id'])) {
    $edit_id = intval($_GET['id']);

    // کوئری با JOIN برای گرفتن اطلاعات کامل
    $sql = "SELECT r.*, u.name AS user_name, f.name AS forest_name
            FROM reservations r
            JOIN users u ON r.user_id = u.id
            JOIN forests f ON r.forest_area_id = f.id
            WHERE r.id = $edit_id";

    $result = $conn->query($sql);
    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
    } else {
        echo "رزرو مورد نظر یافت نشد.";
        exit;
    }
} else {
    echo "هیچ رزروی برای ویرایش انتخاب نشده است.";
    exit;
}

// ذخیره تغییرات
if (isset($_POST["editsubmit"])) {
    $user_id = $_POST["user_id"];
    $forest_area_id = $_POST["forest_area_id"];
    $start_date = $_POST["start_date"];
    $end_date = $_POST["end_date"];
    $nights = $_POST["nights"];
    $total_price = $_POST["total_price"];
    $discount_code = $_POST["discount_code"];
    $extras = $_POST["extras"];
    $Examination = $_POST["Examination"];

    $sql = "UPDATE reservations 
            SET user_id='$user_id', forest_area_id='$forest_area_id', start_date='$start_date', end_date='$end_date', 
                nights='$nights', total_price='$total_price', discount_code='$discount_code', extras='$extras', 
                Examination='$Examination'
            WHERE id = $edit_id";

    $conn->query($sql);
    header('location: Account.admin.php');
    exit;
}

// گرفتن لیست کاربران برای dropdown
$users_result = $conn->query("SELECT id, name FROM users");

// گرفتن لیست جنگل‌ها برای dropdown
$forests_result = $conn->query("SELECT id, name FROM forests");

?>





<!DOCTYPE html>
<html lang="en" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <!-- jQuery library -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>
    <!-- Popper JS -->
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>

    <title>کمپینگ</title>

    <link rel="stylesheet" href="Account.css">

    <!-- لوگو سایت -->
    <link rel="icon" type="img/download.jpg" sizes="192x192" href="img/camping_1f3d5 1.png">
</head>
<body>
<form method="post">
    <div class="row pl-5 pr-5 mt-5">
        <div class="col-md-12">
            <div class="cr-ger">
                <div class="inner-box">
                    <div class="row">
                        <div class="col-md-10 text-center" style="padding-right: 200px;">
                            <h4>رزرو ها</h4>
                        </div>
                        <div class="col-md-2">
                            <div class="action-btns">
                                <button class="edit">
                                    <i class="fas fa-edit"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                    <img src="img/Line long.png" width="100%" height="100%" alt="">
                    <div class="col-md-12">
                        <div class="row text-right mt-4">
                            <div class="col-md-2">نام و نام خانوادگی:</div>
                            <div class="col-md-2">
                                <select name="user_id" class="form-control">
                                    <?php while($user = $users_result->fetch_assoc()): ?>
                                        <option value="<?= $user['id']; ?>" <?= $user['id'] == $row['user_id'] ? 'selected' : ''; ?>>
                                            <?= htmlspecialchars($user['name']); ?>
                                        </option>
                                    <?php endwhile; ?>
                                </select>
                            </div>

                            <div class="col-md-2">نام جنگل:</div>
                            <div class="col-md-2">
                                <select name="forest_area_id" class="form-control">
                                    <?php while($forest = $forests_result->fetch_assoc()): ?>
                                        <option value="<?= $forest['id']; ?>" <?= $forest['id'] == $row['forest_area_id'] ? 'selected' : ''; ?>>
                                            <?= htmlspecialchars($forest['name']); ?>
                                        </option>
                                    <?php endwhile; ?>
                                </select>
                            </div>

                            <div class="col-md-2">مبلغ:</div>
                            <div class="col-md-2">
                                <input type="text" name="total_price" class="form-control" value="<?= $row['total_price']; ?>">
                            </div>
                        </div>


                        <div class="row text-right mt-5">
                            <div class="col-md-2">ازتاریخ:</div>
                            <div class="col-md-2"><input type="text" name="start_date" id="start_date" class="form-control" value="<?php echo $row["start_date"]; ?>"></div>
                            <div class="col-md-2">تاتاریخ:</div>
                            <div class="col-md-2"><input type="text" name="end_date" id="end_date" class="form-control" value="<?php echo $row["end_date"]; ?>"></div>
                            <div class="col-md-2">تعداد روز ها:</div>
                            <div class="col-md-1"><input type="phone" name="nights" id="nights" class="form-control" value="<?php echo $row['nights']; ?>"></div>
                        </div>
                        <div class="row text-right mt-5">
                            <div class="col-md-2">موارد اضافی:</div>
                                <input type="text" name="extras" id="extras" class="form-control" value="<?php echo $row["extras"]; ?>">
                        </div>
                        <div class="row text-right mt-5">
                        <div class="col-md-2">کد تخفیف استفاده شده:</div>
                        <div class="col-md-2"><input type="text" name="discount_code" id="discount_code" class="form-control" value="<?php echo $row['discount_code']; ?>"></div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="">قابلیت</label>
                                <select name="Examination" id="Examination" class="form-control">
                                    <option value="تایید شده" <?php if( $row["Examination"]=='تایید شده'){ echo "selected"; } ?> >تایید شده</option>
                                    <option value="درحال برسی..." <?php if( $row["Examination"]=='درحال برسی...'){ echo "selected"; } ?>>درحال برسی...</option>
                                    <option value="منقضی شده" <?php if( $row["Examination"]=='منقضی شده'){ echo "selected"; } ?>>منقضی شده</option>
                                </select>
                            </div>
                        </div>
                        </div>
                        <div class="col-md-12">
                            <input type="submit" class="btn btn-warning" value="ذخیره تغیرات" id="editsubmit" name="editsubmit">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>

</body>
</html>