<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>درباره ما</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Tahoma', sans-serif;
            margin: 0;
            padding: 0;
            background: #f5f5f5;
            direction: rtl; /* راست‌چین کردن صفحه */
            text-align: right; /* متن به سمت راست بچسبد */
        }

        .about-header {
            background: linear-gradient(120deg, #004d8b, #1e3c72);
            padding: 100px 0;
            color: #fff;
            text-align: center;
            border-bottom: 5px solid #003366;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            animation: fadeInHeader 1.5s ease-in-out;
        }

        .about-header h1 {
            font-size: 3.5em;
            margin-bottom: 20px;
            text-transform: uppercase;
            letter-spacing: 2px;
            text-shadow: 3px 3px 6px rgba(0, 0, 0, 0.3);
        }

        .about-header p {
            font-size: 1.3em;
            margin-bottom: 40px;
            font-weight: 300;
        }

        .about-content {
            padding: 60px 0;
        }

        .about-section {
            background-color: #fff;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            margin-bottom: 40px;
            animation: fadeInSection 2s ease-out;
        }

        .about-section h3 {
            font-size: 2.5em;
            margin-bottom: 20px;
            color: #003366;
        }

        .about-section p {
            font-size: 1.2em;
            line-height: 1.8;
            color: #333;
        }

        .team {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
            margin-top: 50px;
        }

        .team-member {
            width: 30%;
            text-align: center;
            margin-bottom: 30px;
            animation: fadeInMember 1.5s ease-in-out;
        }

        .team-member img {
            width: 100%;
            border-radius: 50%;
            border: 5px solid #fff;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            transition: 0.3s;
        }

        .team-member img:hover {
            transform: scale(1.05);
        }

        .team-member h5 {
            font-size: 1.5em;
            margin-top: 15px;
            color: #003366;
        }

        .team-member p {
            font-size: 1.1em;
            color: #777;
        }

        @keyframes fadeInHeader {
            0% { opacity: 0; transform: translateY(-50px); }
            100% { opacity: 1; transform: translateY(0); }
        }

        @keyframes fadeInSection {
            0% { opacity: 0; transform: translateY(50px); }
            100% { opacity: 1; transform: translateY(0); }
        }

        @keyframes fadeInMember {
            0% { opacity: 0; transform: translateY(30px); }
            100% { opacity: 1; transform: translateY(0); }
        }

        @media (max-width: 768px) {
            .team-member {
                width: 100%;
                margin-bottom: 40px;
            }
        }
    </style>
</head>
<body>

    <header class="about-header">
        <h1>درباره ما</h1>
        <p>ما به شما کمک می‌کنیم تا بهترین تجربه کمپینگ رو داشته باشید!</p>
    </header>

    <div class="container about-content">
        <div class="about-section">
            <h3>ماموریت ما</h3>
            <p>
                هدف ما ایجاد یک تجربه خاص و به یاد ماندنی برای علاقه‌مندان به کمپینگ است.
                از امکانات عالی تا طبیعت بکر، هر چیزی که شما نیاز دارید تا یک تعطیلات متفاوت و هیجان‌انگیز
                را تجربه کنید، در اختیار شما خواهیم گذاشت.
            </p>
        </div>

        <div class="about-section">
            <h3>اهداف ما</h3>
            <p>
                در سایت ما، هدف اصلی ارائه بهترین خدمات برای گردشگران و کمپینگ‌کاران است.
                ما می‌خواهیم تجربه‌ای به یاد ماندنی و بدون دغدغه برای شما فراهم کنیم.
            </p>
        </div>

        <div class="about-section">
            <h3>تیم ما</h3>
            <p>
                تیم ما از افراد با تجربه و متخصص در حوزه کمپینگ و گردشگری تشکیل شده است که همیشه آماده‌اند
                تا بهترین خدمات را برای شما فراهم کنند.
            </p>
        </div>

        <div class="team">
            <div class="team-member">
                <img src="https://via.placeholder.com/200" alt="team member 1">
                <h5>محمد علی</h5>
                <p>مدیر عامل</p>
            </div>

            <div class="team-member">
                <img src="https://via.placeholder.com/200" alt="team member 2">
                <h5>فرشته مهدی</h5>
                <p>مدیر بازاریابی</p>
            </div>

            <div class="team-member">
                <img src="https://via.placeholder.com/200" alt="team member 3">
                <h5>سارا طاهری</h5>
                <p>مدیر خدمات مشتریان</p>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>
