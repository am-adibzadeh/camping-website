<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "camping";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

if(!isset($_SESSION['id'])) {
    header('location: index.php');
    exit;
}

// گرفتن اطلاعات کاربر فعلی
$sql = "SELECT * FROM `users` WHERE `id`='" . $_SESSION['id'] . "'";
$result = $conn->query($sql);
if ($result->num_rows == 1) {
    $row = $result->fetch_assoc(); // اطلاعات کاربر فعلی
}

// گرفتن سفرهای این کاربر
$userId = $_SESSION['id'];
$sql_reservations = "SELECT r.*, f.name AS forest_name 
                     FROM reservations r
                     JOIN forests f ON r.forest_area_id = f.id
                     WHERE r.user_id = $userId
                     ORDER BY r.start_date DESC
                     LIMIT 10";
$result_reservations = $conn->query($sql_reservations);
$sql_reservations1 = "SELECT r.*, f.name AS forest_name 
                     FROM reservations r
                     JOIN forests f ON r.forest_area_id = f.id
                     WHERE r.user_id = $userId
                     ORDER BY r.start_date DESC
                     LIMIT 3";
$result_reservations1 = $conn->query($sql_reservations1);


?>

<!DOCTYPE html>
<html lang="en" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <!-- jQuery library -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>
    <!-- Popper JS -->
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>

    <title>کمپینگ</title>

    <link rel="stylesheet" href="Account.css">

    <!-- لوگو سایت -->
    <link rel="icon" type="img/download.jpg" sizes="192x192" href="img/camping_1f3d5 1.png">
</head>
<body>

<div class="container-fluid text-center mt-3">
        <div class="row">
            <div class="col-md-2 pr-5">
                <div class="ba-ra-ac" style="height: 700px;">
                    <img src="img/user-profile.jpg" class="prof-img mt-3" width="100px" alt="">
                    <h6 class="mt-2 mb-1"><?php echo $row['name']; ?></h6>
                    <h6 style="font-size: 17px;"><small><?php echo $row['role']; ?></small></h6>
                    <h6 class="mt-0 pt-0" style="color: #9a9ae6;"><small>ویرایش اطلاعات</small></h6>
                    <img src="img/Line 32.png" width="150px" height="1.5px" alt="">
                    <div class="container">
                        <div class="row mt-2" onclick="camping('dashbord')" id="atoop">
                            <img src="img/Control Panel.png" class="mr-3 ml-2" width="25px" height="25px" alt="">
                            <h6>داشبورد</h6>
                        </div>
                        <div class="row mt-5" onclick="camping('carbaran')">
                            <img src="img/Group2.png" class="mr-3 ml-2" width="15px" height="25px" alt="">
                            <h6>اطلاعات شخصی</h6>
                        </div>
                        <div class="row mt-5" onclick="camping('taniat')">
                            <img src="img/Bonfire.png" class="mr-3 ml-2" width="25px" height="25px" alt="">
                            <h6>سفر های من</h6>
                        </div>
                        <div class="row mt-5" onclick="camping('payam')">
                            <img src="img/Headset.png" class="mr-3 ml-2" width="25px" height="25px" alt="">
                            <h6>پشتیبانی</h6>
                        </div>
                        <div class="row mt-5 mr-1">
                            <a href="index.php">
                                <div class="row pb-2">
                                    <img src="img/icons8-home-100.png" class="mr-3 ml-2" width="25px" height="25px" alt="">
                                    <h6 class="mt-1">بازگشت</h6>
                                </div>
                            </a>
                        </div>

                        <div class="row mt-5 mr-1">
                            <a href="logout.php">
                                <div class="row pb-2">
                                    <img src="img/icons8-exit-100.png" class="mr-3 ml-2" width="25px" height="25px" alt="">
                                    <h6 class="mt-1" style="color: red;">خروج</h6>
                                </div>
                            </a>
                        </div>

                    </div>
                </div>
            </div>
            <div class="col-md-10">
                <div class="" id="bendaz" style="margin-top: 50px;">
                </div>

            </div>
        </div>
    </div>
    


</body>
<!-- آیکون‌ها -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/js/all.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.getElementById('atoop').click();
function camping(op)
{
    let x='';
    if(op == 'dashbord')
    {
        x='<div class="row pl-5 pr-5"><div class="col-md-4"><div class="cr-zard"><div class="inner-box p-3"><h4>اطلاعات شخصی</h4><img src="img/Line 31.png" alt=""><div class="scroll-area"><div class="col-md-12"><div class="row cr-zard-zar"><div class="col-md-6 text-right"><h6 class="p-0 m-0 mt-1" style="font-size: 12px;">نام و نام خوانوادگی :</h6></div><div class="col-md-6"><p class="mb-0 p-1" style="font-size: 11px;"><?php echo $row['name']; ?></p></div></div></div><div class="col-md-12 mt-2"><div class="row cr-zard-zar"><div class="col-md-7 text-right"><h6 class="p-0 m-0 mt-1" style="font-size: 13px;">تلفن همراه :</h6></div><div class="col-md-5"><p class="mb-0 p-1" style="font-size: 13px;"><?php echo $row['phone_number']; ?></p></div></div></div><div class="col-md-12 mt-2"><div class="row cr-zard-zar"><div class="col-md-7 text-right"><h6 class="p-0 m-0 mt-1" style="font-size: 13px;">تاریخ تولد :</h6></div><div class="col-md-5"><p class="mb-0 p-1" style="font-size: 13px;">1386/05/04</p></div></div></div><div class="col-md-12 mt-2"><div class="row cr-zard-zar"><div class="col-md-7 text-right"><h6 class="p-0 m-0 mt-1" style="font-size: 13px;">کدملی :</h6></div><div class="col-md-5"><p class="mb-0 p-1" style="font-size: 13px;"><?php echo $row['codmidi']; ?></p></div></div></div><div class="col-md-12 mt-2"><div class="row cr-zard-zar"><div class="col-md-7 text-right"><h6 class="p-0 m-0 mt-1" style="font-size: 13px;">رمز عبور :</h6></div><div class="col-md-5"><p class="mb-0 p-1" style="font-size: 13px;"><?php echo $row['password']; ?></p></div></div></div><div class="col-md-12 mt-2"><div class="row cr-zard-zar"><div class="col-md-4 text-right"><h6 class="p-0 m-0 mt-1" style="font-size: 13px;">آدرس :</h6></div><div class="col-md-8"><p class="mb-0 p-1" style="font-size: 13px;"><?php echo substr($row['adres'], 0, 40) . '...'; ?></p></div></div></div></div><a><p class="m-0 b-0 mt-2" style="color: #8c9cff;">مشاهده همه</p></a></div></div></div><div class="col-md-4"><div class="cr-ger"><div class="inner-box p-3"><h4>سفر های من</h4><img src="img/Line 31.png" width="100%" alt="">  <div class="scroll-area"><?php if ($result_reservations && $result_reservations->num_rows > 0): ?><?php while ($row_reservation = $result_reservations->fetch_assoc()): ?><div class="col-md-12 mt-2"><div class="row cr-ger-nar"><div class="col-md-6 text-right"><h6 class="p-0 m-0 mt-1" style="font-size: 12px;">جنگل :</h6></div><div class="col-md-6"><p class="mb-0 p-1" style="font-size: 11px;"><?php echo $row_reservation['forest_name']; ?></p></div><div class="col-md-4 text-right"><h6 class="p-0 m-0 mt-1" style="font-size: 12px;">تاریخ :</h6></div><div class="col-md-8"><p class="mb-0 p-1" style="font-size: 11px;"><?php echo $row_reservation['start_date'] . ' تا ' . $row_reservation['end_date']; ?></p></div></div></div><?php endwhile; ?><?php else: ?><p style="font-size: 12px;">هیچ سفری ثبت نشده است.</p><?php endif; ?></div><a><p class="m-0 b-0 mt-2" style="color: #8c9cff;">مشاهده همه</p></a></div></div></div><div class="col-md-4"><div class="cr-banafsh"><div class="inner-box p-3"><h4>پشتیبانی</h4><img src="img/Line 31.png" width="100%" alt=""><div class="scroll-area"><div class="col-md-12 mt-2"><div class="row cr-banafsh-ban"><div class="col-md-7 text-right"><h6 class="p-0 m-0 mt-1" style="font-size: 9px;"></h6></div><div class="col-md-12 text-right"><p class="mb-0 p-1" style="font-size: 13px;">هیچ پیامی به پشتیبانی وجود ندارد</p></div></div></div></div><p class="m-0 b-0 mt-2" style="color: #8c9cff; padding-top: 180px">مشاهده همه</p></div></div></div></div>'
        document.getElementById('bendaz').innerHTML=x;
    }else if(op == 'carbaran')
    {
        x='<div class="row pl-5 pr-5"><div class="col-md-12"><div class="cr-zard"><div class="inner-box"><div class="row"><div class="col-md-10 text-center" style="padding-right: 200px;"><h4>اطلاعات شخصی</h4></div><div class="col-md-2"><div class="action-btns"><a href="edituser.php"><button class="edit"><i class="fas fa-edit"></i></button></a></div></div></div><img src="img/Line long.png" width="100%" height="100%" alt=""><div class="col-md-12"><div class="row text-right mt-4"><div class="col-md-2">نام و نام خوانوادگی:</div><div class="col-md-2"><?php echo $row['name']; ?></div><div class="col-md-2">تاریخ تولد:</div><div class="col-md-2">1386.05.21</div><div class="col-md-2">کدملی:</div><div class="col-md-2"><?php echo $row['codmidi']; ?></div></div><div class="row text-right mt-5"><div class="col-md-2">آدرس اینترنتی:</div><div class="col-md-3"><?php echo $row['email']; ?></div><div class="col-md-3"></div><div class="col-md-2">شماره تلفن:</div><div class="col-md-2"><?php echo $row['phone_number']; ?></div></div><div class="row text-right mt-5"><div class="col-md-2">آدرس محل سکونت:</div><div class="col-md-10"><?php echo $row['adres']; ?></div></div><div class="row text-right mt-5"><div class="col-md-2">رمز عبور:</div><div class="col-md-3"><?php echo $row['password']; ?></div><div class="col-md-3"></div></div></div></div></div></div></div>'
        document.getElementById('bendaz').innerHTML=x;
    }else if(op == 'taniat')
    {
        x='<div class="row pl-5 pr-5"><div class="col-md-12"><div class="cr-ger"><div class="inner-box"><div class="row"><div class="col-md-10 text-center" style="padding-right: 200px;"><h4>سفر های من</h4></div><div class="col-md-2"><div class="action-btns"><a href="rezery.php?item=tree&time=day"><button class="add"><i class="fas fa-plus"></i> رزرو کمپ </button></a></div></div></div><img src="img/Line long.png" width="100%" height="100%" alt=""><div class="col-md-12"><?php if ($result_reservations1 && $result_reservations1->num_rows > 0): ?><?php while ($row_reservation1 = $result_reservations1->fetch_assoc()): ?><div class="row text-right mt-4"><div class="col-md-1">جنگل:</div><div class="col-md-2"><?php echo $row_reservation1['forest_name']; ?></div><div class="col-md-2">از تاریخ تا تاریخ:</div><div class="col-md-3"><?php echo $row_reservation1['start_date'] . ' تا ' . $row_reservation1['end_date']; ?></div><div class="col-md-1">قیمت:</div><div class="col-md-1"><?php echo number_format($row_reservation1['total_price'], 0, '.', ','); ?></div><div class="col-md-2"><?php $status = trim($row_reservation1['Examination']); $color = 'warning'; if ($status == 'تایید شده') {     $color = 'success'; } elseif ($status == 'درحال برسی...') {     $color = 'warning'; } elseif ($status == 'منقضی شده') {     $color = 'danger'; }?><button class="btn btn-<?php echo $color; ?> btn-block" disabled><?php echo $status ?: 'درحال برسی...';?></button></div></div><div class="row text-right mt-3"><div class="col-md-2">آدرس جنگل:</div><div class="col-md-3">شمال</div><div class="col-md-2"></div><div class="col-md-2">تعداد روز ها:</div><div class="col-md-1"><?php echo $row_reservation1['nights']; ?></div><div class="col-md-2 action-btns"><a href="generate_pdf.php?id=<?php echo $row_reservation1['id']; ?>" target="_blank"><button class="download-pdf"><i class="fas fa-file-pdf"></i> دانلود </button></a><a href="deletecamp.php?id=<?php echo $row_reservation1["id"]; ?>" onclick="return confirm(\'Do You Want Delete Row ??\')"><button class="delete"><i class="fas fa-trash-alt"></i></button></a></div></div><hr><?php endwhile; ?><?php else: ?><p style="font-size: 12px;">هیچ سفری ثبت نشده است.</p><?php endif; ?></div></div></div></div></div>'
        document.getElementById('bendaz').innerHTML=x;
    }else if(op == 'payam')
    {
        x='<div class="row pl-5 pr-5"><div class="col-md-12 mt-3"><div class="cr-banafsh"><div class="inner-box p-3 text-center"><div class="row"><div class="col-md-10 text-center" style="padding-right: 180px;"><h4>پشتیبانی</h4></div><div class="col-md-2"><div class="action-btns"><button class="add"><i class="fas fa-plus"></i> پیام دادن </button></div></div></div><img src="img/Line long.png" width="100%" alt=""><div class="scroll-area-acon"><div class="col-md-12"><div class="scroll-area-acon"><div class="row cr-banafsh-ban mt-2"><div class="col-md-7 text-right"><h6 class="p-0 m-0 mt-1" style="font-size: 13px;">هیچ پیامی به پشتیبانی وجود ندارد</h6></div><div class="col-md-5 text-right"><h6 class="p-0 m-0 mt-1" style="font-size: 10px;"></h6></div><div class="col-md-10 text-right"><p class="mb-0 p-1" style="font-size: 14px;"></p></div><div class="col-md-2 action-btns"></div></div></div></div></div></div></div>'
        document.getElementById('bendaz').innerHTML=x;
    }
}

</script>
</html>