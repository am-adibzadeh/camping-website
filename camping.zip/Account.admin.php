<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "camping";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

if(!isset($_SESSION['id'])) {
    header('location: index.php');
    exit;
}

$sql = "SELECT * FROM `users` WHERE `id`='" . $_SESSION['id'] . "'";
$result = $conn->query($sql);
if ($result->num_rows == 1) {
    $row = $result->fetch_assoc(); // اطلاعات کاربر فعلی
}

// جدول user
$allUsersQuery = "SELECT * FROM users";
$allUsersResult = $conn->query($allUsersQuery);

// جدول جنگل ها
$forestQuery = "SELECT * FROM forests";
$forestResult = $conn->query($forestQuery);



// جنگل های ریز
$areaSql = "
  SELECT forest_areas.*, forests.name AS forest_name 
  FROM forest_areas 
  JOIN forests ON forest_areas.forest_id = forests.id
  ORDER BY forest_areas.id DESC
";
$areaResult = $conn->query($areaSql);
$areasSql = "
  SELECT forest_areas.*, forests.name AS forest_name 
  FROM forest_areas 
  JOIN forests ON forest_areas.forest_id = forests.id
  ORDER BY forest_areas.id DESC
";
$areasResult = $conn->query($areasSql);



// کدتخفیف
$discountQuery = "SELECT * FROM discount_codes ORDER BY created_at DESC";
$discountResult = $conn->query($discountQuery);
$discountSql = "
    SELECT *, DATEDIFF(expiration_date, created_at) AS valid_days
    FROM discount_codes
    ORDER BY created_at DESC
";
$discountResult = $conn->query($discountSql);

// 
$discountQuery1 = "SELECT * FROM discount_codes ORDER BY created_at DESC";
$discountResult1 = $conn->query($discountQuery1);
$discountSql1 = "
    SELECT *, DATEDIFF(expiration_date, created_at) AS valid_days
    FROM discount_codes
    ORDER BY created_at DESC
";
$discountResult1 = $conn->query($discountSql1);


// نظرات
$commentsSql = "
    SELECT comments.comment, users.name 
    FROM comments 
    JOIN users ON comments.user_id = users.id 
    ORDER BY comments.created_at DESC
";
$commentsResult = $conn->query($commentsSql);
// نظرات با جنگل‌ها
$commentsWithForestSql = "
    SELECT comments.*, users.name AS user_name, forests.name AS forest_name
    FROM comments
    JOIN users ON comments.user_id = users.id
    JOIN forests ON comments.forest_id = forests.id
    ORDER BY comments.id DESC
";
$commentsWithForestResult = $conn->query($commentsWithForestSql);

// رزرو ها
$reservationsSql = "
    SELECT reservations.*, users.name AS user_name, forests.name AS forest_name
    FROM reservations
    JOIN users ON reservations.user_id = users.id
    JOIN forest_areas ON reservations.forest_area_id = forest_areas.id
    JOIN forests ON forest_areas.forest_id = forests.id
    ORDER BY reservations.created_at DESC
";
$reservationsResult = $conn->query($reservationsSql);
// رزرو ها ریز
$reservationsSql1 = "
    SELECT reservations.*, users.name AS user_name, forests.name AS forest_name
    FROM reservations
    JOIN users ON reservations.user_id = users.id
    JOIN forest_areas ON reservations.forest_area_id = forest_areas.id
    JOIN forests ON forest_areas.forest_id = forests.id
    ORDER BY reservations.created_at DESC
";
$reservationsResult1 = $conn->query($reservationsSql1);

?>

<!DOCTYPE html>
<html lang="en" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <!-- jQuery library -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>
    <!-- Popper JS -->
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>

    <title>کمپینگ</title>

    <link rel="stylesheet" href="Account.css">

    <!-- لوگو سایت -->
    <link rel="icon" type="img/download.jpg" sizes="192x192" href="img/camping_1f3d5 1.png">
</head>
<body>

    <div class="container-fluid text-center mt-3">
        <div class="row">
            <div class="col-md-2 pr-5 mr-">
                <div class="ba-ra-ac">
                    <img src="img/user-profile.jpg" class="prof-img mt-3" width="100px" alt="">
                    <h6 class="mt-2 mb-1"><?php echo $row['name']; ?></h6>
                    <h6 style="font-size: 17px;"><small><?php echo $row['role']; ?></small></h6>
                    <h6 class="mt-0 pt-0" style="color: #9a9ae6;"><small>ویرایش اطلاعات</small></h6>
                    <img src="img/Line 32.png" width="150px" height="1.5px" alt="">
                    <div class="container">
                        <div class="row mt-2" onclick="camping('dashbord')" id="atoop">
                            <img src="img/Control Panel.png" class="mr-3 ml-2" width="25px" height="25px" alt="">
                            <h6>داشبورد</h6>
                        </div>
                        <div class="row mt-5" onclick="camping('carbaran')">
                            <img src="img/Group.png" class="mr-3 ml-2" width="25px" height="25px" alt="">
                            <h6>کاربران</h6>
                        </div>
                        <div class="row mt-5" onclick="camping('taniat')">
                            <img src="img/Tent in the Forest.png" class="mr-3 ml-2" width="25px" height="25px" alt="">
                            <h6>رزرو ها</h6>
                        </div>
                        <div class="row mt-5" onclick="camping('manateg')">
                            <img src="img/Map.png" class="mr-3 ml-2" width="25px" height="25px" alt="">
                            <h6>مناطق</h6>
                        </div>
                        <div class="row mt-5" onclick="camping('payam')">
                            <img src="img/Chat.png" class="mr-3 ml-2" width="25px" height="25px" alt="">
                            <h6>نظرات</h6>
                        </div>
                        <div class="row mt-5" onclick="camping('tafif')">
                            <img src="img/Banknotes.png" class="mr-3 ml-2" width="25px" height="25px" alt="">
                            <h6>تخفیف ها</h6>
                        </div>
                        <div class="col-md-12 mt-4"><div class="row"><a href="index.php"><div class="row pb-2">
                            <img src="img/icons8-home-100.png" class="mr-3 ml-2" width="25px" height="25px" alt="">
                            <h6 class="mt-1">بازگشت</h6>
                        </div></a>
                        <a href="logout.php"><img src="img/icons8-exit-100.png" width="25px" height="25px" class="text-left" style="margin-right: 64px;" alt=""></a></div></div>

                    </div>
                </div>
            </div>
            <div class="col-md-10">
                <div class="" id="bendaz">
                </div>
            </div>
        </div>
    </div>


</body>
  <!-- آیکون‌ها -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/js/all.min.js"></script>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
  
<script>
document.getElementById('atoop').click();
function camping(op)
{
    let x='';
    if(op == 'dashbord')
    {
        x='<div class="row pl-5 pr-5"><div class="col-md-4"><div class="cr-sabz"><div class="inner-box p-3"><h4>کاربران</h4><img src="img/Line 31.png" width="100%" alt=""><div class="scroll-area mt-2"><?php if ($allUsersResult->num_rows > 0) {while($user = $allUsersResult->fetch_assoc()) {?><div class="col-md-12 mt-2"><div class="row da-cr-sabz"><div class="col-md-8 text-right"><h6 class="p-0 m-0 mt-1"><?php echo htmlspecialchars($user['name']); ?></h6></div><?php if (isset($user) && isset($user['role'])): ?><?php $role = htmlspecialchars($user['role']);$roleText = 'نامشخص';$bgClass = 'bg-secondary text-white'; if ($role === 'user') { $bgClass = 'bg-warning text-dark';$roleText = 'کاربر';} elseif ($role === 'admin') { $bgClass = 'bg-info text-white';$roleText = 'مدیر';}?><div class="col-md-4"><p class="mb-0 p-1 ba-ko2 rounded text-center <?php echo $bgClass; ?>"><?php echo $roleText; ?></p></div><?php else: ?><div class="col-md-4"><p class="mb-0 p-1 ba-ko2 bg-secondary text-white rounded text-center">نقش نامشخص</p></div><?php endif; ?></div></div><?php }} else {echo "<p class='text-center mt-3'>هیچ کاربری یافت نشد.</p>";}?></div><p class="m-0 b-0 mt-2" style="color: #8c9cff;">مشاهده همه</p></div></div></div><div class="col-md-4"><div class="cr-ger"><div class="inner-box p-3"><h4>رزرو</h4><img src="img/Line 31.png" width="100%" alt=""><div class="scroll-area mt-2"><?php $reservationsSql2 = "    SELECT reservations.*, users.name AS user_name, forests.name AS forest_name    FROM reservations    JOIN users ON reservations.user_id = users.id    JOIN forests ON reservations.forest_area_id = forests.id    ORDER BY reservations.created_at DESC";$reservationsResult2 = $conn->query($reservationsSql2); if ($reservationsResult2->num_rows > 0): while($res = $reservationsResult2->fetch_assoc()):?><div class="col-md-12 mt-2"><div class="row cr-ger-nar"><div class="col-md-6 text-right"> <h6 class="p-0 m-0 mt-1" style="font-size: 9px;"><?php echo htmlspecialchars($res['user_name']); ?></h6></div><div class="col-md-6 text-left mb-2"><h6 class="p-0 m-0 mt-1" style="font-size: 9px;"><?php echo number_format($res['total_price']); ?> تومان</h6></div><div class="col-md-8 text-right"><h6 class="p-0 m-0 mt-2"><?php echo htmlspecialchars($res['forest_name']); ?></h6></div><div class="col-md-4"><?php $status = htmlspecialchars($res['Examination']);$bgClass = 'bg-secondary text-dark';$fontSize = '12px'; if ($status === 'درحال برسی...') {    $bgClass = 'bg-warning text-dark';$fontSize = '9px';} elseif ($status === 'تایید شده') {    $bgClass = 'bg-success text-white';} elseif ($status === 'منقضی شده') {    $bgClass = 'bg-danger text-white';}?>    <p class="mb-0 p-1 ba-ko1 <?php echo $bgClass; ?>" style="font-size: <?php echo $fontSize; ?>;"><?php echo $status; ?></p></div></div></div><?php endwhile; ?><?php else: ?><p class="text-center mt-3">هیچ رزروی پیدا نشد.</p><?php endif; ?></div><p class="m-0 b-0 mt-2" style="color: #8c9cff;">مشاهده همه</p></div></div></div><div class="col-md-4"><div class="cr-abie"><div class="inner-box p-3"><h4>مناطق</h4><img src="img/Line 31.png" width="100%" alt=""><div class="scroll-area mt-2"><?php if ($areasResult->num_rows > 0): ?><?php while($area = $areasResult->fetch_assoc()): ?><div class="col-md-12 mt-2"><div class="row cr-abie-camr"><div class="col-md-8 text-right"><h6 class="p-0 m-0 mt-1" style="font-size: 12px;"><?php echo htmlspecialchars($area['forest_name'] . ' - ' . $area['area_name']); ?></h6></div><div class="col-md-4"><p class="mb-0 p-1" style="font-size: 12px;"><?php echo number_format($area['price']); ?>ت</p></div></div></div><?php endwhile; ?><?php else: ?><p class="text-center mt-3">ناحیه‌ای پیدا نشد.</p><?php endif; ?></div><p class="m-0 b-0 mt-2" style="color: #8c9cff;">مشاهده همه</p></div></div></div><div class="col-md-4 mt-4"><div class="cr-banafsh"><div class="inner-box p-3"><h4>نظرات</h4><img src="img/Line 31.png" width="100%" alt=""><div class="scroll-area2"><?php if ($commentsResult->num_rows > 0): ?><?php while($commentRow = $commentsResult->fetch_assoc()): ?><div class="col-md-12 mt-2"><div class="row cr-banafsh-ban"><div class="col-md-7 text-right"><h6 class="p-0 m-0 mt-1" style="font-size: 9px;">از طرف <?php echo htmlspecialchars($commentRow['name']); ?></h6></div><div class="col-md-12 text-right"><p class="mb-0 p-1" style="font-size: 13px;"><?php echo htmlspecialchars(mb_substr($commentRow['comment'], 0, 28)) . '...'; ?></p></div></div></div><?php endwhile; ?><?php else: ?><p class="text-center">هیچ نظری ثبت نشده است.</p><?php endif; ?></div><p class="m-0 b-0 mt-2" style="color: #8c9cff;">مشاهده همه</p></div></div></div><div class="col-md-4 mt-4"><div class="cr-narengi"><div class="inner-box p-3"><h4>تخفیف ها</h4><img src="img/Line 31.png" width="100%" alt=""><div class="scroll-area2"><div class="col-md-12"><?php if ($discountResult->num_rows > 0): ?><?php while($discount = $discountResult->fetch_assoc()): ?><div class="row cr-narengi-nar mb-2"><div class="col-md-4 text-right"><h6 class="p-0 m-0 mt-1" style="font-size: 15px;"><?php echo htmlspecialchars($discount['code']); ?></h6></div><div class="col-md-4"><p class="mb-0 p-1" style="font-size: 15px;"><?php echo htmlspecialchars($discount['discount_percentage']); ?>%</p></div><div class="col-md-4"><p class="mb-0 p-1" style="font-size: 10px;"><?php echo htmlspecialchars($discount['expiration_date']); ?></p></div></div><?php endwhile; ?><?php else: ?><p class="text-center mt-3">کدی ثبت نشده است.</p><?php endif; ?></div></div><p class="m-0 b-0 mt-2" style="color: #8c9cff;">مشاهده همه</p></div></div></div><div class="col-md-4 mt-4"><div class="cr-zard"><div class="inner-box p-3"><h4>اطلاعات شخصی</h4><img src="img/Line 31.png" width="100%" alt=""><div class="scroll-area2"><div class="col-md-12"><div class="row cr-zard-zar"><div class="col-md-6 text-right"><h6 class="p-0 m-0 mt-1" style="font-size: 12px;">نام و نام خوانوادگی :</h6></div><div class="col-md-6"><p class="mb-0 p-1" style="font-size: 11px;"><?php echo $row['name']; ?></p></div></div></div><div class="col-md-12 mt-2"><div class="row cr-zard-zar"><div class="col-md-7 text-right"><h6 class="p-0 m-0 mt-1" style="font-size: 13px;">تلفن همراه :</h6></div><div class="col-md-5"><p class="mb-0 p-1" style="font-size: 13px;"><?php echo $row['phone_number']; ?></p></div></div></div><div class="col-md-12 mt-2"><div class="row cr-zard-zar"><div class="col-md-7 text-right"><h6 class="p-0 m-0 mt-1" style="font-size: 13px;">تاریخ تولد :</h6></div><div class="col-md-5"><p class="mb-0 p-1" style="font-size: 13px;">1386/05/04</p></div></div></div><div class="col-md-12 mt-2"><div class="row cr-zard-zar"><div class="col-md-7 text-right"><h6 class="p-0 m-0 mt-1" style="font-size: 13px;">کدملی :</h6></div><div class="col-md-5"><p class="mb-0 p-1" style="font-size: 13px;"><?php echo $row['codmidi']; ?></p></div></div></div></div><a href="Account.php"><p class="m-0 b-0 mt-2" style="color: #8c9cff;">مشاهده همه</p></a></div></div></div></div>'
        document.getElementById('bendaz').innerHTML=x;
    }else if(op == 'carbaran')
    {
        x='<div class="row pl-5 pr-5"><div class="col-md-12"><div class="cr-sabz"><div class="inner-box"><div class="row"><div class="col-md-10 text-center" style="padding-right: 200px;"><h4>کاربران</h4></div><div class="col-md-2"><div class="action-btns"><button class="add"><i class="fas fa-plus"></i> اضافه کردن</button></div></div></div><img src="img/Line long.png" width="100%" alt=""><div class="mt-3 scroll-area-acon" style="overflow-x: auto;" id="scrollTableWrapper"><table class="table custom-table table-bordered" style="min-width: 1600px;"><thead><tr><th style="width: 170px;">نام</th><th style="width: 160px;">شماره تلفن</th><th style="width: 120px;">کدملی</th><th style="width: 140px;">رمز عبور</th><th style="width: 240px;">ایمیل</th><th style="width: 360px;">آدرس</th><th style="width: 80px;">نقش</th><th style="width: 130px;">عضویت</th><th style="width: 100px;" class="action">عملیات</th></tr></thead><tbody><?php $allUsersQuery = "SELECT * FROM users";$allUsersResult = $conn->query($allUsersQuery);if ($allUsersResult->num_rows > 0) {while ($user = $allUsersResult->fetch_assoc()) {$role = htmlspecialchars($user['role']);$roleText = 'نامشخص';$roleClass = 'text-secondary';if ($role === 'user') {  $roleText = 'کاربر';  $roleClass = 'bg-warning text-dark';} elseif ($role === 'admin') {  $roleText = 'مدیر';  $roleClass = 'bg-info text-white';}?><tr><td><?php echo htmlspecialchars($user['name']); ?></td><td><?php echo htmlspecialchars($user['phone_number']); ?></td><td><?php echo htmlspecialchars($user['codmidi']); ?></td><td><?php echo htmlspecialchars($user['password']); ?></td><td><?php echo htmlspecialchars($user['email']); ?></td><td><?php echo htmlspecialchars($user['adres']); ?></td><td><span class="p-1 ba-ko2 rounded text-center <?php echo $roleClass; ?>"><?php echo $roleText; ?></span></td><td><?php echo htmlspecialchars($user['created_at']); ?></td><td class="action-btns"><a href="edituseradmin.php?id=<?php echo htmlspecialchars($user['id']); ?>"><button class="edit"><i class="fas fa-edit"></i></button></a><a href="deleteuser.php?id=<?php echo htmlspecialchars($user['id']); ?>" onclick="return confirm(\'آیا مطمعن هستید می خواهید این کاربر رو حذف کنید؟؟\')"><button class="delete"><i class="fas fa-trash-alt"></i></button></a></td></tr><?php   }} else {  echo "<tr><td colspan='9' class='text-center'>هیچ کاربری یافت نشد.</td></tr>";}?></tbody></table></div></div></div></div></div>'
        document.getElementById('bendaz').innerHTML=x;
    }else if(op == 'taniat')
    {
        x='<div class="row pl-5 pr-5"><div class="col-md-12"><div class="cr-ger"><div class="inner-box"><div class="row"><div class="col-md-10 text-center" style="padding-right: 200px;"><h4>رزرو ها</h4></div><div class="col-md-2"><div class="action-btns"><button class="add"><i class="fas fa-plus"></i> اضافه کردن</button></div></div></div><img src="img/Line long.png" width="100%" alt=""><div class="mt-3 scroll-area-acon" style="overflow-x: auto;"><table class="table custom-table-red table-bordered" style="min-width: 1600px;"><thead><tr><th style="width: 170px;">نام</th><th style="width: 160px;">جنگل فلان</th><th style="width: 120px;">از تاریخ</th><th style="width: 120px;">تا تاریخ</th><th style="width: 120px;">تعداد روز ها</th><th style="width: 160px;">قیمت کل</th><th style="width: 120px;">کد تخفیف</th><th style="width: 150px;">موارد اضافی</th><th style="width: 120px;">تاریخ رزرو</th><th style="width: 100px;" class="action">عملیات</th></tr></thead><tbody><?php if ($reservationsResult->num_rows > 0): ?><?php while($row = $reservationsResult->fetch_assoc()): ?><tr><td><?php echo htmlspecialchars($row['user_name']); ?></td><td><?php echo htmlspecialchars($row['forest_name']); ?></td><td><?php echo htmlspecialchars($row['start_date']); ?></td><td><?php echo htmlspecialchars($row['end_date']); ?></td><td><?php echo htmlspecialchars($row['nights']); ?></td><td><?php echo number_format($row['total_price']); ?> تومان</td><td><?php echo htmlspecialchars($row['discount_code'] ?? '-'); ?></td><td><?php echo htmlspecialchars($row['extras'] ?? '-'); ?></td><td><?php echo htmlspecialchars($row['created_at']); ?></td><td class="action-btns"><a href="editrezeryadmin.php?id=<?php echo htmlspecialchars($row['id']); ?>"><button class="edit"><i class="fas fa-edit"></i></button></a><a href="deletecamp.php?id=<?php echo htmlspecialchars($row['id']); ?>" onclick="return confirm(\'آیا مطمعن هستید که می خواهید این رزرو را حدف کنید؟؟\')"><button class="delete"><i class="fas fa-trash-alt"></i></button></a></td></tr><?php endwhile; ?><?php else: ?><tr><td colspan="10" class="text-center">هیچ رزروی ثبت نشده است.</td></tr><?php endif; ?></tbody></table></div></div></div></div></div>'
        document.getElementById('bendaz').innerHTML=x;
    }else if(op == 'manateg')
    {
        x='<div class="row pl-5 pr-5"><div class="col-md-12"><div class="cr-abie"><div class="inner-box"><div class="row"><div class="col-md-10 text-center" style="padding-right: 180px;"><h4>لیست جنگل‌ها</h4></div><div class="col-md-2"><div class="action-btns"><button class="add"><i class="fas fa-plus"></i> اضافه کردن</button></div></div></div><img src="img/Line long.png" width="100%" alt=""><div class="mt-3 scroll-area-acon"><table class="table custom-table-abe table-bordered"><thead><tr><th>نام جنگل ، استان</th><th>موقعیت</th><th>قیمت</th><th>توضیحات</th><th class="action">عملیات</th></tr></thead><tbody><?php if ($areaResult->num_rows > 0): ?><?php while($area = $areaResult->fetch_assoc()): ?><tr><td><?= htmlspecialchars($area['forest_name']) ?></td><td><?= htmlspecialchars($area['area_name']) ?></td><td><?= htmlspecialchars($area['price']) ?> تومان</td><td><?= htmlspecialchars($area['description']) ?></td><td class="action-btns"><a href="editmantagidmin.php?id=<?php echo htmlspecialchars($area['id']); ?>"><button class="edit"><i class="fas fa-edit"></i></button></a><a href="deletematagi.php?id=<?php htmlspecialchars($area['id']) ?>" onclick="return confirm(\'آیا مطمعن هستید که می خواهید این منطقه را حدف کنید؟؟\')"><button class="delete"><i class="fas fa-trash-alt"></i></button></a></td></tr><?php endwhile; ?><?php else: ?><tr><td colspan="5" class="text-center">هیچ منطقه‌ای پیدا نشد.</td></tr><?php endif; ?></tbody></table></div></div></div></div></div>'
        document.getElementById('bendaz').innerHTML=x;
    }else if(op == 'payam')
    {
        x='<div class="row pl-5 pr-5"><div class="col-md-12 mt-3"><div class="cr-banafsh"><div class="inner-box p-3 text-center"><div class="row"><div class="col-md-10 text-center" style="padding-right: 180px;"><h4>پیام‌ها</h4></div><div class="col-md-2"><div class="action-btns"><button class="add"><i class="fas fa-plus"></i> اضافه کردن</button></div></div></div><img src="img/Line long.png" width="100%" alt=""><div class="scroll-area-acon"><div class="col-md-12"><div class="scroll-area-acon"><?php if ($commentsWithForestResult->num_rows > 0): ?><?php while($comment = $commentsWithForestResult->fetch_assoc()): ?><div class="row cr-banafsh-ban mt-2"><div class="col-md-7 text-right"><h6 class="p-0 m-0 mt-1" style="font-size: 10px;">از طرف <?php echo htmlspecialchars($comment['user_name']); ?></h6></div><div class="col-md-5 text-right"><h6 class="p-0 m-0 mt-1" style="font-size: 10px;"><?php echo htmlspecialchars($comment['forest_name']); ?></h6></div><div class="col-md-10 text-right"><p class="mb-0 p-1" style="font-size: 14px;"><?php echo htmlspecialchars($comment['comment']); ?></p></div><div class="col-md-2 action-btns"><button class="edit"><i class="fas fa-edit"></i></button><a href="deletenazar.php?id=<?php htmlspecialchars($comment['id']) ?>" onclick="return confirm(\'آیا مطمعن هستید که می خواهید این نظر را حدف کنید؟؟\')"><button class="delete"><i class="fas fa-trash-alt"></i></button></a><button class="replay">پاسخ</button></div></div><?php endwhile; ?><?php else: ?><p class="text-center">هیچ نظری ثبت نشده است.</p><?php endif; ?></div></div></div></div></div></div></div>'
        document.getElementById('bendaz').innerHTML=x;
    }else if(op == 'tafif')
    {
        x='<div class="row pl-5 pr-5"><div class="col-md-12 mt-3"><div class="cr-narengi"><div class="inner-box p-3"><div class="row"><div class="col-md-10 text-center" style="padding-right: 200px;"><h4>تخفیف ها</h4></div><div class="col-md-2"><div class="action-btns"><button class="add"><i class="fas fa-plus"></i> اضافه کردن</button></div></div></div><img src="img/Line long.png" width="100%" alt=""><div class="scroll-area-acon"><?php if ($discountResult1->num_rows > 0): ?><?php while($code = $discountResult1->fetch_assoc()): ?><div class="col-md-12 mt-3"><div class="row cr-narengi-nar"><div class="col-md-3 text-right mt-2"><h6 class="p-0 m-0 mt-1" style="font-size: 15px;"><?php echo htmlspecialchars($code['code']); ?></h6></div><div class="col-md-3 mt-2"><p class="mb-0 p-1" style="font-size: 15px;"><?php echo $code['valid_days']; ?> روز</p></div><div class="col-md-3 mt-2"><p class="mb-0 p-1" style="font-size: 15px;"><?php echo $code['discount_percentage']; ?>%</p></div><div class="col-md-1"></div><div class="col-md-2 action-btns"><button class="edit"><i class="fas fa-edit"></i></button><a href="deletetaff.php?id=<?php htmlspecialchars($code['id']) ?>" onclick="return confirm(\'آیا مطمعن هستید که می خواهید این کدتخفیف را حدف کنید؟؟\')"><button class="delete"><i class="fas fa-trash-alt"></i></button></a></div></div></div><?php endwhile; ?><?php else: ?><p class="text-center">هیچ کد تخفیفی ثبت نشده است.</p><?php endif; ?></div></div></div></div></div>'
        document.getElementById('bendaz').innerHTML=x;
    }
}
</script>
</html>