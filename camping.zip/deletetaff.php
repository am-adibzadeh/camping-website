<?php
$resalat = new mysqli('localhost', 'root', '','camping');
$sql_code="DELETE FROM `discount_codes` WHERE `id`='".$_GET['id']."'";
$resalat->query($sql_code);
header("Location: index.php");
?>