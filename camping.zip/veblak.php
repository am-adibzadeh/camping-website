<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>وبلاگ کمپینگ</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Tahoma', sans-serif;
            margin: 0;
            padding: 0;
            background: #f4f7fc;
            direction: rtl;
            text-align: right;
            overflow-x: hidden; /* اضافه کردن این خط برای جلوگیری از اسکرول افقی */
        }

        .blog-header {
            background: url('img/Flux_Dev_A_serene_and_breathtaking_camping_scene_at_sunset_cap_3.jpeg') no-repeat center;
            background-size: cover;
            color: #fff;
            padding: 100px 0;
            text-align: center;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            height: 500px;
        }

        .blog-header h1 {
            font-size: 3.5em;
            margin-bottom: 20px;
            font-weight: 700;
            text-shadow: 3px 3px 15px rgba(0, 0, 0, 0.4);
        }

        .blog-header p {
            font-size: 1.3em;
            font-weight: 300;
        }

        .blog-posts {
            padding: 80px 150px;
        }

        .post {
            background-color: #fff;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
            transition: all 0.3s ease;
            height: 100%;
            display: flex;
            flex-direction: column;
        }

        .post img {
            width: 100%;
            height: 200px;
            object-fit: cover;
            border-radius: 15px 15px 0 0;
            transition: all 0.3s ease;
        }

        .post img:hover {
            transform: scale(1.05);
        }

        .post-content {
            padding: 15px;
            flex-grow: 1;
        }

        .post-title {
            font-size: 1.6em;
            color: #003366;
            margin-bottom: 10px;
            font-weight: 600;
        }

        .post-meta {
            font-size: 1em;
            color: #777;
            margin-bottom: 10px;
        }

        .post-excerpt {
            font-size: 0.9em;
            line-height: 1.6;
            color: #555;
            flex-grow: 1;
            height: 45px; /* نمایش کامل خط اول */
            overflow: hidden; /* اطمینان از اینکه متن بعد از اولین خط مخفی می‌شود */
        }

        .dots {
            display: inline;
        }

        .full-text {
            display: none;
        }

        .read-more {
            color: #007bff;
            cursor: pointer;
            font-size: 0.9em;
        }

        .read-more:hover {
            text-decoration: underline;
        }

        .pagination {
            justify-content: center;
            margin-top: 50px;
        }

        .pagination .page-link {
            color: #004d8b;
            font-size: 1.1em;
        }

        .pagination .page-item.active .page-link {
            background-color: #004d8b;
            border-color: #004d8b;
            color: #fff;
        }

        .pagination .page-item.disabled .page-link {
            color: #ddd;
        }

        .pagination .page-item .page-link:hover {
            color: #fff;
            background-color: #003366;
            border-color: #003366;
        }

        @media (max-width: 768px) {
            .post {
                margin-bottom: 20px;
            }
        }

        .row > .col-md-4 {
            margin-bottom: 30px; /* فاصله بین هر ردیف */
        }
    </style>
</head>
<body>

    <header class="blog-header">
        <h1>وبلاگ کمپینگ</h1>
        <p>تجربیات و مطالب جذاب درباره دنیای کمپینگ</p>
    </header>

    <div class="container-fluid blog-posts">
        <div class="row" id="posts-container">
            <!-- Posts will be dynamically loaded here -->
        </div>

        <!-- Pagination -->
        <div class="row">
            <div class="col-12">
                <nav aria-label="Page navigation">
                    <ul class="pagination" id="pagination">
                        <!-- Pagination items will be inserted dynamically -->
                    </ul>
                </nav>
            </div>
        </div>

        <!-- Options for selecting number of posts per page -->
        <div class="row justify-content-center mt-4">
            <div class="col-auto">
                <label for="postsPerPageSelect">تعداد پست‌ها در هر صفحه:</label>
                <select id="postsPerPageSelect" class="form-control">
                    <option value="9">9 پست</option>
                    <option value="12">12 پست</option>
                    <option value="24">24 پست</option>
                </select>
            </div>
        </div>
    </div>

    <script>
        let postsPerPage = 9; // تعداد پست‌های اولیه در هر صفحه
        let currentPage = 1;
        const totalPosts = 24;
        const posts = [
        { title: "راهنمای انتخاب بهترین تجهیزات کمپینگ", image: "img/camping-gears.jpg", author: "محمد علی", date: "25 دی 1399", excerpt: "در این مقاله، به بررسی بهترین تجهیزات کمپینگ و نکات کلیدی برای انتخاب آنها می‌پردازیم" },
        { title: "چگونه یک کمپ موفق بسازیم؟", image: "img/Image-07_09_2024-1-1024x682.webp", author: "فرشته مهدی", date: "20 دی 1399", excerpt: "در این مقاله می‌آموزیم که چگونه یک کمپ خوب بسازیم و در دل طبیعت لذت ببریم" },
        { title: "کمپینگ در فصل‌های مختلف", image: "img/best-time-for-climbing.jpg", author: "سارا طاهری", date: "18 دی 1399", excerpt: "کمپینگ در هر فصل ویژگی‌های خاص خود را دارد. در این مقاله، به بررسی این ویژگی‌ها می‌پردازیم" },
        { title: "چگونه کمپینگ خود را جذاب کنیم؟", image: "img/-زدن-e1529929665217.jpg", author: "علی راد", date: "10 دی 1399", excerpt: "برخی نکات برای داشتن یک تجربه جذاب و به یاد ماندنی در کمپینگ" },
        { title: "نکات ایمنی در کمپینگ", image: "img/0032865_Blog-Amozeshi-1_550.webp", author: "لیلا آذری", date: "5 دی 1399", excerpt: "ایمنی در کمپینگ اهمیت زیادی دارد. در این مقاله، به مهم‌ترین نکات ایمنی می‌پردازیم" },
        { title: "راهنمای انتخاب بهترین محل کمپینگ", image: "img/How-to-find-the-best-place-to-camp_.jpg", author: "فرشاد حیدری", date: "1 دی 1399", excerpt: "چگونه بهترین مکان برای کمپینگ را انتخاب کنیم؟ در این مقاله به بررسی عوامل مهم انتخاب محل کمپینگ می‌پردازیم" },
        { title: "چگونه وسایل کمپینگ خود را سازماندهی کنیم؟", image: "img/yfa_051616_42218_campsite_comfort_organization_lg.jpg", author: "مینا حسینی", date: "28 آذر 1399", excerpt: "سازماندهی وسایل برای کمپینگ اهمیت زیادی دارد. در این مقاله، روش‌های مختلف سازماندهی وسایل کمپینگ را بررسی می‌کنیم..." },
        { title: "نکات جالب در مورد کمپینگ در کوهستان", image: "img/-زدن-e1529929665217.jpg", author: "جواد کریمی", date: "25 آذر 1399", excerpt: "کمپینگ در کوهستان یک تجربه خاص است. در این مقاله نکات جالب و مفیدی برای کمپینگ در کوهستان را بررسی می‌کنیم..." },
        { title: "چگونه غذای خوشمزه در کمپینگ بپزیم؟", image: "img/9d427700-bced-4f55-8e97-fab58b17b30a.webp", author: "ندا مصطفوی", date: "20 آذر 1399", excerpt: "پخت غذای خوشمزه در کمپینگ می‌تواند تجربه‌ای لذت‌بخش باشد. در این مقاله نکات کلیدی برای پخت غذا در کمپینگ را بررسی می‌کنیم..." },
        { title: "تجربه کمپینگ در طبیعت بکر", image: "img/5e1c0e0bbc47f816120fdf3d.jpg", author: "سینا احمدی", date: "15 آذر 1399", excerpt: "کمپینگ در طبیعت بکر می‌تواند تجربه‌ای فراموش‌نشدنی باشد. در این مقاله، به بررسی تجربیات شخصی از کمپینگ در طبیعت بکر می‌پردازیم..." },
        { title: "کمپینگ با خانواده: نکات ضروری", image: "img/How_20to_20Plan_20a_20Successful_20Family_20Camping_20Trip.jpg", author: "زهره صالحی", date: "10 آذر 1399", excerpt: "کمپینگ با خانواده تجربه‌ای شاد و آموزنده است. در این مقاله نکات ضروری برای کمپینگ خانوادگی را بررسی می‌کنیم..." },
        { title: "چگونه در کمپینگ آرامش پیدا کنیم؟", image: "img/camp1.jpg.webp", author: "رحیم فلاح", date: "5 آذر 1399", excerpt: "کمپینگ می‌تواند فرصتی برای استراحت و آرامش باشد. در این مقاله راه‌هایی برای پیدا کردن آرامش در کمپینگ را بررسی می‌کنیم..." },
        { title: "آشنایی با انواع چادرهای کمپینگ", image: "img/unnamed.jpg", author: "نیکا قاسمی", date: "1 آذر 1399", excerpt: "در این مقاله با انواع مختلف چادرهای کمپینگ و ویژگی‌های آنها آشنا می‌شویم..." },
        { title: "بهترین زمان برای کمپینگ در ایران", image: "img/2-تصویر-جدیدی-ییلاق-به-چه-مناطقی-گفته-می_شود؟.jpg", author: "محمدرضا توکلی", date: "25 آبان 1399", excerpt: "در این مقاله بهترین زمان‌ها برای کمپینگ در ایران را بررسی می‌کنیم..." },
        { title: "چگونه کمپینگ لوکسی داشته باشیم؟", image: "img/کمپینگ-در-طبیعت.webp", author: "عاطفه یزدی", date: "20 آبان 1399", excerpt: "کمپینگ لوکس می‌تواند تجربه‌ای بی‌نظیر باشد. در این مقاله، به نکات مهم برای داشتن کمپینگ لوکس می‌پردازیم..." },
        { title: "کمپینگ در شب: چالش‌ها و راه‌حل‌ها", image: "img/Camping-tent.jpg", author: "حسین نادری", date: "15 آبان 1399", excerpt: "کمپینگ در شب چالش‌های خاص خود را دارد. در این مقاله، به بررسی چالش‌ها و راه‌حل‌های کمپینگ شبانه می‌پردازیم..." },
        { title: "راهنمای انتخاب بهترین کفش برای کمپینگ", image: "img/راهنمای-خرید-کفش-کوهنوردی.webp", author: "سینا مهرابی", date: "10 آبان 1399", excerpt: "انتخاب کفش مناسب برای کمپینگ می‌تواند تفاوت زیادی ایجاد کند. در این مقاله، به بررسی بهترین کفش‌ها برای کمپینگ می‌پردازیم..." },
        { title: "کمپینگ به سبک سبک زندگی پایدار", image: "img/camping-first-timer-tips.jpeg", author: "مرضیه طاهری", date: "5 آبان 1399", excerpt: "کمپینگ به سبک پایدار می‌تواند بر تجربه شما تأثیر زیادی بگذارد. در این مقاله، به بررسی راه‌های کمپینگ پایدار می‌پردازیم..." },
        { title: "چگونه کمپینگ را در باران تجربه کنیم؟", image: "img/Camping-in-rainy-weather-has-some-tips-that-you-should-follow.jpg", author: "امیر شجاعی", date: "1 آبان 1399", excerpt: "کمپینگ در باران می‌تواند تجربه‌ای خاص و متفاوت باشد. در این مقاله، به نکات کمپینگ در باران می‌پردازیم..." },
        { title: "آموزش کمپینگ در مناطق کویری", image: "img/نشرهق.jpg", author: "نادر افشاری", date: "25 مهر 1399", excerpt: "کمپینگ در مناطق کویری می‌تواند چالش‌هایی داشته باشد. در این مقاله، نکات و آموزش‌های مهم برای کمپینگ در کویر را بررسی می‌کنیم..." },
        { title: "راهنمای انتخاب چادر مناسب برای کمپینگ", image: "img/dsc00389-edit-2-1024x682-1.jpg", author: "سیما گلی", date: "20 مهر 1399", excerpt: "در این مقاله، به بررسی انواع چادرهای مناسب کمپینگ و ویژگی‌های آنها پرداخته‌ایم..." },
        { title: "کمپینگ در کنار دریاچه‌ها", image: "img/5e1c0e0bbc47f816120fdf3d.jpg", author: "سعید غلامی", date: "15 مهر 1399", excerpt: "کمپینگ در کنار دریاچه‌ها می‌تواند بسیار لذت‌بخش باشد. در این مقاله، به نکات کمپینگ در کنار دریاچه‌ها می‌پردازیم..." },
        { title: "چگونه کمپینگ ارزان‌تری داشته باشیم؟", image: "img/f3eaae8f4618065e43cbb4d981d97f151583312959.jpg", author: "مریم طاهری", date: "10 مهر 1399", excerpt: "کمپینگ ارزان نیاز به برنامه‌ریزی دقیق دارد. در این مقاله، به بررسی نکات و راهکارهایی برای داشتن یک کمپینگ ارزان پرداخته‌ایم..." },
        { title: "کمپینگ در فصل زمستان", image: "img/گرم-نگه-داشتن-چادر-مسافرتی.png", author: "هانیه سلیمانی", date: "25 شهریور 1399", excerpt: "کمپینگ در زمستان به تجهیزات ویژه نیاز دارد. در این مقاله، به بررسی نکات کمپینگ در زمستان پرداخته‌ایم..." },
        { title: "آموزش ساخت آتش در کمپینگ", image: "img/campfire-1493151033GIm-1.jpg", author: "مریم امیری", date: "5 شهریور 1399", excerpt: "ساخت آتش در کمپینگ یک مهارت حیاتی است. در این مقاله، روش‌های مختلف ساخت آتش را بررسی می‌کنیم..." },
        { title: "کمپینگ و فعالیت‌های ورزشی در طبیعت", image: "img/آموزش-تمرینات-کوهنوردی.webp", author: "مهران جمشیدی", date: "1 شهریور 1399", excerpt: "کمپینگ به‌عنوان فرصتی برای انجام فعالیت‌های ورزشی می‌تواند تجربه‌ای بی‌نظیر باشد. در این مقاله به بررسی فعالیت‌های ورزشی در کمپینگ می‌پردازیم..." },
        { title: "کمپینگ با دوستان: راهنمای برنامه‌ریزی", image: "img/عکس-اول-2.jpg", author: "جواد کریمی", date: "20 مرداد 1399", excerpt: "کمپینگ با دوستان یک تجربه متفاوت است. در این مقاله به راه‌های برنامه‌ریزی برای کمپینگ با دوستان پرداخته‌ایم..." },
        { title: "کمپینگ و طبیعت‌گردی در ایران", image: "img/nature-tourism-iran.jpg", author: "محسن ابراهیمی", date: "15 مرداد 1399", excerpt: "ایران یکی از بهترین مقاصد برای کمپینگ و طبیعت‌گردی است. در این مقاله، به معرفی بهترین مکان‌ها برای کمپینگ در ایران پرداخته‌ایم..." }
    ];


        // Function to render posts
        function renderPosts(posts, page, postsPerPage) {
            const startIndex = (page - 1) * postsPerPage;
            const endIndex = Math.min(startIndex + postsPerPage, posts.length);
            const postsToDisplay = posts.slice(startIndex, endIndex);

            const postsContainer = document.getElementById("posts-container");
            postsContainer.innerHTML = ""; // Clear current posts

            postsToDisplay.forEach(post => {
                const postElement = document.createElement("div");
                postElement.classList.add("col-md-4");
                postElement.innerHTML = `
                    <div class="post">
                        <img src="${post.image}" alt="${post.title}">
                        <div class="post-content">
                            <h3 class="post-title">${post.title}</h3>
                            <p class="post-meta">نوشته شده توسط ${post.author} در تاریخ ${post.date}</p>
                            <p class="post-excerpt">
                                <span class="excerpt-text">${post.excerpt.slice(0, 60)}...</span>
                                <span class="full-text">${post.excerpt}</span>
                            </p>
                            <a class="read-more" onclick="toggleText(this)">ادامه مطلب</a>
                        </div>
                    </div>
                `;
                postsContainer.appendChild(postElement);
            });
        }

        // Function to render pagination
        function renderPagination(totalPosts, currentPage, postsPerPage) {
            const paginationContainer = document.getElementById("pagination");
            paginationContainer.innerHTML = ""; // Clear current pagination

            const totalPages = Math.ceil(totalPosts / postsPerPage);
            for (let i = 1; i <= totalPages; i++) {
                const pageItem = document.createElement("li");
                pageItem.classList.add("page-item");
                if (i === currentPage) {
                    pageItem.classList.add("active");
                }

                const pageLink = document.createElement("a");
                pageLink.classList.add("page-link");
                pageLink.href = "#";
                pageLink.textContent = i;
                pageLink.onclick = function (e) {
                    e.preventDefault();
                    currentPage = i;
                    renderPosts(posts, currentPage, postsPerPage);
                    renderPagination(totalPosts, currentPage, postsPerPage);
                };

                pageItem.appendChild(pageLink);
                paginationContainer.appendChild(pageItem);
            }
        }

        // Function to toggle post text visibility
        function toggleText(link) {
            const postExcerpt = link.previousElementSibling;
            const fullText = postExcerpt.querySelector('.full-text');
            const excerptText = postExcerpt.querySelector('.excerpt-text');

            if (fullText.style.display === "none") {
                fullText.style.display = "inline";
                excerptText.style.display = "none";
                link.textContent = "کمتر دیدن";
            } else {
                fullText.style.display = "none";
                excerptText.style.display = "inline";
                link.textContent = "ادامه مطلب";
            }
        }

        // Event listener for changing posts per page
        document.getElementById("postsPerPageSelect").addEventListener("change", function () {
            postsPerPage = parseInt(this.value);
            currentPage = 1; // Reset to the first page
            renderPosts(posts, currentPage, postsPerPage);
            renderPagination(totalPosts, currentPage, postsPerPage);
        });

        // Initialize the page
        renderPosts(posts, currentPage, postsPerPage);
        renderPagination(totalPosts, currentPage, postsPerPage);

    </script>
</body>
</html>
