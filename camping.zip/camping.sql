-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 07, 2025 at 07:03 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `camping`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `forest_id` int(11) NOT NULL,
  `comment` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `user_id`, `forest_id`, `comment`, `created_at`) VALUES
(1, 1, 1, 'جنگل بسیار آرامش‌بخش بود و هوای آن بسیار تازه بود. پیشنهاد می‌کنم!', '2025-04-20 15:14:19'),
(2, 2, 2, 'تجربه‌ای فوق‌العاده، مخصوصاً در منطقه کنار رودخانه.', '2025-04-20 15:14:19'),
(3, 1, 2, 'جنگل بسیار خوب و خوشگل برای خانواده خیلی خوب و عالی', '2025-04-21 19:24:28');

-- --------------------------------------------------------

--
-- Table structure for table `discount_codes`
--

CREATE TABLE `discount_codes` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `discount_percentage` varchar(100) NOT NULL,
  `expiration_date` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `discount_codes`
--

INSERT INTO `discount_codes` (`id`, `code`, `discount_percentage`, `expiration_date`, `created_at`) VALUES
(1, 'ali110', '15', '2025-08-31', '2025-04-20 15:14:37'),
(2, 'camping', '20', '2025-12-31', '2025-04-20 15:14:37'),
(3, 'maherteransel', '50', '2025-12-20', '2025-04-26 18:55:45'),
(4, 'amingodarzi', '100', '2027-12-30', '2025-04-26 18:56:44'),
(5, 'hamedagaba', '100', '2027-12-30', '2025-04-26 18:56:57'),
(6, 'avine', '17', '2025-06-30', '2025-04-26 18:57:56');

-- --------------------------------------------------------

--
-- Table structure for table `forests`
--

CREATE TABLE `forests` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `location` varchar(200) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `forests`
--

INSERT INTO `forests` (`id`, `name`, `location`, `created_at`) VALUES
(1, 'جنگل المیستان', 'استان مازندران - بابل', '2025-04-20 15:13:27'),
(2, 'جنگل ابر', 'شاهرود', '2025-04-20 15:13:27'),
(3, 'جنگل ییلاقات ماسال', 'استان مازندران - گیلان', '2025-04-21 17:20:25'),
(4, 'جنگل دالخانی', 'رامسر', '2025-04-21 17:20:41'),
(5, 'کویر مرنجاب', 'استان اصفهان', '2025-04-21 17:21:01'),
(6, 'کویر لوت', 'استان‌های کرمان', '2025-04-21 17:21:16'),
(7, 'کویر زردگاه', 'استان خراسان جنوبی', '2025-04-21 17:21:31'),
(8, 'کویر ریگ جن', 'استان‌های سمنان', '2025-04-21 17:21:44'),
(9, 'کوه دماوند', 'استان البرز', '2025-04-21 17:22:08'),
(10, 'رشته کوه زاگرس', 'استان‌ کردستان', '2025-04-21 17:22:21'),
(11, 'قله الوند', 'استان همدان', '2025-04-21 17:22:35'),
(12, 'قلهٔ بینالود', 'استان خراسان رضوی', '2025-04-21 17:22:49');

-- --------------------------------------------------------

--
-- Table structure for table `forest_areas`
--

CREATE TABLE `forest_areas` (
  `id` int(11) NOT NULL,
  `forest_id` int(11) NOT NULL,
  `area_name` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `forest_areas`
--

INSERT INTO `forest_areas` (`id`, `forest_id`, `area_name`, `price`, `description`) VALUES
(1, 1, 'منطقه1', 900000.00, ''),
(2, 1, 'منطقه2', 800000.00, ''),
(3, 1, 'منطقه3', 1000000.00, ''),
(5, 1, 'منطقه5', 3800000.00, ''),
(6, 1, 'منطقه6', 2300000.00, ''),
(7, 1, 'منطقه7', 7400000.00, ''),
(8, 1, 'منطقه8', 1200000.00, ''),
(9, 1, 'منطقه9', 500000.00, ''),
(10, 1, 'منطقه10', 750000.00, ''),
(11, 1, 'منطقه11', 700000.00, ''),
(12, 1, 'منطقه12', 1100000.00, '');

-- --------------------------------------------------------

--
-- Table structure for table `reservations`
--

CREATE TABLE `reservations` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `forest_area_id` int(11) NOT NULL,
  `start_date` varchar(100) NOT NULL,
  `end_date` varchar(100) NOT NULL,
  `nights` int(11) NOT NULL,
  `total_price` bigint(20) NOT NULL,
  `discount_code` varchar(50) DEFAULT NULL,
  `extras` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `Examination` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reservations`
--

INSERT INTO `reservations` (`id`, `user_id`, `forest_area_id`, `start_date`, `end_date`, `nights`, `total_price`, `discount_code`, `extras`, `created_at`, `Examination`) VALUES
(4, 3, 1, '1404/02/06', '1404/02/08', 2, 1624000, 'ali', 'میز - هیزوم -کتری', '2025-04-26 15:56:58', 'درحال برسی...'),
(6, 1, 1, '1404/02/21', '1404/02/26', 5, 20100000, 'ali', '[{\"name\":\"چادر مسافرتی\",\"quantity\":2,\"price\":3000000},{\"name\":\"کیسه خواب\",\"quantity\":6,\"price\":600000}]', '2025-05-07 16:56:44', 'تایید شده'),
(7, 3, 1, '1404/02/17', '1404/02/20', 3, 14750000, 'ali', '[{\"name\":\"چادر مسافرتی\",\"quantity\":2,\"price\":3000000},{\"name\":\"کیسه خواب\",\"quantity\":4,\"price\":600000},{\"name\":\"ابزار پزشکی\",\"quantity\":3,\"price\":100000},{\"name\":\"اجاغ گاز/منقل\",\"quantity\":1,\"price\":150000}]', '2025-05-04 10:02:05', 'تایید شده'),
(8, 1, 1, '1404/03/01', '1404/03/14', 13, 48150000, 'ali', '[{\"name\":\"چادر مسافرتی\",\"quantity\":6,\"price\":3000000},{\"name\":\"کیسه خواب\",\"quantity\":2,\"price\":600000},{\"name\":\"قطعه چوب\",\"quantity\":1,\"price\":50000}]', '2025-05-04 09:55:30', 'تایید شده'),
(9, 1, 1, '1404/02/20', '1404/02/24', 4, 3200000, '', '[]', '2025-05-04 09:36:35', 'درحال برسی...'),
(10, 1, 1, '1404/02/13', '1404/02/18', 5, 4550000, 'ali', '', '2025-05-03 12:20:17', 'تایید شده'),
(11, 2, 1, '1404/02/06', '1404/02/08', 2, 3800000, 'ali', 'چراغ قوه - چادر مسافرتی - پاوربانک - قطعه چوب - ابزار پزشکی', '2025-04-26 16:08:57', 'تایید شده');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `phone_number` varchar(15) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `role` enum('admin','author','user') DEFAULT 'user',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `codmidi` varchar(11) NOT NULL,
  `adres` text NOT NULL,
  `email` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `phone_number`, `password`, `name`, `role`, `created_at`, `codmidi`, `adres`, `email`) VALUES
(1, '09051712900', 'adib1386', 'امیر مهدی ادیب زاده', 'admin', '2025-04-20 15:13:06', '0373173377', 'تهران خ هریور خ آذرباد پلاک 18', 'am.adibzadeh1386@gmail.com'),
(2, '09120125235', 'ali110', 'علی ابراهیمی', 'admin', '2025-04-20 15:13:06', '0028976542', '', ''),
(3, '09126010119', '1234', 'احمد', 'admin', '2025-04-21 16:33:39', '48464154684', '', 'ahmad@gmail.com'),
(8, '', 'ali12', 'اریا', 'user', '2025-05-04 09:30:11', '', '', ''),
(9, '09302886870', '1234567', 'احمد', 'user', '2025-05-04 09:35:27', '', '', ''),
(10, '09192513696', '123456789', 'علی باقالنی', 'user', '2025-05-04 09:36:12', '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `forest_id` (`forest_id`);

--
-- Indexes for table `discount_codes`
--
ALTER TABLE `discount_codes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`);

--
-- Indexes for table `forests`
--
ALTER TABLE `forests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `forest_areas`
--
ALTER TABLE `forest_areas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `forest_id` (`forest_id`);

--
-- Indexes for table `reservations`
--
ALTER TABLE `reservations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `forest_area_id` (`forest_area_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `phone_number` (`phone_number`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `discount_codes`
--
ALTER TABLE `discount_codes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `forests`
--
ALTER TABLE `forests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `forest_areas`
--
ALTER TABLE `forest_areas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `reservations`
--
ALTER TABLE `reservations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=543;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `comments_ibfk_2` FOREIGN KEY (`forest_id`) REFERENCES `forests` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `forest_areas`
--
ALTER TABLE `forest_areas`
  ADD CONSTRAINT `forest_areas_ibfk_1` FOREIGN KEY (`forest_id`) REFERENCES `forests` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `reservations`
--
ALTER TABLE `reservations`
  ADD CONSTRAINT `reservations_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `reservations_ibfk_2` FOREIGN KEY (`forest_area_id`) REFERENCES `forest_areas` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
