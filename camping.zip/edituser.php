<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "camping";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

if(!isset($_SESSION['id'])) {
    header('location: index.php');
    exit;
}

$sql="SELECT * FROM `users` WHERE `id`='".$_SESSION['id']."'";
$result = $conn->query($sql);
if ($result->num_rows == 1) {
    $row = $result->fetch_assoc();
}

if(isset($_POST["editsubmit"]))
{
    if($_POST["password"] == '')
    {
        $sql="UPDATE `users` SET `phone_number`='".$_POST["phone_number"]."',`name`='".$_POST["name"]."',`codmidi`='".$_POST["codmidi"]."',`adres`='".$_POST["adres"]."',`email`='".$_POST["email"]."' WHERE `id`='".$_SESSION['id']."'";
    }else{
        $sql="UPDATE `users` SET `phone_number`='".$_POST["phone_number"]."',`password`='".$_POST["password"]."',`name`='".$_POST["name"]."',`codmidi`='".$_POST["codmidi"]."',`adres`='".$_POST["adres"]."',`email`='".$_POST["email"]."' WHERE `id`='".$_SESSION['id']."'";
    }
    $conn->query($sql);
    header('location: Account.php');
}

?>


<!DOCTYPE html>
<html lang="en" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <!-- jQuery library -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>
    <!-- Popper JS -->
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>

    <title>کمپینگ</title>

    <link rel="stylesheet" href="Account.css">

    <!-- لوگو سایت -->
    <link rel="icon" type="img/download.jpg" sizes="192x192" href="img/camping_1f3d5 1.png">
</head>
<body>
<form method="post">
    <div class="row pl-5 pr-5 mt-5">
        <div class="col-md-12">
            <div class="cr-zard">
                <div class="inner-box">
                    <div class="row">
                        <div class="col-md-10 text-center" style="padding-right: 200px;">
                            <h4>اطلاعات شخصی</h4>
                        </div>
                        <div class="col-md-2">
                            <div class="action-btns">
                                <button class="edit">
                                    <i class="fas fa-edit"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                    <img src="img/Line long.png" width="100%" height="100%" alt="">
                    <div class="col-md-12">
                        <div class="row text-right mt-4">
                            <div class="col-md-2">نام و نام خوانوادگی:</div>
                            <div class="col-md-2"><input type="name" name="name" id="name" class="form-control" value="<?php echo $row['name']; ?>"></div>
                            <div class="col-md-2">تاریخ تولد:</div>
                            <div class="col-md-2"><input type="text" name="" id="" class="form-control" value="1386/05/21"></div>
                            <div class="col-md-2">کدملی:</div>
                            <div class="col-md-2"><input type="text" name="codmidi" id="codmidi" class="form-control" value="<?php echo $row['codmidi']; ?>"></div>
                        </div>
                        <div class="row text-right mt-5">
                            <div class="col-md-2">آدرس اینترنتی:</div>
                            <div class="col-md-2"><input type="email" name="email" id="email" class="form-control" value="<?php echo $row["email"]; ?>"></div>
                            <div class="col-md-3"></div>
                            <div class="col-md-2">شماره تلفن:</div>
                            <div class="col-md-2"><input type="phone" name="phone_number" id="phone_number" class="form-control" value="<?php echo $row['phone_number']; ?>"></div>
                        </div>
                        <div class="row text-right mt-5">
                            <div class="col-md-2">آدرس محل سکونت:</div>
                                <input type="text" name="adres" id="adres" class="form-control" value="<?php echo $row["adres"]; ?>">
                        </div>
                        <div class="row text-right mt-5">
                            <div class="col-md-2">رمز عبور:</div>
                            <div class="col-md-2"><input type="text" name="password" id="password" class="form-control"></div>
                            <div class="col-md-3"></div>
                        </div>
                        <div class="col-md-12">
                            <input type="submit" class="btn btn-warning" value="ذخیره تغیرات" id="editsubmit" name="editsubmit">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>

</body>
</html>