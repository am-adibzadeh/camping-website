<?php
require_once __DIR__ . '/vendor/autoload.php'; // بارگذاری mPDF

session_start();
if (!isset($_SESSION['id']) || !isset($_GET['id'])) {
    die('دسترسی غیرمجاز');
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "camping";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$reservation_id = intval($_GET['id']);
$user_id = intval($_SESSION['id']);

$sql = "SELECT r.*, f.name AS forest_name 
        FROM reservations r 
        JOIN forests f ON r.forest_area_id = f.id 
        WHERE r.id = $reservation_id AND r.user_id = $user_id";
$result = $conn->query($sql);

if ($result->num_rows === 0) {
    die('رزرو پیدا نشد.');
}

$row = $result->fetch_assoc();

ob_start();
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <style>
        body { font-family: 'DejaVu Sans', sans-serif; direction: rtl; background-color: #f4f7f6; color: #333; }
        .container { width: 80%; margin: auto; padding: 20px; border-radius: 8px; background-color: #fff; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
        .header { text-align: center; font-size: 24px; font-weight: bold; color: #4CAF50; margin-bottom: 20px; }
        .info { margin: 15px 0; font-size: 16px; line-height: 1.8; }
        .info span { font-weight: bold; }
        .footer { text-align: center; font-size: 12px; color: #777; margin-top: 20px; }
        .details-table { width: 100%; margin-top: 20px; border-collapse: collapse; }
        .details-table th, .details-table td { padding: 12px; border: 1px solid #ddd; text-align: right; }
        .details-table th { background-color: #f1f1f1; }
        .details-table tr:nth-child(even) { background-color: #f9f9f9; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">اطلاعات رزرو کمپینگ</div>

        <div class="info">
            <span>نام جنگل:</span> <?php echo $row['forest_name']; ?>
        </div>
        <div class="info">
            <span>تاریخ شروع:</span> <?php echo $row['start_date']; ?>
        </div>
        <div class="info">
            <span>تاریخ پایان:</span> <?php echo $row['end_date']; ?>
        </div>
        <div class="info">
            <span>تعداد شب:</span> <?php echo $row['nights']; ?>
        </div>
        <div class="info">
            <span>مبلغ کل:</span> <?php echo number_format($row['total_price'], 0, '.', ','); ?> تومان
        </div>
        <div class="info">
            <span>وضعیت بررسی:</span> <?php echo $row['Examination']; ?>
        </div>

        <table class="details-table">
            <tr>
                <th>مورد</th>
                <th>مقدار</th>
            </tr>
            <tr>
                <td>جنگل</td>
                <td><?php echo $row['forest_name']; ?></td>
            </tr>
            <tr>
                <td>تاریخ شروع</td>
                <td><?php echo $row['start_date']; ?></td>
            </tr>
            <tr>
                <td>تاریخ پایان</td>
                <td><?php echo $row['end_date']; ?></td>
            </tr>
            <tr>
                <td>تعداد شب</td>
                <td><?php echo $row['nights']; ?></td>
            </tr>
            <tr>
                <td>مبلغ کل</td>
                <td><?php echo number_format($row['total_price'], 0, '.', ','); ?> تومان</td>
            </tr>
            <tr>
                <td>وضعیت بررسی</td>
                <td><?php echo $row['Examination']; ?></td>
            </tr>
        </table>

        <div class="footer">
            <p>کمپینگ آنلاین - تمامی حقوق محفوظ است.</p>
        </div>
    </div>
</body>
</html>
<?php
$html = ob_get_clean();

$mpdf = new \Mpdf\Mpdf([
    'mode' => 'utf-8',
    'format' => 'A4',
    'default_font' => 'dejavusans',
]);

$mpdf->WriteHTML($html);
$mpdf->Output('reservation.pdf', 'I'); // نمایش در مرورگر
?>
