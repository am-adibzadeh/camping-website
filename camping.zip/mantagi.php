<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "camping";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

if(!isset($_SESSION['id'])) {
    header('location: index.php');
exit;
}
?>

<!DOCTYPE html>
<html lang="en" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <!-- jQuery library -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>
    <!-- Popper JS -->
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>

    <link rel="stylesheet" href="mantagi.css">
    <link rel="stylesheet" href="style.css">

    <title>کمپینگ</title>

    <!-- لوگو سایت -->
    <link rel="icon" type="img/download.jpg" sizes="192x192" href="img/camping_1f3d5 1.png">
</head>
<body>

<!-- هدر -->
<div class="container-fluid text-center sticky-top" style="color: #000;">
    <div class="row shadow bg-warning mt-4 p-2 mr-5 ml-5" style="border-radius: 15px; position: relative; z-index: 3;">
        <!-- عنوان کمپینگ -->
        <div class="col-md-2 pl-md-5" style="font-family: yekanBlack;">
            <h2 style="color: #000;"><b>کمپینگ</b></h2>
        </div>

        <!-- دکمه همبرگر و ورود/ثبت‌نام برای موبایل -->
        <div class="container-fluid d-md-none">
            <div class="row">
                <div class="col-10">            
                <?php
                    if (isset($_SESSION['id'])) {
                        $userId = $_SESSION['id'];
                        $sql = "SELECT * FROM users WHERE id = '$userId'";
                        $result = $conn->query($sql);
                        
                        if ($result->num_rows > 0) {
                            $row = $result->fetch_assoc();
                    ?>
                            <div class="dropdown ml-auto mt-1">
                                <a class="dropdown-toggle d-flex align-items-center" href="#" id="userDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <img src="img/icons8-user-96.png" class="ml-1" height="30px" alt="">
                                    <?php echo '<p class="persian-number pt-3">' . $row['phone_number'] . '</p>'; ?>
                                </a>
                                <div class="dropdown-menu dropdown-menu-left text-right" aria-labelledby="userDropdown">
                                    <a class="dropdown-item" href="#">اطلاعات حساب کاربری</a>
                                    <a class="dropdown-item" href="#"></a>
                                    <a class="dropdown-item" href="#">اعلان ها</a>
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item text-danger" href="logout.php">خروج</a>
                                </div>
                            </div>
                    <?php
                        }
                    } else {
                    ?>
                        <!-- دکمه ورود/ثبت‌نام برای زمانی که لاگین نیست -->
                        <div class="col-md-2 text-left pt-1 d-none d-md-block">
                            <button type="button" class="btn btn-success" onclick="document.getElementById('id01').style.display='block'">ورود / ثبت نام</button>
                        </div>
                    <?php
                    }
                    ?>                
                </div>
                <div class="col-2 text-left">
                    <button class="navbar-toggler" type="button" onclick="toggleNav()">
                        <img src="img/icons8-menu-208.png" width="20px" alt="">
                    </button>
                </div>
            </div>
        </div>

        <!-- منوی ناوبری (فقط در دسکتاپ نمایش داده شود) -->
        <div class="col-md-8 pr-md-5 pl-md-5 d-none d-md-block">
            <ul class="nav navbar justify-content-center">
                <a href="index.php"><li class="nav-item mx-5">صفحه اصلی</li></a>
                <a href="rezery.php?item=tree&time=day"><li class="nav-item mx-5">رزروکمپ</li></a>
                <a href="http://localhost:5000/" onclick="alert('این هوش مصنوعی برای کمپینگ است و به سوال‌های غیر مرتبط پاسخ نمی‌دهد.')">
                    <li class="nav-item mx-5">هوش مصنوعی <small style="font-size: 8px;color: red;">(جدید)</small></li>
                </a>
                <a href="tamasbama.php"><li class="nav-item mx-5">تماس باما</li></a>
            </ul>
        </div>

        <?php
    if (isset($_SESSION['id'])) {
        $userId = $_SESSION['id'];
        $sql = "SELECT * FROM users WHERE id = '$userId'";
        $result = $conn->query($sql);
        
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
    ?>
    <div class="dropdown ml-auto mt-1 con-desktop">
        <a class="dropdown-toggle d-flex align-items-center" href="#" id="userDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <img src="img/icons8-user-96.png" class="ml-1" height="30px" alt="">
            <?php echo '<p class="persian-number pt-3">' . $row['phone_number'] . '</p>'; ?>
        </a>
        <div class="dropdown-menu dropdown-menu-left text-right" aria-labelledby="userDropdown">
            <a class="dropdown-item" href="Account.php">اطلاعات حساب کاربری</a>
            
            <?php
            // اینجا چک میکنیم اگر نقش admin بود، لینک تنظیمات رو هم نشون بده
            if (isset($row['role']) && $row['role'] === 'admin') {
                echo '<a class="dropdown-item" href="Account.admin.php">تنظیمات</a>';
            }
            ?>

            <a class="dropdown-item" href="#">اعلان ها</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item text-danger" href="logout.php">خروج</a>
        </div>
    </div>
<?php
    }
} else {
?>
    <!-- دکمه ورود/ثبت‌نام برای زمانی که لاگین نیست -->
    <div class="col-md-2 text-left pt-1 d-none d-md-block">
        <button type="button" class="btn btn-success" onclick="document.getElementById('id01').style.display='block'">ورود / ثبت نام</button>
    </div>
<?php
}
?>

    </div>
</div>

<!-- ساید ناوبری برای موبایل -->
<div id="mySidenav" class="sidenav">
    <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
    <a href="index.php">صفحه اصلی</a>
    <a href="rezery.php">رزروکمپ</a>
    <a href="ai camping.php" onclick="alert('این هوش مصنوعی برای کمپینگ است و به سوال‌های غیر مرتبط پاسخ نمی‌دهد.')">هوش مصنوعی <small style="font-size: 8px;color: red;">(جدید)</small></a>
    <a href="">تماس باما</a>
</div>

<!-- پس‌زمینه‌ی تاریک هنگام باز شدن منوی موبایل -->
<div id="overlay" class="overlay" onclick="closeNav()"></div>




<!-- اطلاعات درخت روز -->
<div id="tree-day" class="content-section">
    <div class="container-fluid">
        <div class="row mt-4">
            <div class="col-md-1"></div>
            <!-- لیست اول (تصاویر) -->
            <ul class="col-11 col-md-10 nav navbar pb-0 d-flex justify-content-center flex-wrap mr-2">
                <li><img src="img/1.png" width="45px" class="navbar-brand" alt=""></li>
                <li><img src="img/titi-p.png" width="300px" class="navbar-brand" height="25px" alt=""></li>
                <li><img src="img/2.png" width="45px" class="navbar-brand" alt=""></li>
                <li><img src="img/titi.png" width="300px" class="navbar-brand" height="25px" alt=""></li>
                <li><img src="img/3.2.png" width="45px" class="navbar-brand" alt=""></li>
                <li><img src="img/titi.png" width="300px" class="navbar-brand" height="25px" alt=""></li>
                <li><img src="img/4.2.png" width="45px" class="navbar-brand" alt=""></li>
            </ul>
            
            <!-- لیست دوم (متن‌ها) -->
            <div class="col-md-3 pr-5 text-center con-desktop">
                <h6>انتخاب محل کمپ</h6>
            </div>
            <div class="col-md-3 text-center pr-5 con-desktop">
                <h6>انتخاب منطقه</h6>
            </div>
            <div class="col-md-3 text-center pr-5 con-desktop">
                <h6>اجاره ابزارآلات</h6>
            </div>
            <div class="col-md-3 text-center pr-5 con-desktop">
                <h6>پرداخت</h6>
            </div>
        </div>
</div>
</div>

<!-- اطلاعات درخت شب -->
<div id="tree-night" class="content-section">
    <div class="container-fluid">
        <div class="row mt-4">
            <div class="col-md-1"></div>
            <!-- لیست اول (تصاویر) -->
            <ul class="col-11 col-md-10 nav navbar pb-0 d-flex justify-content-center flex-wrap mr-2">
                <li><img src="img/1.png" width="45px" class="navbar-brand" alt=""></li>
                <li><img src="img/titi-p.png" width="300px" class="navbar-brand" height="25px" alt=""></li>
                <li><img src="img/2.png" width="45px" class="navbar-brand" alt=""></li>
                <li><img src="img/titi.png" width="300px" class="navbar-brand" height="25px" alt=""></li>
                <li><img src="img/3.2.png" width="45px" class="navbar-brand" alt=""></li>
                <li><img src="img/titi.png" width="300px" class="navbar-brand" height="25px" alt=""></li>
                <li><img src="img/4.2.png" width="45px" class="navbar-brand" alt=""></li>
            </ul>
            
            <!-- لیست دوم (متن‌ها) -->
            <div class="col-md-3 pr-5 text-center text-light con-desktop">
                <h6>انتخاب محل کمپ</h6>
            </div>
            <div class="col-md-3 text-center pr-5 text-light con-desktop">
                <h6>انتخاب منطقه</h6>
            </div>
            <div class="col-md-3 text-center pr-5 text-light con-desktop">
                <h6>اجاره ابزارآلات</h6>
            </div>
            <div class="col-md-3 text-center pr-5 text-light con-desktop">
                <h6>پرداخت</h6>
            </div>
        </div>
</div>
</div>

<!-- اطلاعات کاکتوث روز -->
<div id="cactus-day" class="content-section">
        <!-- مرحله ها -->
        <div class="container-fluid">
            <div class="row mt-4">
                <div class="col-md-1"></div>
                <!-- لیست اول (تصاویر) -->
                <ul class="col-11 col-md-10 nav navbar pb-0 d-flex justify-content-center flex-wrap mr-2">
                    <li><img src="img/1R.png" width="45px" class="navbar-brand" alt=""></li>
                    <li><img src="img/titir-p.png" width="300px" class="navbar-brand" height="25px" alt=""></li>
                    <li><img src="img/2r.png" width="45px" class="navbar-brand" alt=""></li>
                    <li><img src="img/titir.png" width="300px" class="navbar-brand" height="25px" alt=""></li>
                    <li><img src="img/3.2r.png" width="45px" class="navbar-brand" alt=""></li>
                    <li><img src="img/titir.png" width="300px" class="navbar-brand" height="25px" alt=""></li>
                    <li><img src="img/4.2r.png" width="45px" class="navbar-brand" alt=""></li>
                </ul>
                
                <!-- لیست دوم (متن‌ها) -->
                <div class="col-md-3 pr-5 text-center">
                    <h6>انتخاب محل کمپ</h6>
                </div>
                <div class="col-md-3 text-center pr-5">
                    <h6>انتخاب منطقه</h6>
                </div>
                <div class="col-md-3 text-center pr-5">
                    <h6>اجاره ابزارآلات</h6>
                </div>
                <div class="col-md-3 text-center pr-5">
                    <h6>پرداخت</h6>
                </div>
            </div>
        </div>
</div>

<!-- اطلاعات کاکتوث شب -->
<div id="cactus-night" class="content-section">
<div class="container-fluid">
        <div class="row mt-4">
            <div class="col-md-1"></div>
            <!-- لیست اول (تصاویر) -->
            <ul class="col-11 col-md-10 nav navbar pb-0 d-flex justify-content-center flex-wrap mr-2">
                <li><img src="img/1R.png" width="45px" class="navbar-brand" alt=""></li>
                <li><img src="img/titir-p.png" width="300px" class="navbar-brand" height="25px" alt=""></li>
                <li><img src="img/2r.png" width="45px" class="navbar-brand" alt=""></li>
                <li><img src="img/titir.png" width="300px" class="navbar-brand" height="25px" alt=""></li>
                <li><img src="img/3.2r.png" width="45px" class="navbar-brand" alt=""></li>
                <li><img src="img/titir.png" width="300px" class="navbar-brand" height="25px" alt=""></li>
                <li><img src="img/4.2r.png" width="45px" class="navbar-brand" alt=""></li>
            </ul>
            
            <!-- لیست دوم (متن‌ها) -->
            <div class="col-md-3 pr-5 text-center text-light">
                <h6>انتخاب محل کمپ</h6>
            </div>
            <div class="col-md-3 text-center pr-5 text-light">
                <h6>انتخاب منطقه</h6>
            </div>
            <div class="col-md-3 text-center pr-5 text-light">
                <h6>اجاره ابزارآلات</h6>
            </div>
            <div class="col-md-3 text-center pr-5 text-light">
                <h6>پرداخت</h6>
            </div>
        </div>
</div>
</div>

<!-- اطلاعات کوه روز -->
<div id="mountain-day" class="content-section">
    <!-- مرحله ها -->
    <div class="container-fluid">
        <div class="row mt-4">
            <div class="col-md-1"></div>
            <!-- لیست اول (تصاویر) -->
            <ul class="col-11 col-md-10 nav navbar pb-0 d-flex justify-content-center flex-wrap mr-2">
                <li><img src="img/1b.png" width="45px" class="navbar-brand" alt=""></li>
                <li><img src="img/titib-p.png" width="300px" class="navbar-brand" height="25px" alt=""></li>
                <li><img src="img/2b.png" width="45px" class="navbar-brand" alt=""></li>
                <li><img src="img/titib.png" width="300px" class="navbar-brand" height="25px" alt=""></li>
                <li><img src="img/3.2b.png" width="45px" class="navbar-brand" alt=""></li>
                <li><img src="img/titib.png" width="300px" class="navbar-brand" height="25px" alt=""></li>
                <li><img src="img/4.2b.png" width="45px" class="navbar-brand" alt=""></li>
            </ul>
            
            <!-- لیست دوم (متن‌ها) -->
            <div class="col-md-3 pr-5 text-center">
                <h6>انتخاب محل کمپ</h6>
            </div>
            <div class="col-md-3 text-center pr-5">
                <h6>انتخاب منطقه</h6>
            </div>
            <div class="col-md-3 text-center pr-5">
                <h6>اجاره ابزارآلات</h6>
            </div>
            <div class="col-md-3 text-center pr-5">
                <h6>پرداخت</h6>
            </div>
        </div>
    </div>
</div>

<!-- اطلاعات کوه شب -->
<div id="mountain-night" class="content-section">
    <!-- مرحله ها -->
    <div class="container-fluid">
        <div class="row mt-4">
            <div class="col-md-1"></div>
            <!-- لیست اول (تصاویر) -->
            <ul class="col-11 col-md-10 nav navbar pb-0 d-flex justify-content-center flex-wrap mr-2">
                <li><img src="img/1b.png" width="45px" class="navbar-brand" alt=""></li>
                <li><img src="img/titib-p.png" width="300px" class="navbar-brand" height="25px" alt=""></li>
                <li><img src="img/2b.png" width="45px" class="navbar-brand" alt=""></li>
                <li><img src="img/titib.png" width="300px" class="navbar-brand" height="25px" alt=""></li>
                <li><img src="img/3.2b.png" width="45px" class="navbar-brand" alt=""></li>
                <li><img src="img/titib.png" width="300px" class="navbar-brand" height="25px" alt=""></li>
                <li><img src="img/4.2b.png" width="45px" class="navbar-brand" alt=""></li>
            </ul>
            
            <!-- لیست دوم (متن‌ها) -->
            <div class="col-md-3 pr-5 text-center text-light">
                <h6>انتخاب محل کمپ</h6>
            </div>
            <div class="col-md-3 text-center pr-5 text-light">
                <h6>انتخاب منطقه</h6>
            </div>
            <div class="col-md-3 text-center pr-5 text-light">
                <h6>اجاره ابزارآلات</h6>
            </div>
            <div class="col-md-3 text-center pr-5 text-light">
                <h6>پرداخت</h6>
            </div>
        </div>
    </div>
</div>

<!-- ناحیه -->
<div class="container-fluid text-center mt-5">
    <div class="title" id="selectionTitle">یکی از ناحیه‌های زیر را انتخاب کنید</div>
    <div class="map-container">
        <div class="circle" style="top: 20%; left: 3%;" data-title="منطقه 1" data-capacity="2 نفره" data-price="900000 هزار تومان"></div>
        <div class="circle" style="top: 27%; left: 47%;" data-title="منطقه 2" data-capacity="2 نفره" data-price="800000 هزار تومان"></div>
        <div class="circle" style="top: 70%; left: 20%;" data-title="منطقه 3" data-capacity="2 نفره" data-price="1000000 میلیون تومان"></div>
        <div class="circle" style="top: 60%; left: 68%;" data-title="منطقه 4" data-capacity="8 نفره" data-price="1200000 میلیون تومان"></div>
        <div class="circle" style="top: 50%; left: 10%;" data-title="منطقه 5" data-capacity="10 نفره" data-price="3800000 میلیون تومان"></div>
        <div class="circle" style="top: 54%; left: 37%;" data-title="منطقه 6" data-capacity="6 نفره" data-price="2300000 میلیون تومان"></div>
        <div class="circle" style="top: 80%; left: 60%;" data-title="منطقه 7" data-capacity="15 نفره" data-price="7400000 میلیون تومان"></div>
        <div class="circle" style="top: 20%; left: 20%;" data-title="منطقه 8" data-capacity="4 نفره" data-price="1200000 میلیون تومان"></div>
        <div class="circle" style="top: 80%; left: 40%;" data-title="منطقه 9" data-capacity="2 نفره" data-price="500000 هزار تومن"></div>
        <div class="circle" style="top: 50%; left: 85%;" data-title="منطقه 10" data-capacity="2 نفره" data-price="750000 هزار تومن"></div>
        <div class="circle" style="top: 20%; left: 81%;" data-title="منطقه 11" data-capacity="2 نفره" data-price="700000 هزار تومن"></div>
        <div class="circle" style="top: 10%; left: 34%;" data-title="منطقه 12" data-capacity="4 نفره" data-price="1100000 میلیون تومن"></div>
    </div>
</div>
<div class="info-box" id="infoBox"></div>

<!-- انتخاب -->
<div class="container-fluid mt-5">
    <h5 style="color: red;">موقع انتخاب به نکات زیر توجه داشته باشید</h5>
    <h5 class="text-right p-2 mt-4" style="color: #6c6c69;font-family: YekanLight;">در انتخاب ناحیه دقت لازم را داشته باشید چون امکان جابجایی آن پس از خرید وجود ندارد</h5>
    <h5 class="text-right p-2" style="color: #6c6c69;font-family: YekanLight;">تعداد نفرات نوشته شده در هر ناحیه بر اساس محدوده ناحیه است</h5>
    <h5 class="text-right p-2" style="color: #6c6c69;font-family: YekanLight;">ناحیه ها بافاصله ایجاد شده تا حریم خصوصی شما رعایت شود</h5>
    <hr class="p-3">
</div>

<!-- درباره جنگل -->
<div class="container-fluid">
    <div class="row">
        <div class="col-md-1 text-center"><img src="img/Ellipse 94.png" width="15px" height="15px" class="mt-2" alt=""></div>
        <div class="col-md-11 text-right pr-0"><h2>جنگل المیستال ، <small>استان مازندران - بابل</small></h2></div>
        <div class="col-md-1 text-center mt-4"><img src="img/Line 18.png" width="5px" height="340px" alt=""></div>
        <div class="col-md-11 text-right mt-4">
            <h4 class="mt-3 p-2" style="font-family: YekanLight;font-weight: bold;">جنگل المیستال یکی از زیباترین و سرسبزترین و البته محبوب ترین جنگل های استان مازندران است . این جنگل به دلیل آب و هوای</h4>
            <h4 class="mt-4 p-2" style="font-family: YekanLight;font-weight: bold;">خنک و مرطوب و فضای سبزش میان گردشگران و کمپ کنندگان محبوبت خاصی را اینجاد کرده استاین جنگل علاوه بر درختان سبز</h4>
            <h4 class="mt-4 p-2" style="font-family: YekanLight;font-weight: bold;">و بلند دارای رود های زیبا نیز هست جنگل المیستال یکی از زیباترین و سرسبزترین و البته محبوب ترین جنگل های استان مازندران</h4>
            <h4 class="mt-4 p-2" style="font-family: YekanLight;font-weight: bold;">است . این جنگل به دلیل آب و هوای خنک و مرطوب و فضای سبزش میان گردشگران و کمپ کنندگان محبوبت خاصی را اینجاد کرده</h4>
            <h4 class="mt-4 p-2" style="font-family: YekanLight;font-weight: bold;">استاین جنگل علاوه بر درختان سبز و بلند دارای رود های زیبا نیز هست</h4>
        </div>
        <img src="img/Ellipse 94.png" width="17px" height="17px" class="mr-5" style="margin-top: 100px;" alt="">
        <h2 style="margin-top: 85px; margin-right: 15px;">مزایا و امکانات </h2>
    </div>
</div>

<!-- مزایا و امکانات -->
<div class="container-fluid">
    <div class="row">

        <div class="col-md-4 p-3 pr-5">
            <div class="codr-co p-2 pr-4 text-right">
                <div class="row">
                    <div class="col-md-6">
                        <h3>آنتن دهی</h3>
                    </div>
                    <div class="col-md-6 text-left pl-5">
                        <img src="img/icons8-cellular-network-100.png" width="45px" alt="">
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4 p-3">
            <div class="codr-co p-2 pr-4 text-right">
                <div class="row">
                    <div class="col-md-6">
                        <h3>فضای بازی</h3>
                    </div>
                    <div class="col-md-6 text-left pl-5">
                        <img src="img/Basketball Player.png" width="45px" alt="">
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4 p-3 pl-5">
            <div class="codr-co p-2 pr-4 text-right">
                <div class="row">
                    <div class="col-md-6">
                        <h3>رودخانه</h3>
                    </div>
                    <div class="col-md-6 text-left pl-5">
                        <img src="img/Sea Waves.png" width="45px" alt="">
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-4 p-3 pr-5">
            <div class="codr-co p-2 pr-4 text-right">
                <div class="row">
                    <div class="col-md-6">
                        <h3>جای پارک</h3>
                    </div>
                    <div class="col-md-6 text-left pl-5">
                        <img src="img/Parking.png" width="45px" alt="">
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4 p-3">
            <div class="codr-co p-2 pr-4 text-right">
                <div class="row">
                    <div class="col-md-6">
                        <h3>چراغ سراسری</h3>
                    </div>
                    <div class="col-md-6 text-left pl-5">
                        <img src="img/Lights.png" width="45px" alt="">
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4 p-3 pl-5">
            <div class="codr-co p-2 pr-4 text-right">
                <div class="row">
                    <div class="col-md-6">
                        <h3>فضای سبز</h3>
                    </div>
                    <div class="col-md-6 text-left pl-5">
                        <img src="img/Evergreen.png" width="45px" alt="">
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-4 p-3 pr-5">
            <div class="codr-co p-2 pr-4 text-right">
                <div class="row">
                    <div class="col-md-6">
                        <h3>ابزار حریق</h3>
                    </div>
                    <div class="col-md-6 text-left pl-5">
                        <img src="img/Fire Extinguisher.png" width="45px" alt="">
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4 p-3">
            <div class="codr-co p-2 pr-4 text-right">
                <div class="row">
                    <div class="col-md-8">
                        <h3>سرویس بهداشتی</h3>
                    </div>
                    <div class="col-md-4 text-left pl-5">
                        <img src="img/Portable Toilet.png" width="45px" alt="">
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4 p-3 pl-5">
            <div class="codr-co p-2 pr-4 text-right">
                <div class="row">
                    <div class="col-md-8">
                        <h3>فضای حفاظت شده</h3>
                    </div>
                    <div class="col-md-4 text-left pl-5">
                        <img src="img/Approved Unlock.png" width="45px" alt="">
                    </div>
                </div>
            </div>
        </div>
        <img src="img/Ellipse 94.png" width="17px" height="17px" class="mr-5" style="margin-top: 100px;" alt="">
        <h2 style="margin-top: 85px; margin-right: 15px;">تاریخ اسکان</h2>
    </div>
</div>

<div id="calendar-container">
    <div class="container">
        <div class="header">
            <div onclick="prevMonth()" style="cursor: pointer; border: 1px solid #00796b; border-radius: 25%; padding: 12px;">
                <img src="img/Back2.png" style="width: 18px;" alt="">
            </div>
            <h3 id="month-year"></h3>
            <div onclick="nextMonth()" style="cursor: pointer; border: 1px solid #00796b; border-radius: 25%; padding: 12px;">
                <img src="img/Back.png" style="width: 18px;" alt="">
            </div>
        </div>
    
        <table>
            <thead>
            <tr>
                <th>ش</th>
                <th>ی</th>
                <th>د</th>
                <th>س</th>
                <th>چ</th>
                <th>پ</th>
                <th>ج</th>
            </tr>
            </thead>
            <tbody id="calendar">
            </tbody>
        </table>
        <p id="result"></p>
            <!-- اطلاعات منطقه انتخابی -->
        <div id="selected-area-info" style="margin-top: 20px; text-align: center; display: none;">
            <h4 id="area-title"></h4>
            <p id="area-capacity"></p>
            <p id="area-price"></p>
        </div>
    </div>
</div>

<!-- تایید -->
<a href="abzar.php">
    <div class="btn text-light mb-5" id="next-step" style="background-color: #ff6b01;width: 230px; border-radius: 8px; margin-top: 100px;">تایید و ادامه</div>
</a>

</body>
<script src="https://cdn.jsdelivr.net/npm/jalali-moment@3.3.10/dist/jalali-moment.browser.js"></script>
<script>
    // 
    // رنگ
    // بررسی URL برای گرفتن پارامتر مربوط به دکمه‌ای که کلیک شده
    window.onload = function() {
            const params = new URLSearchParams(window.location.search);  // گرفتن پارامترهای URL

            // گرفتن پارامتر مربوط به دکمه انتخابی (درخت، کاکتوث، یا کوه)
            const item = params.get('item');  
            const time = params.get('time');  // زمان (روز یا شب)

            // مخفی کردن همه بخش‌ها ابتدا
            document.querySelectorAll('.content-section').forEach((section) => {
                section.style.display = 'none';
            });

            // تغییر پس‌زمینه به رنگ شب در صورت انتخاب شب
            if (time === 'night') {
                document.body.style.backgroundColor = '#1b213b'; // تغییر پس‌زمینه به رنگ شب
            }

            // نمایش اطلاعات خاص بر اساس پارامترهای گرفته شده
            if (item && time) {
                const elementId = `${item}-${time}`;  // ترکیب دکمه و زمان (مثلا tree-day)
                const selectedElement = document.getElementById(elementId);
                if (selectedElement) {
                    selectedElement.style.display = 'block';
                }
            }
        };

    // نقشه
const circles = document.querySelectorAll('.circle');
const infoBox = document.getElementById('infoBox');
const selectionTitle = document.getElementById('selectionTitle');

let selectedCircle = null;

// انتخاب منطقه و نمایش اطلاعات آن
circles.forEach(circle => {
    circle.addEventListener('mouseenter', () => {
        const title = circle.getAttribute('data-title');
        const capacity = circle.getAttribute('data-capacity');
        const price = circle.getAttribute('data-price');

        infoBox.innerHTML = `<strong>${title}</strong><br>ظرفیت: ${capacity}<br>قیمت: ${price}`;
        infoBox.style.display = 'block';
    });

    circle.addEventListener('mouseleave', () => {
        infoBox.style.display = 'none';
    });

    circle.addEventListener('mousemove', (e) => {
        const rect = circle.getBoundingClientRect();
        const offsetX = e.clientX - rect.left; // موقعیت موس داخل دایره
        const offsetY = e.clientY - rect.top;

        infoBox.style.top = `${rect.top + offsetY + window.scrollY}px`;
        infoBox.style.left = `${rect.left + offsetX + 15 + window.scrollX}px`; // فاصله کمی از موس
    });

    // وقتی روی دایره کلیک می‌شود، منطقه انتخاب شده را ذخیره کرده و اطلاعات آن را نمایش می‌دهیم
    circle.addEventListener('click', () => {
        if (selectedCircle) {
            selectedCircle.classList.remove('active');
        }
        circle.classList.add('active');
        selectedCircle = circle;

        const areaName = circle.getAttribute('data-title');
        const capacity = circle.getAttribute('data-capacity');
        const price = circle.getAttribute('data-price');

        // نمایش اطلاعات منطقه در پایین تقویم
        document.getElementById('area-title').innerText = `منطقه انتخاب شده: ${areaName}`;
        document.getElementById('area-capacity').innerText = `ظرفیت: ${capacity}`;
        document.getElementById('area-price').innerText = `قیمت: ${price}`;

        // نمایش بخش اطلاعات منطقه
        document.getElementById('selected-area-info').style.display = 'block';

        // تغییر عنوان بالا به نام منطقه انتخابی
        selectionTitle.textContent = `${areaName} انتخاب شد`;
        selectionTitle.style.color = 'green';
    });
});

// 
// تقویم و انتخاب تاریخ
const monthYear = document.getElementById('month-year');
const calendar = document.getElementById('calendar');
const result = document.getElementById('result');

let startDate = null;
let endDate = null;
let currentMonth = moment().jMonth();
let currentYear = moment().jYear();

const monthNames = [
    'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
    'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'
];

const holidays = [
    { month: 0, day: 1 },  // 1 فروردین (عید نوروز)
    { month: 0, day: 2 },  // 2 فروردین (عید نوروز)
    { month: 0, day: 13 }, // 13 فروردین (روز طبیعت)
    { month: 10, day: 22 }, // 22 بهمن (سالگرد انقلاب اسلامی)
    { month: 6, day: 9 },   // 9 مهر (عاشورا)
    { month: 6, day: 10 },  // 10 مهر (تاسوعا)
];

let today = moment().startOf('day');
let maxReservationDate = moment().add(45, 'days').endOf('day');

function toPersianNumber(num) {
    return num.toString().replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[d]);
}

function renderCalendar() {
    calendar.innerHTML = '';
    monthYear.innerText = `${monthNames[currentMonth]} ${toPersianNumber(currentYear)}`;

    let firstDay = moment(`${currentYear}/${currentMonth + 1}/1`, 'jYYYY/jM/jD').weekday();
    firstDay = (firstDay + 1) % 7; // اصلاح نمایش از شنبه
    let daysInMonth = moment(`${currentYear}/${currentMonth + 1}/1`, 'jYYYY/jM/jD').jDaysInMonth();

    let day = 1;
    for (let i = 0; i < 6; i++) {
        const row = document.createElement('tr');
        for (let j = 0; j < 7; j++) {
            const cell = document.createElement('td');
            if (i === 0 && j < firstDay) {
                cell.innerText = '';
            } else if (day <= daysInMonth) {
                cell.innerText = toPersianNumber(day);  // اعداد فارسی
                cell.dataset.day = day;

                let cellDate = moment(`${currentYear}/${currentMonth + 1}/${day}`, 'jYYYY/jM/jD');
                if (cellDate.isBefore(today, 'day')) {
                    cell.classList.add('disabled', 'past');
                } else if (cellDate.isAfter(maxReservationDate, 'day')) {
                    cell.classList.add('disabled', 'future');
                }

                // روزهای تعطیل را به رنگ قرمز نمایش بده
                if (holidays.some(holiday => holiday.month === currentMonth && holiday.day === day)) {
                    cell.classList.add('holiday');
                }
                
                // پررنگ کردن تاریخ شروع
                if (startDate && currentMonth === moment(startDate).jMonth() && day === moment(startDate).jDate()) {
                    cell.classList.add('selected', 'start-date');
                }

                // پررنگ کردن تاریخ پایان
                if (endDate && currentMonth === moment(endDate).jMonth() && day === moment(endDate).jDate()) {
                    cell.classList.add('selected', 'end-date');
                }

                // فقط تاریخ‌های بین تاریخ‌های انتخابی را پررنگ کنیم
                if (startDate && endDate && day > moment(startDate).jDate() && day < moment(endDate).jDate() && currentMonth === moment(startDate).jMonth()) {
                    cell.classList.add('range');
                }

                cell.addEventListener('click', () => handleDateClick(cell));
                day++;
            }
            row.appendChild(cell);
        }
        calendar.appendChild(row);
    }
}

function handleDateClick(cell) {
    if (cell.classList.contains('disabled')) {
        return;
    }

    const dayNumber = parseInt(cell.dataset.day);

    // اگر هیچ تاریخی انتخاب نشده باشد
    if (!startDate) {
        startDate = moment(`${currentYear}/${currentMonth + 1}/${dayNumber}`, 'jYYYY/jM/jD');
        cell.classList.add('selected');
        clearSelection();  // تاریخ‌های قبلی را پاک می‌کنیم
    } else if (startDate && !endDate) {
        endDate = moment(`${currentYear}/${currentMonth + 1}/${dayNumber}`, 'jYYYY/jM/jD');

        // اصلاح ترتیب تاریخ‌ها
        if (endDate.isBefore(startDate)) {
            [startDate, endDate] = [endDate, startDate];
        }

        markRange();
        let startDateFormatted = toPersianNumber(startDate.jDate());
        let endDateFormatted = toPersianNumber(endDate.jDate());
        let daysBetween = endDate.diff(startDate, 'days') + 1;
        result.innerText = `رزرو از ${startDateFormatted} ${monthNames[currentMonth]} تا ${endDateFormatted} ${monthNames[currentMonth]}، تعداد روزها: ${toPersianNumber(daysBetween)} روز`;
    } else {
        // اگر تاریخ شروع و پایان انتخاب شده است، تاریخ جدیدی را به عنوان تاریخ شروع انتخاب می‌کنیم
        startDate = moment(`${currentYear}/${currentMonth + 1}/${dayNumber}`, 'jYYYY/jM/jD');
        endDate = null;
        result.innerText = '';
        renderCalendar();
    }
}

function markRange() {
    const cells = calendar.getElementsByTagName('td');
    Array.from(cells).forEach(cell => {
        const cellDay = parseInt(cell.dataset.day);
        if (startDate && endDate) {
            if (cellDay > moment(startDate).jDate() && cellDay < moment(endDate).jDate()) {
                cell.classList.add('range');
            }
        }
    });
    renderCalendar();
}

function clearSelection() {
    const cells = calendar.getElementsByTagName('td');
    Array.from(cells).forEach(cell => cell.classList.remove('selected', 'range'));
}

function prevMonth() {
    currentMonth--;
    if (currentMonth < 0) {
        currentMonth = 11;
        currentYear--;
    }
    renderCalendar();
}

function nextMonth() {
    currentMonth++;
    if (currentMonth > 11) {
        currentMonth = 0;
        currentYear++;
    }
    renderCalendar();
}

renderCalendar();


document.getElementById("next-step").addEventListener("click", function() {
    // بررسی اینکه آیا ناحیه‌ای انتخاب شده یا خیر
    if (selectedCircle) {
        // گرفتن اطلاعات از دایره انتخاب شده
        const areaTitle = selectedCircle.getAttribute("data-title");
        const areaCapacity = selectedCircle.getAttribute("data-capacity");
        const areaPrice = selectedCircle.getAttribute("data-price");


        // ذخیره کردن اطلاعات ناحیه در localStorage
        localStorage.setItem("areaTitle", areaTitle);
        localStorage.setItem("areaCapacity", areaCapacity);
        localStorage.setItem("areaPrice", areaPrice);

        // ذخیره کردن تاریخ شروع و پایان در localStorage
if (startDate) {
    localStorage.setItem("startDate", startDate.format('jYYYY/jMM/jDD'));
}
if (endDate) {
    localStorage.setItem("endDate", endDate.format('jYYYY/jMM/jDD'));
}
        // انتقال به صفحه بعدی
        window.location.href = "abzar.php";  // فرض کنید صفحه دوم به نام 3.php است
    } else {
        alert("لطفاً یک ناحیه انتخاب کنید.");
    }
});

//    
// فارسی کردن عدد
function convertNumbersToPersian() {
    const persianNumbers = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
    document.querySelectorAll('.persian-number').forEach(el => {
        el.innerHTML = el.innerHTML.replace(/\d/g, d => persianNumbers[d]);
    });
}

// وقتی صفحه لود شد اعداد فارسی شوند
document.addEventListener("DOMContentLoaded", convertNumbersToPersian);     

// 
</script>
</html>