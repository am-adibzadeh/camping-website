<!DOCTYPE html>
<html lang="en" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <!-- jQuery library -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>
    <!-- Popper JS -->
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>

    <title>کمپینگ</title>
    <link rel="stylesheet" href="style.css">

    <!-- لوگو سایت -->
    <link rel="icon" type="img/download.jpg" sizes="192x192" href="img/camping_1f3d5 1.png">
</head>
<body class="text-center">
    
<!-- اطلاعات درخت روز -->
<div id="tree-day" class="content-section">
    <div class="container-fluid">
        <div class="row mt-4">
            <div class="col-md-1"></div>
            <!-- لیست اول (تصاویر) -->
            <ul class="col-11 col-md-10 nav navbar pb-0 d-flex justify-content-center flex-wrap mr-2">
                <li><img src="img/1.png" width="45px" class="navbar-brand" alt=""></li>
                <li><img src="img/titi-p.png" width="300px" class="navbar-brand" height="25px" alt=""></li>
                <li><img src="img/2r.png" width="45px" class="navbar-brand" alt=""></li>
                <li><img src="img/titir-p.png" width="300px" class="navbar-brand" height="25px" alt=""></li>
                <li><img src="img/3b.png" width="45px" class="navbar-brand" alt=""></li>
                <li><img src="img/titib-p.png" width="300px" class="navbar-brand" height="25px" alt=""></li>
                <li><img src="img/4r.png" width="45px" class="navbar-brand" alt=""></li>
            </ul>
            
            <!-- لیست دوم (متن‌ها) -->
            <div class="col-md-3 pr-5 text-center">
                <h6>انتخاب محل کمپ</h6>
            </div>
            <div class="col-md-3 text-center pr-5">
                <h6>انتخاب منطقه</h6>
            </div>
            <div class="col-md-3 text-center pr-5">
                <h6>اجاره ابزارآلات</h6>
            </div>
            <div class="col-md-3 text-center pr-5">
                <h6>پرداخت</h6>
            </div>
        </div>
</div>
</div>


<a href=""><div class="btn btn-outline-success" style="font-size: 70px;border-radius: 20px; margin-top: 20%;">تایید پردخت</div></a>


</body>
</html>