<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "camping";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
if (!isset($_SESSION['id'])) {
    header('location: index.php');
    exit;
}
if (isset($_POST["submit"])) {
    // دریافت مقادیر از فرم
    $start_date = $_POST['start_date'] ?? 0;
    $end_date = $_POST['end_date'] ?? 0;
    $nights = $_POST['nights'] ?? 0;
    $total_price = $_POST['total_price'] ?? 0;
    $discount_code = $_POST['discount_code'] ?? null;
    $extras = $_POST['extras'] ?? null;
    $forest_area_id = 1; // مقدار پیش‌فرض، باید مطمئن شوید که این ID در جدول forest_areas وجود دارد
    // بررسی وجود forest_area_id
    $checkStmt = $conn->prepare("SELECT COUNT(*) FROM forest_areas WHERE id = ?");
    $checkStmt->bind_param("i", $forest_area_id);
    $checkStmt->execute();
    $checkStmt->bind_result($count);
    $checkStmt->fetch();
    $checkStmt->close();
    if ($count > 0) {
        // اگر forest_area_id معتبر است، ادامه با درج
        $stmt = $conn->prepare("INSERT INTO reservations (user_id, start_date, end_date, nights, total_price, discount_code, extras, forest_area_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ississss", $_SESSION['id'], $start_date, $end_date, $nights, $total_price, $discount_code, $extras, $forest_area_id);
        
        if ($stmt->execute()) {
            echo "<script>
                alert('رزرو با موفقیت انجام شد');
                window.location.href = 'account.php';
            </script>";
            exit; // اضافه کردن exit برای اطمینان از توقف اجرای کد پس از انتقال
        } else {
            echo "<script>
                alert('خطا در انجام رزرو: " . addslashes($stmt->error) . "');
                window.location.href = 'account.php';
            </script>";
            exit; // اضافه کردن exit برای اطمینان از توقف اجرای کد پس از نمایش خطا
        }
    } else {
        echo "<script>alert('ناحیه انتخاب شده معتبر نیست.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <!-- jQuery library -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>
    <!-- Popper JS -->
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>

    <link rel="stylesheet" href="abzar.css">
    <link rel="stylesheet" href="style.css">

    <title>کمپینگ</title>

    <!-- لوگو سایت -->
    <link rel="icon" type="img/download.jpg" sizes="192x192" href="img/camping_1f3d5 1.png">
</head>
<body>

<!-- هدر -->
<div class="container-fluid text-center sticky-top" style="color: #000;">
    <div class="row shadow bg-warning mt-4 p-2 mr-5 ml-5" style="border-radius: 15px; position: relative; z-index: 3;">
        <!-- عنوان کمپینگ -->
        <div class="col-md-2 pl-md-5" style="font-family: yekanBlack;">
            <h2 style="color: #000;"><b>کمپینگ</b></h2>
        </div>

        <!-- دکمه همبرگر و ورود/ثبت‌نام برای موبایل -->
        <div class="container-fluid d-md-none">
            <div class="row">
                <div class="col-10">            
                <?php
                    if (isset($_SESSION['id'])) {
                        $userId = $_SESSION['id'];
                        $sql = "SELECT * FROM users WHERE id = '$userId'";
                        $result = $conn->query($sql);
                        
                        if ($result->num_rows > 0) {
                            $row = $result->fetch_assoc();
                    ?>
                            <div class="dropdown ml-auto mt-1">
                                <a class="dropdown-toggle d-flex align-items-center" href="#" id="userDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <img src="img/icons8-user-96.png" class="ml-1" height="30px" alt="">
                                    <?php echo '<p class="persian-number pt-3">' . $row['phone_number'] . '</p>'; ?>
                                </a>
                                <div class="dropdown-menu dropdown-menu-left text-right" aria-labelledby="userDropdown">
                                    <a class="dropdown-item" href="#">اطلاعات حساب کاربری</a>
                                    <a class="dropdown-item" href="#"></a>
                                    <a class="dropdown-item" href="#">اعلان ها</a>
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item text-danger" href="logout.php">خروج</a>
                                </div>
                            </div>
                    <?php
                        }
                    } else {
                    ?>
                        <!-- دکمه ورود/ثبت‌نام برای زمانی که لاگین نیست -->
                        <div class="col-md-2 text-left pt-1 d-none d-md-block">
                            <button type="button" class="btn btn-success" onclick="document.getElementById('id01').style.display='block'">ورود / ثبت نام</button>
                        </div>
                    <?php
                    }
                    ?>                
                </div>
                <div class="col-2 text-left">
                    <button class="navbar-toggler" type="button" onclick="toggleNav()">
                        <img src="img/icons8-menu-208.png" width="20px" alt="">
                    </button>
                </div>
            </div>
        </div>

        <!-- منوی ناوبری (فقط در دسکتاپ نمایش داده شود) -->
        <div class="col-md-8 pr-md-5 pl-md-5 d-none d-md-block">
            <ul class="nav navbar justify-content-center">
                <a href="index.php"><li class="nav-item mx-5">صفحه اصلی</li></a>
                <a href="rezery.php?item=tree&time=day"><li class="nav-item mx-5">رزروکمپ</li></a>
                <a href="ai camping.php" onclick="alert('این هوش مصنوعی برای کمپینگ است و به سوال‌های غیر مرتبط پاسخ نمی‌دهد.')">
                    <li class="nav-item mx-5">هوش مصنوعی <small style="font-size: 8px;color: red;">(جدید)</small></li>
                </a>
                <a href="tamasbama.php"><li class="nav-item mx-5">تماس باما</li></a>
            </ul>
        </div>

<?php
if (isset($_SESSION['id'])) {
    $userId = $_SESSION['id'];
    $sql = "SELECT * FROM users WHERE id = '$userId'";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
?>
        <div class="dropdown ml-auto mt-1 con-desktop">
            <a class="dropdown-toggle d-flex align-items-center" href="#" id="userDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <img src="img/icons8-user-96.png" class="ml-1" height="30px" alt="">
                <?php echo '<p class="persian-number pt-3">' . $row['phone_number'] . '</p>'; ?>
            </a>
            <div class="dropdown-menu dropdown-menu-left text-right" aria-labelledby="userDropdown">
                <a class="dropdown-item" href="Account.php">اطلاعات حساب کاربری</a>
                <a class="dropdown-item" href="#"></a>
                <a class="dropdown-item" href="#">اعلان ها</a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item text-danger" href="logout.php">خروج</a>
            </div>
        </div>
<?php
    }
} else {
?>
    <!-- دکمه ورود/ثبت‌نام برای زمانی که لاگین نیست -->
    <div class="col-md-2 text-left pt-1 d-none d-md-block">
        <button type="button" class="btn btn-success" onclick="document.getElementById('id01').style.display='block'">ورود / ثبت نام</button>
    </div>
<?php
}
?>

    </div>
</div>

<!-- ساید ناوبری برای موبایل -->
<div id="mySidenav" class="sidenav">
    <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
    <a href="index.php">صفحه اصلی</a>
    <a href="rezery.php">رزروکمپ</a>
    <a href="ai camping.php" onclick="alert('این هوش مصنوعی برای کمپینگ است و به سوال‌های غیر مرتبط پاسخ نمی‌دهد.')">هوش مصنوعی <small style="font-size: 8px;color: red;">(جدید)</small></a>
    <a href="">تماس باما</a>
</div>

<!-- پس‌زمینه‌ی تاریک هنگام باز شدن منوی موبایل -->
<div id="overlay" class="overlay" onclick="closeNav()"></div>


<a href="Account.php"></a>


<!-- اطلاعات همه با هم -->
<div id="tree-day" class="content-section">
    <div class="container-fluid">
        <div class="row mt-4">
            <div class="col-md-1"></div>
            <!-- لیست اول (تصاویر) -->
            <ul class="col-11 col-md-10 nav navbar pb-0 d-flex justify-content-center flex-wrap mr-2">
                <li><img src="img/1.png" width="45px" class="navbar-brand" alt=""></li>
                <li><img src="img/titi-p.png" width="300px" class="navbar-brand" height="25px" alt=""></li>
                <li><img src="img/2r.png" width="45px" class="navbar-brand" alt=""></li>
                <li><img src="img/titir-p.png" width="300px" class="navbar-brand" height="25px" alt=""></li>
                <li><img src="img/3b.png" width="45px" class="navbar-brand" alt=""></li>
                <li><img src="img/tititb-p.png" width="300px" class="navbar-brand" height="25px" alt=""></li>
                <li><img src="img/4r.png" width="45px" class="navbar-brand" alt=""></li>
            </ul>
            
            <!-- لیست دوم (متن‌ها) -->
            <div class="col-md-3 pr-5 text-center">
                <h6>انتخاب محل کمپ</h6>
            </div>
            <div class="col-md-3 text-center pr-5">
                <h6>انتخاب منطقه</h6>
            </div>
            <div class="col-md-3 text-center pr-5">
                <h6>اجاره ابزارآلات</h6>
            </div>
            <div class="col-md-3 text-center pr-5">
                <h6>پرداخت</h6>
            </div>
        </div>
</div>
</div>

<!-- اطلاعیه -->
<div class="container-fluid text-center" style="margin-top: 70px;">
    <div class="row">
        <div class="col-md-1 text-left">
            <img src="img/Line 18.png" height="180px" width="5px" alt="">
        </div>
        <div class="col-md-11 text-right">
            <h4 class="p-2 pb-4">شما کاربر گرامی میتوانید در این بخش ابزارآلات مورد نیاز خود را انتخاب و به تعداد دلخواه آن ها را برای خود در تعداد روز های</h4>
            <h4 class="p-2 pb-4">تعین شده اجاره کنید. مزییت این کار این است که شما برای این سفر نیاز به خرید تجهیزات گران ندارید و با اجاره آن با قیمت</h4>
            <h4 class="p-2 pb-4">خیلی کم می توانید تجربه لذت بهش برای خود و همسفرانتان ایجاد کنید.</h4>
        </div>
    </div>
    <hr>
</div>

<!-- تجهیزات -->
<div class="container-fluid mt-4">
    <div class="row">
        <div class="col-md-1"></div>
        <div class="col-md-2 mb-4 mr-3" id="wood">
            <div class="product-card">
                <img src="img/tent_26fa.png" width="100px" alt="چادر مسافرتی">
                <h4 class="mt-2">چادر مسافرتی</h4>
                <img src="img/menha.png" class="pt-3 pb-3" width="25px" onclick="updateQuantity('wood', -1)" alt="">
                <span id="qty-wood" class="font-weight-bold p-2">0</span>
                <img src="img/balave.png" onclick="updateQuantity('wood', 1)" width="25px" alt="">
            </div>
        </div>
        <div class="col-md-2 mb-4" id="water">
            <div class="product-card">
                <img src="img/bed_1f6cf-fe0f.png" width="100px" alt="کیسه خواب">
                <h4 class="mt-2">کیسه خواب</h4>
                <img src="img/menha.png" class="pt-3 pb-3" width="25px" onclick="updateQuantity('water', -1)" alt="">
                <span id="qty-water" class="font-weight-bold p-2">0</span>
                <img src="img/balave.png" onclick="updateQuantity('water', 1)" width="25px" alt="">
            </div>
        </div>
        <div class="col-md-2 mb-4" id="charcoal">
            <div class="product-card">
                <img src="img/pill_1f48a.png" width="100px" alt="ابزار پزشکی">
                <h4 class="mt-2">ابزار پزشکی</h4>
                <img src="img/menha.png" class="pt-3 pb-3" width="25px" onclick="updateQuantity('charcoal', -1)" alt="">
                <span id="qty-charcoal" class="font-weight-bold p-2">0</span>
                <img src="img/balave.png" onclick="updateQuantity('charcoal', 1)" width="25px" alt="">
            </div>
        </div>
        <div class="col-md-2 mb-4" id="flashlight">
            <div class="product-card">
                <img src="img/flashlight_1f526.png" width="100px" alt="چراغ قوه">
                <h4 class="mt-2">چراغ قوه</h4>
                <img src="img/menha.png" class="pt-3 pb-3" width="25px" onclick="updateQuantity('flashlight', -1)" alt="">
                <span id="qty-flashlight" class="font-weight-bold p-2">0</span>
                <img src="img/balave.png" onclick="updateQuantity('flashlight', 1)" width="25px" alt="">
            </div>
        </div>
        <div class="col-md-2 mb-4" id="paverbank">
            <div class="product-card">
                <img src="img/battery_1f50b.png" width="100px" alt="پاوربانک">
                <h4 class="mt-2">پاوربانک</h4>
                <img src="img/menha.png" class="pt-3 pb-3" width="25px" onclick="updateQuantity('paverbank', -1)" alt="">
                <span id="qty-paverbank" class="font-weight-bold p-2">0</span>
                <img src="img/balave.png" onclick="updateQuantity('paverbank', 1)" width="25px" alt="">
            </div>
        </div>
        <div class="col-md-1"></div>

        <div class="col-md-2 mb-4 mr-3" id="sandali">
            <div class="product-card">
                <img src="img/chair_1fa91.png" width="100px" alt="صندلی">
                <h4 class="mt-2">صندلی</h4>
                <img src="img/menha.png" class="pt-3 pb-3" width="25px" onclick="updateQuantity('sandali', -1)" alt="">
                <span id="qty-sandali" class="font-weight-bold p-2">0</span>
                <img src="img/balave.png" onclick="updateQuantity('sandali', 1)" width="25px" alt="">
            </div>
        </div>
        <div class="col-md-2 mb-4" id="meiz">
            <div class="product-card">
                <img src="img/fork-and-knife-with-plate_1f37d-fe0f.png" width="100px" alt="میز">
                <h4 class="mt-2">میز</h4>
                <img src="img/menha.png" class="pt-3 pb-3" width="25px" onclick="updateQuantity('meiz', -1)" alt="">
                <span id="qty-meiz" class="font-weight-bold p-2">0</span>
                <img src="img/balave.png" onclick="updateQuantity('meiz', 1)" width="25px" alt="">
            </div>
        </div>
        <div class="col-md-2 mb-4" id="shoba">
            <div class="product-card">
                <img src="img/wood_1fab5.png" width="100px" alt="قطعه چوب">
                <h4 class="mt-2">قطعه چوب</h4>
                <img src="img/menha.png" class="pt-3 pb-3" width="25px" onclick="updateQuantity('shoba', -1)" alt="">
                <span id="qty-shoba" class="font-weight-bold p-2">0</span>
                <img src="img/balave.png" onclick="updateQuantity('shoba', 1)" width="25px" alt="">
            </div>
        </div>
        <div class="col-md-2 mb-4" id="gaazz">
            <div class="product-card">
                <img src="img/fire_1f525.png" width="100px" alt="اجاغ گاز/منقل">
                <h4 class="mt-2">اجاغ گاز/منقل</h4>
                <img src="img/menha.png" class="pt-3 pb-3" width="25px" onclick="updateQuantity('gaazz', -1)" alt="">
                <span id="qty-gaazz" class="font-weight-bold p-2">0</span>
                <img src="img/balave.png" onclick="updateQuantity('gaazz', 1)" width="25px" alt="">
            </div>
        </div>
        <div class="col-md-2 mb-4" id="shataee">
            <div class="product-card">
                <img src="img/hot-beverage_2615.png" width="100px" alt="فلاسک چای">
                <h4 class="mt-2">فلاسک چای</h4>
                <img src="img/menha.png" class="pt-3 pb-3" width="25px" onclick="updateQuantity('shataee', -1)" alt="">
                <span id="qty-shataee" class="font-weight-bold p-2">0</span>
                <img src="img/balave.png" onclick="updateQuantity('shataee', 1)" width="25px" alt="">
            </div>
        </div>
        <div class="col-md-1"></div>
    </div>
    <h4 class="text-right mt-5 mb-4 mr-5" style="color: #939393;">!! در ابتدای سفر یک پک استارتر شامل ابزارآلات ضروری به شما هدیه داده میشود.</h4>
    <hr>
</div>

<!-- فاکتور -->
<form action="" method="post" onsubmit="prepareFormData()">
    <div class="container mt-5 pb-5">
        <div class="invoice">
            <p class="text-right" id="reservation-dates">بازه انتخابی: -</p>
            <p class="text-right" id="area-info">اطلاعات ناحیه: -</p>
            <p class="text-right" id="stay-duration">تعداد شب‌ها: -</p>
            <hr>
            <table class="table table-bordered text-right">
                <thead>
                    <tr>
                        <th>ردیف</th>
                        <th>عنوان</th>
                        <th>قیمت</th>
                        <th>تعداد</th>
                        <th>قیمت کامل</th>
                    </tr>
                </thead>
                <tbody id="cart-table"></tbody>
            </table>
            <p class="text-right total-price">مجموع کل: <span id="total-price">0</span> تومان</p>

            <!-- بخش تخفیف -->
            <div class="discount-section row">
                <input type="text" id="discount-code" name="discount_code" class="form-control" placeholder="کد تخفیف را وارد کنید">
                <label class="discount-btn" onclick="applyDiscount()">اعمال کد تخفیف</label>
            </div>
            <p id="discount-message" class="text-right mt-3"></p>

            <!-- فیلدهای مخفی برای ارسال داده‌ها -->
            <input type="hidden" name="start_date" id="start-date-input">
            <input type="hidden" name="end_date" id="end-date-input">
            <input type="hidden" name="nights" id="nights-input">
            <input type="hidden" name="total_price" id="total-price-input">
            <input type="hidden" name="extras" id="extras-input">

            <div class="form-check text-right mb-3">
                <input class="form-check-input" type="checkbox" id="accept-rules">
                <label class="form-check-label mr-3" for="accept-rules">مقررات را قبول دارم</label>
            </div>
            <div class="text-center">
                <button class="btn pay-btn text-center" type="submit" name="submit" id="submit" disabled>پرداخت</button>
            </div>
        </div>
    </div>
</form>

<script>
    const productPrices = {
        wood: 3000000,
        water: 600000,
        charcoal: 100000,
        flashlight: 250000,
        paverbank: 2000000,
        sandali: 580000,
        meiz: 600000,
        shoba: 50000,
        gaazz: 150000,
        shataee: 24000
    };

    const discountCodes = {
        "camp": 2500000,
        "ali": 1000000,
        "mehran": 50000,
        "camp1405": 200000
    };

    let appliedDiscounts = [];
    let currentTotalPrice = 0;

    function formatPrice(price) {
        return price.toLocaleString('fa-IR');
    }

    function updateQuantity(id, change) {
        let qtyElement = document.getElementById(`qty-${id}`);
        let currentQty = parseInt(qtyElement.innerText);
        let newQty = Math.max(0, currentQty + change);
        qtyElement.innerText = newQty;
        renderCart();

        if (change > 0) {
            document.getElementById(id).classList.add("add-to-cart");
            setTimeout(() => {
                document.getElementById(id).classList.remove("add-to-cart");
            }, 500);
        } else if (change < 0) {
            document.getElementById(id).classList.add("remove-from-cart");
            setTimeout(() => {
                document.getElementById(id).classList.remove("remove-from-cart");
            }, 500);
        }
    }

    function renderCart() {
        let cartTable = "";
        let totalPrice = 0;
        let rowNumber = 1;
        let extras = [];

        const areaPrice = parseInt(localStorage.getItem("areaPrice"));
        const stayDuration = parseInt(document.getElementById("stay-duration").innerText.split(":")[1]?.trim() || 0);

        if (areaPrice && stayDuration) {
            const totalAreaPrice = areaPrice * stayDuration;
            cartTable += `
                <tr class="table-row">
                    <td>${rowNumber++}</td>
                    <td>${localStorage.getItem("areaTitle")}</td>
                    <td>${formatPrice(areaPrice)} تومان</td>
                    <td>${stayDuration} شب</td>
                    <td>${formatPrice(totalAreaPrice)} تومان</td>
                </tr>
            `;
            totalPrice += totalAreaPrice;
        }

        Object.keys(productPrices).forEach(id => {
            let quantity = parseInt(document.getElementById(`qty-${id}`).innerText);
            if (quantity > 0) {
                let total = quantity * productPrices[id];
                totalPrice += total;
                cartTable += `
                    <tr class="table-row">
                        <td>${rowNumber++}</td>
                        <td>${document.querySelector(`#${id} h4`).innerText}</td>
                        <td>${formatPrice(productPrices[id])} تومان</td>
                        <td>${quantity}</td>
                        <td>${formatPrice(total)} تومان</td>
                    </tr>
                `;
                
                // اضافه کردن به لیست تجهیزات
                extras.push({
                    name: document.querySelector(`#${id} h4`).innerText,
                    quantity: quantity,
                    price: productPrices[id]
                });
            }
        });

        document.getElementById("cart-table").innerHTML = cartTable;
        document.getElementById("total-price").innerText = formatPrice(totalPrice);
        document.getElementById("total-price-input").value = totalPrice;
        document.getElementById("extras-input").value = JSON.stringify(extras);
        currentTotalPrice = totalPrice;
    }

    function applyDiscount() {
        let discountCode = document.getElementById("discount-code").value.trim();
        let discountMessage = document.getElementById("discount-message");
        let totalPriceElement = document.getElementById("total-price");
        let totalPriceInput = document.getElementById("total-price-input");

        discountMessage.classList.remove("discount-success", "discount-error", "discount-repeat");

        if (appliedDiscounts.includes(discountCode)) {
            discountMessage.innerText = "⚠ این کد قبلاً اعمال شده است!";
            discountMessage.classList.add("discount-repeat");
            return;
        }

        if (discountCodes[discountCode]) {
            let discountAmount = discountCodes[discountCode];
            let finalPrice = Math.max(0, currentTotalPrice - discountAmount);

            appliedDiscounts.push(discountCode);
            totalPriceElement.innerHTML = `
                <span class="discount-price">${formatPrice(currentTotalPrice)} تومان</span>
                <span>${formatPrice(finalPrice)}</span>
            `;

            // به‌روزرسانی قیمت نهایی
            totalPriceInput.value = finalPrice;
            currentTotalPrice = finalPrice;

            discountMessage.innerText = `✅ کد تخفیف اعمال شد! مبلغ ${formatPrice(discountAmount)} تومان کم شد.`;
            discountMessage.classList.add("discount-success");
        } else {
            discountMessage.innerText = "❌ کد تخفیف اشتباه است!";
            discountMessage.classList.add("discount-error");
        }
    }

    function prepareFormData() {
        // پر کردن فیلدهای مخفی قبل از ارسال فرم
        document.getElementById("start-date-input").value = localStorage.getItem("startDate");
        document.getElementById("end-date-input").value = localStorage.getItem("endDate");
        document.getElementById("nights-input").value = parseInt(document.getElementById("stay-duration").innerText.split(":")[1]?.trim() || 0);
    }

    document.getElementById('accept-rules').addEventListener('change', function() {
        document.getElementById('submit').disabled = !this.checked;
    });

    window.onload = function() {
        const startDate = localStorage.getItem("startDate");
        const endDate = localStorage.getItem("endDate");
        const areaTitle = localStorage.getItem("areaTitle");
        const areaCapacity = localStorage.getItem("areaCapacity");
        const areaPrice = localStorage.getItem("areaPrice");

        if (startDate && endDate && areaTitle && areaPrice) {
            const start = new Date(startDate);
            const end = new Date(endDate);
            const timeDifference = end - start;
            const days = timeDifference / (1000 * 3600 * 24);

            document.getElementById("reservation-dates").innerText = `بازه انتخابی: ${startDate} تا ${endDate}`;
            document.getElementById("stay-duration").innerText = `تعداد شب‌ها: ${days}`;
            document.getElementById("area-info").innerText = `ناحیه: ${areaTitle}, ظرفیت: ${areaCapacity}, قیمت: ${formatPrice(areaPrice)}`;

            // پر کردن فیلدهای مخفی
            document.getElementById("start-date-input").value = startDate;
            document.getElementById("end-date-input").value = endDate;
            document.getElementById("nights-input").value = days;
        } else {
            document.getElementById("reservation-dates").innerText = "لطفاً ناحیه و مدت اقامت خود را انتخاب کنید";
        }

        renderCart();
    };

    // فارسی کردن عدد
    function convertNumbersToPersian() {
        const persianNumbers = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
        document.querySelectorAll('.persian-number').forEach(el => {
            el.innerHTML = el.innerHTML.replace(/\d/g, d => persianNumbers[d]);
        });
    }

    // وقتی صفحه لود شد اعداد فارسی شوند
    document.addEventListener("DOMContentLoaded", convertNumbersToPersian);
</script>
</html>