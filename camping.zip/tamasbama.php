<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تماس با ما</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Tahoma', sans-serif;
            margin: 0;
            padding: 0;
            background: #f5f5f5;
        }

        .contact-header {
            background: linear-gradient(120deg, #004d8b, #1e3c72);
            padding: 100px 0;
            color: #fff;
            text-align: center;
            border-bottom: 5px solid #003366;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            animation: fadeInHeader 1.5s ease-in-out;
        }

        .contact-header h1 {
            font-size: 3.5em;
            margin-bottom: 20px;
            text-transform: uppercase;
            letter-spacing: 2px;
            text-shadow: 3px 3px 6px rgba(0, 0, 0, 0.3);
        }

        .contact-header p {
            font-size: 1.3em;
            margin-bottom: 40px;
            font-weight: 300;
        }

        .contact-form {
            background-color: #fff;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            animation: slideInFromLeft 1.5s ease-out;
        }

        .contact-form h3 {
            font-size: 2em;
            margin-bottom: 20px;
            color: #003366;
        }

        .contact-form input,
        .contact-form textarea {
            width: 100%;
            padding: 15px;
            margin: 15px 0;
            border-radius: 10px;
            border: 1px solid #ccc;
            font-size: 1.1em;
            transition: 0.3s;
        }

        .contact-form input:focus,
        .contact-form textarea:focus {
            border-color: #1e3c72;
            box-shadow: 0 0 10px rgba(30, 60, 114, 0.3);
        }

        .contact-form button {
            background-color: #1e3c72;
            color: #fff;
            padding: 15px 30px;
            border-radius: 25px;
            font-size: 1.2em;
            border: none;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .contact-form button:hover {
            background-color: #004d8b;
            transform: translateY(-5px);
        }

        .contact-info {
            display: flex;
            justify-content: space-between;
            margin-top: 40px;
            color: #333;
            font-size: 1.2em;
            opacity: 0;
            animation: fadeInInfo 2s forwards;
        }

        .contact-info div {
            text-align: center;
        }

        .contact-info i {
            font-size: 2.5em;
            color: #004d8b;
            margin-bottom: 10px;
            transition: 0.3s;
            transform: translateY(10px);
            opacity: 0;
            animation: fadeInIcon 1s forwards;
        }

        .contact-info i:hover {
            color: #1e3c72;
            transform: scale(1.2);
        }

        .contact-info span {
            display: block;
            font-size: 1.1em;
        }

        .map-container {
            margin-top: 50px;
            opacity: 0;
            animation: fadeInMap 2s forwards;
        }

        .map-container iframe {
            width: 100%;
            height: 500px;
            border: none;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }

        @keyframes fadeInHeader {
            0% { opacity: 0; transform: translateY(-50px); }
            100% { opacity: 1; transform: translateY(0); }
        }

        @keyframes slideInFromLeft {
            0% { opacity: 0; transform: translateX(-100px); }
            100% { opacity: 1; transform: translateX(0); }
        }

        @keyframes fadeInInfo {
            0% { opacity: 0; transform: translateY(20px); }
            100% { opacity: 1; transform: translateY(0); }
        }

        @keyframes fadeInIcon {
            0% { opacity: 0; transform: translateY(10px); }
            100% { opacity: 1; transform: translateY(0); }
        }

        @keyframes fadeInMap {
            0% { opacity: 0; transform: translateY(30px); }
            100% { opacity: 1; transform: translateY(0); }
        }

        @media (max-width: 768px) {
            .contact-info {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>

    <header class="contact-header">
        <h1>تماس با ما</h1>
        <p>هر سوالی دارید، ما اینجا هستیم که پاسخ بدیم. با ما در تماس باشید.</p>
    </header>

    <div class="container">
        <div class="row">
            <div class="col-lg-6">
                <div class="contact-form">
                    <h3>فرم تماس</h3>
                    <form id="contactForm">
                        <input type="text" id="name" placeholder="نام شما" required>
                        <input type="email" id="email" placeholder="ایمیل شما" required>
                        <textarea id="message" rows="5" placeholder="پیام شما" required></textarea>
                        <button type="submit">ارسال پیام</button>
                    </form>
                </div>
            </div>

            <div class="col-lg-6">
                <div class="contact-info">
                    <div>
                        <i class="fas fa-map-marker-alt"></i>
                        <span>تهران، ایران</span>
                    </div>
                    <div>
                        <i class="fas fa-phone-alt"></i>
                        <span>+98 21 0000 0000</span>
                    </div>
                    <div>
                        <i class="fas fa-envelope"></i>
                        <span>info@camping.com</span>
                    </div>
                </div>
            </div>
        </div>

        <div class="map-container">
            <h3 class="text-center">محل ما</h3>
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d126660.92230767898!2d51.30951814453516!3d35.698204400000006!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3f8c1c01f7b6e3b7%3A0xd20a080ed3b5edfb!2z2LHZg9mF2KfYqNin2LPYr9i32YQ!5e0!3m2!1sen!2sus!4v1611306954343!5m2!1sen!2sus" allowfullscreen="" loading="lazy"></iframe>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <script>
        document.getElementById("contactForm").addEventListener("submit", function(event) {
            event.preventDefault();
            alert("پیام شما با موفقیت ارسال شد.");
        });
    </script>

</body>
</html>
