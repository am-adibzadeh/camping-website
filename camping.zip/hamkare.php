<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>همکاری با ما</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Tahoma', sans-serif;
            margin: 0;
            padding: 0;
            background: #f5f5f5;
            direction: rtl; /* راست‌چین کردن صفحه */
            text-align: right; /* متن به سمت راست بچسبد */
        }

        .collaboration-header {
            background: linear-gradient(120deg, #0a74da, #1e3c72);
            padding: 100px 0;
            color: #fff;
            text-align: center;
            border-bottom: 5px solid #003366;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            animation: fadeInHeader 1.5s ease-in-out;
        }

        .collaboration-header h1 {
            font-size: 3.5em;
            margin-bottom: 20px;
            text-transform: uppercase;
            letter-spacing: 2px;
            text-shadow: 3px 3px 6px rgba(0, 0, 0, 0.3);
        }

        .collaboration-header p {
            font-size: 1.3em;
            margin-bottom: 40px;
            font-weight: 300;
        }

        .collaboration-content {
            padding: 60px 0;
        }

        .collaboration-section {
            background-color: #fff;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            margin-bottom: 40px;
            animation: fadeInSection 2s ease-out;
        }

        .collaboration-section h3 {
            font-size: 2.5em;
            margin-bottom: 20px;
            color: #003366;
        }

        .collaboration-section p {
            font-size: 1.2em;
            line-height: 1.8;
            color: #333;
        }

        .collaboration-form {
            background-color: #f0f8ff;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            animation: fadeInForm 2s ease-out;
        }

        .collaboration-form h4 {
            font-size: 2em;
            margin-bottom: 30px;
            color: #003366;
        }

        .form-control {
            border-radius: 8px;
            box-shadow: none;
            font-size: 1.1em;
            padding: 15px;
            margin-bottom: 15px;
            border: 2px solid #ddd;
        }

        .form-control:focus {
            border-color: #0a74da;
            box-shadow: 0 0 10px rgba(10, 116, 218, 0.5);
        }

        .btn-submit {
            background-color: #0a74da;
            color: #fff;
            padding: 15px 30px;
            border: none;
            border-radius: 8px;
            font-size: 1.2em;
            cursor: pointer;
            transition: 0.3s;
        }

        .btn-submit:hover {
            background-color: #005bb5;
            transform: scale(1.05);
        }

        @keyframes fadeInHeader {
            0% { opacity: 0; transform: translateY(-50px); }
            100% { opacity: 1; transform: translateY(0); }
        }

        @keyframes fadeInSection {
            0% { opacity: 0; transform: translateY(50px); }
            100% { opacity: 1; transform: translateY(0); }
        }

        @keyframes fadeInForm {
            0% { opacity: 0; transform: translateY(30px); }
            100% { opacity: 1; transform: translateY(0); }
        }

        @media (max-width: 768px) {
            .collaboration-form {
                padding: 30px;
            }
        }
    </style>
</head>
<body>

    <header class="collaboration-header">
        <h1>همکاری با ما</h1>
        <p>بیایید با هم تجربه‌ای عالی بسازیم!</p>
    </header>

    <div class="container collaboration-content">
        <div class="collaboration-section">
            <h3>چرا با ما همکاری کنید؟</h3>
            <p>
                ما در سایت کمپینگ خود، فضایی برای همکاری با تمامی علاقه‌مندان به گردشگری و کمپینگ فراهم کرده‌ایم.
                با همکاری با ما می‌توانید به یک شبکه گسترده از گردشگران و کمپینگ‌کاران دست یابید و تجربه‌های جدیدی
                را در کنار ما داشته باشید.
            </p>
        </div>

        <div class="collaboration-form">
            <h4>فرم همکاری</h4>
            <form>
                <input type="text" class="form-control" placeholder="نام کامل" required>
                <input type="email" class="form-control" placeholder="ایمیل" required>
                <textarea class="form-control" rows="4" placeholder="پیام شما" required></textarea>
                <button type="submit" class="btn-submit">ارسال</button>
            </form>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>


const posts = [
            { title: "راهنمای انتخاب بهترین تجهیزات کمپینگ", image: "img/camping-gears.jpg", author: "محمد علی", date: "25 دی 1399", excerpt: "در این مقاله، به بررسی بهترین تجهیزات کمپینگ و نکات کلیدی برای انتخاب آنها می‌پردازیم" },
            { title: "چگونه یک کمپ موفق بسازیم؟", image: "img/Image-07_09_2024-1-1024x682.webp", author: "فرشته مهدی", date: "20 دی 1399", excerpt: "در این مقاله می‌آموزیم که چگونه یک کمپ خوب بسازیم و در دل طبیعت لذت ببریم" },
            { title: "کمپینگ در فصل‌های مختلف", image: "img/best-time-for-climbing.jpg", author: "سارا طاهری", date: "18 دی 1399", excerpt: "کمپینگ در هر فصل ویژگی‌های خاص خود را دارد. در این مقاله، به بررسی این ویژگی‌ها می‌پردازیم" },
            { title: "چگونه کمپینگ خود را جذاب کنیم؟", image: "img/-زدن-e1529929665217.jpg", author: "علی راد", date: "10 دی 1399", excerpt: "برخی نکات برای داشتن یک تجربه جذاب و به یاد ماندنی در کمپینگ" },
            { title: "نکات ایمنی در کمپینگ", image: "img/0032865_Blog-Amozeshi-1_550.webp", author: "لیلا آذری", date: "5 دی 1399", excerpt: "ایمنی در کمپینگ اهمیت زیادی دارد. در این مقاله، به مهم‌ترین نکات ایمنی می‌پردازیم" },
            { title: "راهنمای انتخاب بهترین محل کمپینگ", image: "img/How-to-find-the-best-place-to-camp_.jpg", author: "فرشاد حیدری", date: "1 دی 1399", excerpt: "چگونه بهترین مکان برای کمپینگ را انتخاب کنیم؟ در این مقاله به بررسی عوامل مهم انتخاب محل کمپینگ می‌پردازیم" },
            { title: "چگونه وسایل کمپینگ خود را سازماندهی کنیم؟", image: "img/yfa_051616_42218_campsite_comfort_organization_lg.jpg", author: "مینا حسینی", date: "28 آذر 1399", excerpt: "سازماندهی وسایل برای کمپینگ اهمیت زیادی دارد. در این مقاله، روش‌های مختلف سازماندهی وسایل کمپینگ را بررسی می‌کنیم..." },
            { title: "نکات جالب در مورد کمپینگ در کوهستان", image: "img/-زدن-e1529929665217.jpg", author: "جواد کریمی", date: "25 آذر 1399", excerpt: "کمپینگ در کوهستان یک تجربه خاص است. در این مقاله نکات جالب و مفیدی برای کمپینگ در کوهستان را بررسی می‌کنیم..." },
            { title: "چگونه غذای خوشمزه در کمپینگ بپزیم؟", image: "img/9d427700-bced-4f55-8e97-fab58b17b30a.webp", author: "ندا مصطفوی", date: "20 آذر 1399", excerpt: "پخت غذای خوشمزه در کمپینگ می‌تواند تجربه‌ای لذت‌بخش باشد. در این مقاله نکات کلیدی برای پخت غذا در کمپینگ را بررسی می‌کنیم..." },
            { title: "تجربه کمپینگ در طبیعت بکر", image: "img/5e1c0e0bbc47f816120fdf3d.jpg", author: "سینا احمدی", date: "15 آذر 1399", excerpt: "کمپینگ در طبیعت بکر می‌تواند تجربه‌ای فراموش‌نشدنی باشد. در این مقاله، به بررسی تجربیات شخصی از کمپینگ در طبیعت بکر می‌پردازیم..." },
            { title: "کمپینگ با خانواده: نکات ضروری", image: "img/How_20to_20Plan_20a_20Successful_20Family_20Camping_20Trip.jpg", author: "زهره صالحی", date: "10 آذر 1399", excerpt: "کمپینگ با خانواده تجربه‌ای شاد و آموزنده است. در این مقاله نکات ضروری برای کمپینگ خانوادگی را بررسی می‌کنیم..." },
            { title: "چگونه در کمپینگ آرامش پیدا کنیم؟", image: "img/camp1.jpg.webp", author: "رحیم فلاح", date: "5 آذر 1399", excerpt: "کمپینگ می‌تواند فرصتی برای استراحت و آرامش باشد. در این مقاله راه‌هایی برای پیدا کردن آرامش در کمپینگ را بررسی می‌کنیم..." },
            { title: "آشنایی با انواع چادرهای کمپینگ", image: "img/unnamed.jpg", author: "نیکا قاسمی", date: "1 آذر 1399", excerpt: "در این مقاله با انواع مختلف چادرهای کمپینگ و ویژگی‌های آنها آشنا می‌شویم..." },
            { title: "بهترین زمان برای کمپینگ در ایران", image: "img/2-تصویر-جدیدی-ییلاق-به-چه-مناطقی-گفته-می_شود؟.jpg", author: "محمدرضا توکلی", date: "25 آبان 1399", excerpt: "در این مقاله بهترین زمان‌ها برای کمپینگ در ایران را بررسی می‌کنیم..." },
            { title: "چگونه کمپینگ لوکسی داشته باشیم؟", image: "img/کمپینگ-در-طبیعت.webp", author: "عاطفه یزدی", date: "20 آبان 1399", excerpt: "کمپینگ لوکس می‌تواند تجربه‌ای بی‌نظیر باشد. در این مقاله، به نکات مهم برای داشتن کمپینگ لوکس می‌پردازیم..." },
            { title: "کمپینگ در شب: چالش‌ها و راه‌حل‌ها", image: "img/Camping-tent.jpg", author: "حسین نادری", date: "15 آبان 1399", excerpt: "کمپینگ در شب چالش‌های خاص خود را دارد. در این مقاله، به بررسی چالش‌ها و راه‌حل‌های کمپینگ شبانه می‌پردازیم..." },
            { title: "راهنمای انتخاب بهترین کفش برای کمپینگ", image: "img/راهنمای-خرید-کفش-کوهنوردی.webp", author: "سینا مهرابی", date: "10 آبان 1399", excerpt: "انتخاب کفش مناسب برای کمپینگ می‌تواند تفاوت زیادی ایجاد کند. در این مقاله، به بررسی بهترین کفش‌ها برای کمپینگ می‌پردازیم..." },
            { title: "کمپینگ به سبک سبک زندگی پایدار", image: "img/camping-first-timer-tips.jpeg", author: "مرضیه طاهری", date: "5 آبان 1399", excerpt: "کمپینگ به سبک پایدار می‌تواند بر تجربه شما تأثیر زیادی بگذارد. در این مقاله، به بررسی راه‌های کمپینگ پایدار می‌پردازیم..." },
            { title: "چگونه کمپینگ را در باران تجربه کنیم؟", image: "img/Camping-in-rainy-weather-has-some-tips-that-you-should-follow.jpg", author: "امیر شجاعی", date: "1 آبان 1399", excerpt: "کمپینگ در باران می‌تواند تجربه‌ای خاص و متفاوت باشد. در این مقاله، به نکات کمپینگ در باران می‌پردازیم..." },
            { title: "آموزش کمپینگ در مناطق کویری", image: "img/نشرهق.jpg", author: "نادر افشاری", date: "25 مهر 1399", excerpt: "کمپینگ در مناطق کویری می‌تواند چالش‌هایی داشته باشد. در این مقاله، نکات و آموزش‌های مهم برای کمپینگ در کویر را بررسی می‌کنیم..." }
        ];  