<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "camping";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$abas="SELECT * FROM `users`";
$result = $conn->query($abas);
    
    // ورود
    if(isset($_POST["submit"]))
    {
        $phone_number=$_POST['phone_number'];
        $password=$_POST['password'];
    
        $sql="SELECT * FROM `users` WHERE `phone_number`='".$phone_number."'";
        $result = $conn->query($sql);
    
        if ($result->num_rows == 1) {
            $row = $result->fetch_assoc();
            if($row['password'] == $password)
            {
                $_SESSION['id']=$row['id'];
                header('location: index.php');
            }else{
                echo "نام کاربری یا رمز عبور اشتباه است!!!";
            }
        } else {
            echo "!!!حساب کاربری با این نام پیدا نشد";
        }
    }

    // ثبت نام

if (isset($_POST["acoontss"])) {
    $phophone_numberne = $_POST["phone_number"];
    $password = $_POST["password"];
    
    $sql = "INSERT INTO `users` (`phone_number`, `password`) VALUES ('$phone_number', '$password')";
    
    if ($conn->query($sql) === TRUE) {
        echo "<script>
          alert('🎉 ثبت‌نام با موفقیت انجام شد!');
          window.location.href = 'index.php'; // آدرس صفحه‌ای که بعدش می‌خوای بری
        </script>";
    } else {
        echo "<script>
          alert('❌ خطا در ثبت‌نام: " . $conn->error . "');
        </script>";
    }
}
    
?>
<!DOCTYPE html>
<html lang="en" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <!-- jQuery library -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>
    <!-- Popper JS -->
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>

    <link rel="stylesheet" href="style.css">

    <title>کمپینگ</title>

    <!-- لوگو سایت -->
    <link rel="icon" type="img/download.jpg" sizes="192x192" href="img/camping_1f3d5 1.png">
</head>
<body>

<!-- هدر -->
<div class="container-fluid text-center sticky-top" style="color: #000;">
    <div class="row shadow bg-warning mt-4 p-2 mr-5 ml-5" style="border-radius: 15px; position: relative; z-index: 3;">
        <!-- عنوان کمپینگ -->
        <div class="col-md-2 pl-md-5" style="font-family: yekanBlack;">
            <h2 style="color: #000;"><b>کمپینگ</b></h2>
        </div>

        <!-- دکمه همبرگر و ورود/ثبت‌نام برای موبایل -->
        <div class="container-fluid d-md-none">
            <div class="row">
                <div class="col-10">            
                <?php
                    if (isset($_SESSION['id'])) {
                        $userId = $_SESSION['id'];
                        $sql = "SELECT * FROM users WHERE id = '$userId'";
                        $result = $conn->query($sql);
                        
                        if ($result->num_rows > 0) {
                            $row = $result->fetch_assoc();
                    ?>
                            <div class="dropdown ml-auto mt-1">
                                <a class="dropdown-toggle d-flex align-items-center" href="#" id="userDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <img src="img/icons8-user-96.png" class="ml-1" height="30px" alt="">
                                    <?php echo '<p class="persian-number pt-3">' . $row['phone_number'] . '</p>'; ?>
                                </a>
                                <div class="dropdown-menu dropdown-menu-left text-right" aria-labelledby="userDropdown">
                                    <a class="dropdown-item" href="#">اطلاعات حساب کاربری</a>
                                    <a class="dropdown-item" href="#"></a>
                                    <a class="dropdown-item" href="#">اعلان ها</a>
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item text-danger" href="logout.php">خروج</a>
                                </div>
                            </div>
                    <?php
                        }
                    } else {
                    ?>
                        <!-- دکمه ورود/ثبت‌نام برای زمانی که لاگین نیست -->
                        <div class="col-md-2 text-left pt-1 d-none d-md-block">
                            <button type="button" class="btn btn-success" onclick="document.getElementById('id01').style.display='block'">ورود / ثبت نام</button>
                        </div>
                    <?php
                    }
                    ?>                
                </div>
                <div class="col-2 text-left">
                    <button class="navbar-toggler" type="button" onclick="toggleNav()">
                        <img src="img/icons8-menu-208.png" width="20px" alt="">
                    </button>
                </div>
            </div>
        </div>

        <!-- منوی ناوبری (فقط در دسکتاپ نمایش داده شود) -->
        <div class="col-md-8 pr-md-5 pl-md-5 d-none d-md-block">
            <ul class="nav navbar justify-content-center">
                <a href="index.php"><li class="nav-item mx-5">صفحه اصلی</li></a>
                <a href="rezery.php?item=tree&time=day"><li class="nav-item mx-5">رزروکمپ</li></a>
                <a href="http://localhost:5000/" onclick="alert('این هوش مصنوعی برای کمپینگ است و به سوال‌های غیر مرتبط پاسخ نمی‌دهد.')">
                    <li class="nav-item mx-5">هوش مصنوعی <small style="font-size: 8px;color: red;">(جدید)</small></li>
                </a>
                <a href="tamasbama.php"><li class="nav-item mx-5">تماس باما</li></a>
            </ul>
        </div>

        <?php
    if (isset($_SESSION['id'])) {
        $userId = $_SESSION['id'];
        $sql = "SELECT * FROM users WHERE id = '$userId'";
        $result = $conn->query($sql);
        
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
    ?>
    <div class="dropdown ml-auto mt-1 con-desktop">
        <a class="dropdown-toggle d-flex align-items-center" href="#" id="userDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <img src="img/icons8-user-96.png" class="ml-1" height="30px" alt="">
            <?php echo '<p class="persian-number pt-3">' . $row['phone_number'] . '</p>'; ?>
        </a>
        <div class="dropdown-menu dropdown-menu-left text-right" aria-labelledby="userDropdown">
            <a class="dropdown-item" href="Account.php">اطلاعات حساب کاربری</a>
            
            <?php
            // اینجا چک میکنیم اگر نقش admin بود، لینک تنظیمات رو هم نشون بده
            if (isset($row['role']) && $row['role'] === 'admin') {
                echo '<a class="dropdown-item" href="Account.admin.php">تنظیمات</a>';
            }
            ?>

            <a class="dropdown-item" href="#">اعلان ها</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item text-danger" href="logout.php">خروج</a>
        </div>
    </div>
<?php
    }
} else {
?>
    <!-- دکمه ورود/ثبت‌نام برای زمانی که لاگین نیست -->
    <div class="col-md-2 text-left pt-1 d-none d-md-block">
        <button type="button" class="btn btn-success" onclick="document.getElementById('id01').style.display='block'">ورود / ثبت نام</button>
    </div>
<?php
}
?>

    </div>
</div>

<!-- ساید ناوبری برای موبایل -->
<div id="mySidenav" class="sidenav">
    <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
    <a href="index.php">صفحه اصلی</a>
    <a href="rezery.php">رزروکمپ</a>
    <a href="ai camping.php" onclick="alert('این هوش مصنوعی برای کمپینگ است و به سوال‌های غیر مرتبط پاسخ نمی‌دهد.')">هوش مصنوعی <small style="font-size: 8px;color: red;">(جدید)</small></a>
    <a href="">تماس باما</a>
</div>

<!-- پس‌زمینه‌ی تاریک هنگام باز شدن منوی موبایل -->
<div id="overlay" class="overlay" onclick="closeNav()"></div>

<!-- فرم ورود / ثبت‌نام -->
<div id="id01" class="modal">
    <form class="modal-content animate" style="width: 470px; height: 440px;" method="post">
        <div class="container text-center" id="bendaz">
            <h4 class="mb-2" style="margin-top: 50px;"><b>ورود / ثبت نام</b></h4>
            <p class="mt-4 text-right mr-5" style="font-size: 10px;">برای ورود یا ثبت نام ابتدا باید شماره موبایل خود را وارد کنید ، این کار به منظور است </p>
            <p class="text-right mr-5" style="font-size: 10px;">که <a href="" style="font-size: 10px; border-bottom: rgb(98 92 212) solid;color: rgb(98 92 212);">قوانین و مقررات </a>را مطالعه و با آن موافق هستید.</p>
            <h6 class="text-right mt-4" style="margin-right: 80px;">تلفن همراه:</h6>
            <input type="number" name="phone_number" id="phone_number" class="in-pha in-ba-im text-right mt-0" placeholder="09123456789" required>
            <h6 class="text-right mt-2" style="margin-right: 80px;">رمز عبور:</h6>
            <input type="password" id="password" name="password" class="in-pha in-ba-im text-right mt-0" placeholder="********" required>
            <div class="row mt-4">
                <div class="col-md-12 text-center">
                    <input href="" type="submit"  id="submit" name="submit" class="btn btn-warning" style="width: 270px; border-radius: 10px;" value="ورود">
                </div>
                <div class="col-md-12 text-center">
                    <p onclick="ali_baba_vorod('sabt')" class="mt-3" style="font-size: 10px;">حساب کاربری ندارید: <b style="color: blue; font-size: 11px;"><a href="#">ثبت نام کنید </a></b></p>
                </div>
            </div>
        </div>
    </form>
</div>


<!-- صفحه اول -->
<div class="container-fluid text-right" style="padding-right: 60px;padding-top: 50px;position: relative;z-index: 5;">
    <div class="row">
        <div class="col-md-7 row mt-5">
            <img src="img/camping_1f3d5 1.png" alt="" style="width: 60px;height: 60px;">
            <h1 class="mt-3 mr-3 extra-content"id="London-Extra-Day" style="color: #347928;"><b>کمپینگ کمپی بی دردسر</b></h1>
            <h1 class="mt-3 mr-3 extra-content"id="London-Extra-Night" style="color: #c0eca7;"><b>کمپینگ کمپی بی دردسر</b></h1>

            <h1 class="mt-3 mr-3 extra-content"id="Paris-Extra-Day" style="color:#fe4c00 ;"><b>کمپینگ کمپی بی دردسر</b></h1>
            <h1 class="mt-3 mr-3 extra-content"id="Paris-Extra-Night" style="color:#fccd29 ;"><b>کمپینگ کمپی بی دردسر</b></h1>

            <h1 class="mt-3 mr-3 extra-content"id="Tokyo-Extra-Day" style="color: #365ee2;"><b>کمپینگ کمپی بی دردسر</b></h1>
            <h1 class="mt-3 mr-3 extra-content"id="Tokyo-Extra-Night" style="color: #a4effe;"><b>کمپینگ کمپی بی دردسر</b></h1>
        </div>
        <div class="col-md-5">
            <div class="background bgtab1 shadow">
                <div class="container-fluid mt-2 pr-3">
                    <div class="row">
                        <div class="col-md-4 icon-container" id="icon-Tokyo" onclick="toggleContent('Tokyo'); changeButtonColors('#98d7ff')">
                            <img src="img/Mountain.png" width="28px" alt="">
                        </div>
                        <div class="col-md-4 text-center icon-container" id="icon-Paris" onclick="toggleContent('Paris'); changeButtonColors('#ffc107')">
                            <img src="img/Western.png" width="28px" alt="">
                        </div>
                        <div class="col-md-4 icon-container" id="icon-London" onclick="toggleContent('London'); changeButtonColors('#28a745')">
                            <img src="img/Forest.png" width="28px" alt="">
                        </div>
                    </div>
                </div>
            </div>
            <div class="background bgtab2 shadow">
                <div class="container-fluid mr-2" style="margin-top: 6px;">
                    <div class="row">
                        <div class="col-md-4 mr-1 icon-container" id="icon-Night" onclick="toggleDayNight('Night')">
                            <img src="img/Do not Disturb iOS.png" width="28px" alt="">
                        </div>
                        <div class="col-md-4 mr-2 text-center icon-container" id="icon-Day" onclick="toggleDayNight('Day')">
                            <img src="img/Sun.png" width="28px" alt="">
                        </div>
                    </div>
                </div>
            </div>
            <div class="background bgtab3 shadow">
                <div class="container-fluid mt-2 pr-2">
                    <div class="row">
                        <div class="col-md-4 pr-3">
                            <img src="img/brf.png" id="snow-img" width="28px" alt=""></button>
                        </div>
                        <div class="col-md-4 pr-2 text-center">
                            <img src="img/baron.png" id="rain-img" width="28px" alt=""></button>
                        </div>
                        <div class="col-md-4 pr-0">
                            <img src="img/abr.png" id="clear-img" width="28px" alt=""></button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6 mr-3 mt-2">
            <br>
            <h6>کمپینگ با هدف ایجاد یک فضای تفریحی برای هم مهمان عزیز ایجاد شده تا همه افراد</h6>
            <h6 class="mt-4">حتی افرادی که اطلاعات زیادی از کمپ در طبیعت ندارد هم بتوانند از این نعمت زیبا </h6>
            <h6 class="mt-4">یعنی استراحت با خانواده در طبیعت استفاده کنند </h6>
            <h6 class="mt-4">همپنین اینجا همه چیز در امنیت کامل تا به استراحت و آرامش شما کوچکترین</h6>
            <h6 class="mt-4">لطمه ای وارد نشود.</h6>
            <div class="row mt-5">
                <div class="col-md-3">

                    <a class="btn btn btn-danger btnbb btntt extra-content mr-4" href="rezery.php?item=tree&time=day" id="London-Extra3-Day">بزن بریم کمپ</a>
                    <a class="btn btn btn-danger btnbb1 btntt extra-content mr-4" href="rezery.php?item=tree&time=night" id="London-Extra3-Night">بزن بریم کمپ</a>

                    <a class="btn btn btn-danger btnbb2 btntt extra-content mr-4" href="rezery.php?item=cactus&time=day" id="Paris-Extra3-Day">بزن بریم کمپ</a>
                    <a class="btn btn btn-danger btnbb3 btntt extra-content mr-4" href="rezery.php?item=cactus&time=night" id="Paris-Extra3-Night">بزن بریم کمپ</a>

                    <a class="btn btn btn-danger btnbb4 btntt extra-content mr-4" href="rezery.php?item=mountain&time=day" id="Tokyo-Extra3-Day">بزن بریم کمپ</a>
                    <a class="btn btn btn-danger btnbb5 btntt extra-content mr-4" href="rezery.php?item=mountain&time=night" id="Tokyo-Extra3-Night">بزن بریم کمپ</a>
                </div>
                <div class="col-md-3 mr-3">
                    <a class="btn btn-outline-success btntt extra-content" id="London-Extra2-Day" style="border: 3px solid;">اطلاعات بیشتر</a>
                    <a class="btn btn-outline-success btntt extra-content" id="London-Extra2-Night" style="border: 3px solid;">اطلاعات بیشتر</a>

                    <a class="btn btn-outline-warning btntt extra-content" id="Paris-Extra2-Day" style="border: 3px solid;">اطلاعات بیشتر</a>
                    <a class="btn btn-outline-warning btntt extra-content" id="Paris-Extra2-Night" style="border: 3px solid;">اطلاعات بیشتر</a>

                    <a class="btn btn-outline-primary btntt extra-content" id="Tokyo-Extra2-Day" style="border: 3px solid;">اطلاعات بیشتر</a>
                    <a class="btn btn-outline-primary btntt extra-content" id="Tokyo-Extra2-Night" style="border: 3px solid;">اطلاعات بیشتر</a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- لایه افکت -->
<div class="effect-layer" id="effect-layer"></div>

<!-- سبز کم رنگ -->
<div id="London" class="content mt-5 text-center">
    <div id="London-Day" class="sub-content mt-4">
        <div class="background bg1"></div>
        <div class="background bg2"></div>
        <div class="background bg3"></div>
        <div class="background bg4"></div>
        <div class="background bg5"></div>

    </div>
<!-- سبز پر رنگ -->
    <div id="London-Night" class="sub-content mt-4">
        <div class="background bg6"></div>
        <div class="background bg7"></div>
        <div class="background bg8"></div>
        <div class="background bg9"></div>
        <div class="background bg10"></div>

    </div>
</div>

<!-- نارنجی کم رنگ -->
<div id="Paris" class="content mt-5 text-center">
    <div id="Paris-Day" class="sub-content mt-4">
        <div class="background bg1-n"></div>
        <div class="background bg2-n"></div>
        <div class="background bg3-n"></div>
        <div class="background bg4-n"></div>
        <div class="background bg5-n"></div>

    </div>
    <!-- نارنجی پر رنگ -->
    <div id="Paris-Night" class="sub-content mt-4">
        <div class="background bg6-n"></div>
        <div class="background bg7-n"></div>
        <div class="background bg8-n"></div>
        <div class="background bg9-n"></div>
        <div class="background bg10-n"></div>

    </div>
</div>

<!-- آبی کم رنگ -->
<div id="Tokyo" class="content mt-5 text-center">
    <div id="Tokyo-Day" class="sub-content mt-4">
        <div class="background bg1-a"></div>
        <div class="background bg2-a"></div>
        <div class="background bg3-a"></div>
        <div class="background bg4-a"></div>
        <div class="background bg5-a"></div>

    </div>
    <!-- آبی پر رنگ -->
    <div id="Tokyo-Night" class="sub-content mt-4">
        <div class="background bg6-a"></div>
        <div class="background bg7-a"></div>
        <div class="background bg8-a"></div>
        <div class="background bg9-a"></div>
        <div class="background bg10-a"></div>

    </div>
</div>

<!-- مرحله ها -->
 
<div class="container-fluid" style="margin-top: 200px;">
            <!-- شماره‌ها -->
            <div class="row text-center">
                <div class="col-md-12 extra-content London-Extra2-Day London-Extra2-Night" id="step-indicators">
                    <img src="img/1.png" width="50px" alt="" id="step-1-img">
                    <img src="img/titi.png" width="400px" height="20px" alt="">
                    <img src="img/2.2.png" width="50px" alt="" id="step-2-img">
                    <img src="img/titi.png" width="400px" height="20px" alt="">
                    <img src="img/3.2.png" width="50px" alt="" id="step-3-img">
                </div>

                <div class="col-md-12 extra-content Paris-Extra2-Day Paris-Extra2-Night" id="step-indicators">
                    <img src="img/1r.png" width="50px" alt="" id="step-1-img">
                    <img src="img/titir.png" width="400px" height="20px" alt="">
                    <img src="img/2.2r.png" width="50px" alt="" id="step-2-img">
                    <img src="img/titir.png" width="400px" height="20px" alt="">
                    <img src="img/3.2r.png" width="50px" alt="" id="step-3-img">
                </div>

                <div class="col-md-12 extra-content Tokyo-Extra2-Day Tokyo-Extra2-Night" id="step-indicators">
                    <img src="img/1b.png" width="50px" alt="" id="step-1-img">
                    <img src="img/titib.png" width="400px" height="20px" alt="">
                    <img src="img/2.2b.png" width="50px" alt="" id="step-2-img">
                    <img src="img/titib.png" width="400px" height="20px" alt="">
                    <img src="img/3.2b.png" width="50px" alt="" id="step-3-img">
                </div>

            </div>

            <!-- اسلایدر -->
            <div class="slider-wrapper">
                <div class="slider-content active" id="step-1">
                    <div class="row mt-3">
                        <div class="col-md-3 col-1">
                            <div class="row">
                                <div class="col-md-11">
                                    <h2 class="extra-content London-Extra2-Day" style="font-size: 400px;color: #e6f5cc;">۱</h2>
                                    <h2 class="extra-content London-Extra2-Night" style="font-size: 400px;color: #1b431e;">۱</h2>
                                    <h2 class="extra-content Paris-Extra2-Day" style="font-size: 400px;color: #fde488;">۱</h2>
                                    <h2 class="extra-content Paris-Extra2-Night" style="font-size: 400px;color: #8b7633;">۱</h2>
                                    <h2 class="extra-content Tokyo-Extra2-Day" style="font-size: 400px;color: #d6eef0;">۱</h2>
                                    <h2 class="extra-content Tokyo-Extra2-Night" style="font-size: 400px;color: #4c6989;">۱</h2>
                                </div>
                                <div class="col-md-1 line">
                                    <img src="img/Ellipse 8.png" width="15px" alt="">
                                    <img src="img/Line 7.png" width="4px" height="310px" alt="" class="mt-5">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-9 col-11 text-right" style="margin-top: 100px;">
                            <h3>انتخاب منطقه تفریحی</h3>
                            <h5 class="mt-4">در مرحله اول شما می توانید با استفاده از نقشه جامع کمپینگ</h5>
                            <h5 class="mt-5">منطقه تفریحی خود را انتخاب کنید این منطقه می تواند </h5>
                            <h5 class="mt-5">کوهستانی ، جنگلی یا کویری باشد. نکته قابل توجه این است که باید یکی</h5>
                            <h5 class="mt-5">از مناطق تحت پوشش کمپینگ رو انتخاب کنی</h5>
                            <h5 class="mt-5">تا از مسائل امنیتی - تفریحی برخوردار باشد</h5>
                        </div>
                    </div>
                </div>

                <div class="slider-content" id="step-2">
                    <div class="row mt-3">
                        <div class="col-md-3 col-1">
                            <div class="row">
                                <div class="col-md-11">
                                    <h2 class="extra-content London-Extra2-Day" style="font-size: 400px;color: #e6f5cc;">۲</h2>
                                    <h2 class="extra-content London-Extra2-Night" style="font-size: 400px;color: #1b431e;">۲</h2>
                                    <h2 class="extra-content Paris-Extra2-Day" style="font-size: 400px;color: #fde488;">۲</h2>
                                    <h2 class="extra-content Paris-Extra2-Night" style="font-size: 400px;color: #8b7633;">۲</h2>
                                    <h2 class="extra-content Tokyo-Extra2-Day" style="font-size: 400px;color: #d6eef0;">۲</h2>
                                    <h2 class="extra-content Tokyo-Extra2-Night" style="font-size: 400px;color: #4c6989;">۲</h2>                                </div>
                                <div class="col-md-1 line">
                                    <img src="img/Ellipse 8.png" width="15px" alt="">
                                    <img src="img/Line 7.png" width="4px" height="310px" alt="" class="mt-5">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-9 col-11 text-right" style="margin-top: 100px;">
                            <h3>رزرو کمپینگ</h3>
                            <h5 class="mt-4">در مرحله دوم شما می‌توانید کمپینگ مورد نظر خود را رزرو کنید...</h5>
                        </div>
                    </div>
                </div>

                <div class="slider-content" id="step-3">
                    <div class="row mt-3">
                        <div class="col-md-3 col-1">
                            <div class="row">
                                <div class="col-md-11">
                                    <h2 class="extra-content London-Extra2-Day" style="font-size: 400px;color: #e6f5cc;">۳</h2>
                                    <h2 class="extra-content London-Extra2-Night" style="font-size: 400px;color: #1b431e;">۳</h2>
                                    <h2 class="extra-content Paris-Extra2-Day" style="font-size: 400px;color: #fde488;">۳</h2>
                                    <h2 class="extra-content Paris-Extra2-Night" style="font-size: 400px;color: #8b7633;">۳</h2>
                                    <h2 class="extra-content Tokyo-Extra2-Day" style="font-size: 400px;color: #d6eef0;">۳</h2>
                                    <h2 class="extra-content Tokyo-Extra2-Night" style="font-size: 400px;color: #4c6989;">۳</h2>                                </div>
                                <div class="col-md-1 line">
                                    <img src="img/Ellipse 8.png" width="15px" alt="">
                                    <img src="img/Line 7.png" width="4px" height="310px" alt="" class="mt-5">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-9 col-11 text-right" style="margin-top: 100px;">
                            <h3>تایید و پرداخت</h3>
                            <h5 class="mt-4">در مرحله سوم اطلاعات را تایید و پرداخت را تکمیل کنید...</h5>
                        </div>
                    </div>
                </div>
            </div>

            <!-- دکمه‌های قبلی و بعدی -->
            <div class="row slider-nav text-left mb-5">
                <div class="col-md-12">
                    <img src="img/-).png" class="btn" style="width: 70px;" id="prev-btn" alt="">
                    <img src="img/(-_.png" class="btn" style="width: 70px;" id="next-btn" alt="">
                </div>
            </div>
</div>

<!-- خبر های کمپ -->
<div class="news-container extra-content London-Extra2-Day London-Extra2-Night pb-4" style="background-color: #1a6701;">
    <div class="news-text pt-2">
        تخفیفات ویژه برای رزرو کمپ‌های زمستانی آغاز شد! | برنامه‌های جدید کمپینگ در حال اضافه شدن به سایت هستند! | از مناطق دیدنی جدید بازدید کنید! | امکانات رفاهی در کمپ‌های برتر اضافه شد! | تخفیف‌های زمستانی تا پایان ماه جاری ادامه دارد! | کمپ‌های برفی با مناظر فوق‌العاده در دسترس هستند! | نقشه تعاملی جدید برای یافتن نزدیک‌ترین کمپ به شما آماده است! | به خانواده کمپینگ ما بپیوندید و تجربه‌ای شگفت‌انگیز داشته باشید! | مسابقات عکاسی از طبیعت در کمپ‌های برتر برگزار خواهد شد! | بسته‌های ویژه اقامت در کمپ‌های تابستانی با تخفیف ارائه می‌شود! | کمپ‌های خانوادگی با خدمات کامل در تمام فصل‌ها موجود است! | خدمات اجاره تجهیزات کمپینگ با بهترین قیمت در دسترس است! |اقامتگاه‌های لوکس کمپ‌های جنگلی در انتظار شما هستند! | به زودی کمپ‌های ساحلی جدید با امکانات رفاهی بیشتر افتتاح می‌شوند! | از تجربه شگفت‌انگیز کمپ‌های کوهستانی در زمستان لذت ببرید! | تخفیف‌های لحظه آخری کمپینگ را از دست ندهید!
    </div>
</div>
<div class="news-container extra-content Paris-Extra2-Day Paris-Extra2-Night pb-4" style="background-color: #ff9501;">
    <div class="news-text pt-2">
        تخفیفات ویژه برای رزرو کمپ‌های زمستانی آغاز شد! | برنامه‌های جدید کمپینگ در حال اضافه شدن به سایت هستند! | از مناطق دیدنی جدید بازدید کنید! | امکانات رفاهی در کمپ‌های برتر اضافه شد! | تخفیف‌های زمستانی تا پایان ماه جاری ادامه دارد! | کمپ‌های برفی با مناظر فوق‌العاده در دسترس هستند! | نقشه تعاملی جدید برای یافتن نزدیک‌ترین کمپ به شما آماده است! | به خانواده کمپینگ ما بپیوندید و تجربه‌ای شگفت‌انگیز داشته باشید! | مسابقات عکاسی از طبیعت در کمپ‌های برتر برگزار خواهد شد! | بسته‌های ویژه اقامت در کمپ‌های تابستانی با تخفیف ارائه می‌شود! | کمپ‌های خانوادگی با خدمات کامل در تمام فصل‌ها موجود است! | خدمات اجاره تجهیزات کمپینگ با بهترین قیمت در دسترس است! |اقامتگاه‌های لوکس کمپ‌های جنگلی در انتظار شما هستند! | به زودی کمپ‌های ساحلی جدید با امکانات رفاهی بیشتر افتتاح می‌شوند! | از تجربه شگفت‌انگیز کمپ‌های کوهستانی در زمستان لذت ببرید! | تخفیف‌های لحظه آخری کمپینگ را از دست ندهید!
    </div>
</div>
<div class="news-container extra-content Tokyo-Extra2-Day Tokyo-Extra2-Night pb-4" style="background-color: #365ee4;">
    <div class="news-text pt-2">
        تخفیفات ویژه برای رزرو کمپ‌های زمستانی آغاز شد! | برنامه‌های جدید کمپینگ در حال اضافه شدن به سایت هستند! | از مناطق دیدنی جدید بازدید کنید! | امکانات رفاهی در کمپ‌های برتر اضافه شد! | تخفیف‌های زمستانی تا پایان ماه جاری ادامه دارد! | کمپ‌های برفی با مناظر فوق‌العاده در دسترس هستند! | نقشه تعاملی جدید برای یافتن نزدیک‌ترین کمپ به شما آماده است! | به خانواده کمپینگ ما بپیوندید و تجربه‌ای شگفت‌انگیز داشته باشید! | مسابقات عکاسی از طبیعت در کمپ‌های برتر برگزار خواهد شد! | بسته‌های ویژه اقامت در کمپ‌های تابستانی با تخفیف ارائه می‌شود! | کمپ‌های خانوادگی با خدمات کامل در تمام فصل‌ها موجود است! | خدمات اجاره تجهیزات کمپینگ با بهترین قیمت در دسترس است! |اقامتگاه‌های لوکس کمپ‌های جنگلی در انتظار شما هستند! | به زودی کمپ‌های ساحلی جدید با امکانات رفاهی بیشتر افتتاح می‌شوند! | از تجربه شگفت‌انگیز کمپ‌های کوهستانی در زمستان لذت ببرید! | تخفیف‌های لحظه آخری کمپینگ را از دست ندهید!
    </div>
</div>

<!-- شروع یک ماجرا جویی جدید -->
 <!-- دستکتاپ -->
<div class="container-fluid mt-2 p-5 con-desktop">
    <div class="row">
        <div class="text-right col-md-4" style="margin-top: 100px;">
            <div class="extra-content London-Extra2-Day London-Extra2-Night" style="color: #ff4E04 ; font-size: 200px;"><h2>شروع یک ماجرا جویی جدید</h2></div>
            <div class="extra-content Paris-Extra2-Day Paris-Extra2-Night" style="color: #ff4E04 ; font-size: 200px;"><h2>شروع یک ماجرا جویی جدید</h2></div>
            <div class="extra-content Tokyo-Extra2-Day Tokyo-Extra2-Night" style="color: #ff4E04 ; font-size: 200px;"><h2>شروع یک ماجرا جویی جدید</h2></div>

            <div class="extra-content London-Extra2-Day London-Extra2-Night mt-4 ml-3" style="color: #1a6701 ;"><h2><b>شایدم تکرار یک ماجراجویی</b></h2></div>
            <div class="extra-content Paris-Extra2-Day Paris-Extra2-Night mt-4 ml-3" style="color: #ffc107 ;"><h2><b>شایدم تکرار یک ماجراجویی</b></h2></div>
            <div class="extra-content Tokyo-Extra2-Day Tokyo-Extra2-Night mt-4 ml-3" style="color: #365ee2 ;"><h2><b>شایدم تکرار یک ماجراجویی</b></h2></div>
            <div class="text-right mt-5 mr-3" style="font-family: YekanLight;">
                <h6 class="mt-4 pt-2"><b>برای شروع مراحل اجاره کمپ از طریق دکمه</b></h6>
                <h6 class="mt-4 pt-2"><b>زیر وارد صفحه اجاره شوید</b></h6>
                <h6 class="mt-4 pt-2"><b>از صفحه اجاره ، مکان مورد نظر خود را انتخاب کرده</b></h6>
                <h6 class="mt-4 pt-2"><b>و وارد صفحه جزئیات اجاره شوید و اقدام مورد نیاز</b></h6>
                <h6 class="mt-4 pt-2"><b>را انتخاب کنید و مبلغ درج شده را پرداخت کنید</b></h6>
                <h6 class="mt-4 pt-2"><b>و تماااااااااااام ، کمپ شما با موفقیت رزرو شد.</b></h6>

                <div class="text-center">
                    <a class="btn btn-danger btnbb6 btntt extra-content London-Extra2-Night mr-5 mt-5" href="rezery.php?item=tree&time=night">بزن بریم کمپ</a>
                    <a class="btn btn-danger btnbb6 btntt extra-content London-Extra2-Day mr-5 mt-5" href="rezery.php?item=tree&time=day">بزن بریم کمپ</a>
    
                    <a class="btn btn-warning btnbb7 btntt extra-content Paris-Extra2-Day mr-5 mt-5" href="rezery.php?item=cactus&time=day">بزن بریم کمپ</a>
                    <a class="btn btn-warning btnbb7 btntt extra-content Paris-Extra2-Night mr-5 mt-5" href="rezery.php?item=cactus&time=night">بزن بریم کمپ</a>
    
                    <a class="btn btn-primary btnbb8 btntt extra-content Tokyo-Extra2-Night mr-5 mt-5" href="rezery.php?item=mountain&time=day">بزن بریم کمپ</a>
                    <a class="btn btn-primary btnbb8 btntt extra-content Tokyo-Extra2-Day mr-5 mt-5" href="rezery.php?item=mountain&time=night">بزن بریم کمپ</a>
                </div>

            </div>
        </div>
        <div class="col-md-8">
            <div class="sub-content London-Extra2-Day London-Extra2-Night">
                <div class="background bg11"></div>
                <div class="background bg12"></div>
            </div>
            <div class="sub-content Paris-Extra2-Day Paris-Extra2-Night">
                <div class="background bg11-n"></div>
                <div class="background bg12-n"></div>
            </div>
            <div class="sub-content Tokyo-Extra2-Day Tokyo-Extra2-Night">
                <div class="background bg11-a"></div>
                <div class="background bg12-a"></div>
            </div>
        </div>
    </div>
</div>
<!-- موبایل -->
<div class="container-fluid mt-2 p-5 con-mobile">
    <div class="row">
        <div class="text-right">
            <div class="extra-content London-Extra2-Day London-Extra2-Night" style="color: #ff4E04 ; font-size: 200px;"><h3>شروع یک ماجرا جویی جدید</h3></div>
            <div class="extra-content Paris-Extra2-Day Paris-Extra2-Night" style="color: #ff4E04 ; font-size: 200px;"><h3>شروع یک ماجرا جویی جدید</h3></div>
            <div class="extra-content Tokyo-Extra2-Day Tokyo-Extra2-Night" style="color: #ff4E04 ; font-size: 200px;"><h3>شروع یک ماجرا جویی جدید</h3></div>

            <div class="extra-content London-Extra2-Day London-Extra2-Night mt-4 ml-3" style="color: #1a6701 ;"><h3><b>شایدم تکرار یک ماجراجویی</b></h3></div>
            <div class="extra-content Paris-Extra2-Day Paris-Extra2-Night mt-4 ml-3" style="color: #ffc107 ;"><h3><b>شایدم تکرار یک ماجراجویی</b></h3></div>
            <div class="extra-content Tokyo-Extra2-Day Tokyo-Extra2-Night mt-4 ml-3" style="color: #365ee2 ;"><h3><b>شایدم تکرار یک ماجراجویی</b></h3></div>
            <div class="text-right mt-5 mr-3" style="font-family: YekanLight;">
                <h6 class="mt-4 pt-2"><b>برای شروع مراحل اجاره کمپ از طریق دکمه</b></h6>
                <h6 class="mt-4 pt-2"><b>زیر وارد صفحه اجاره شوید</b></h6>
                <h6 class="mt-4 pt-2"><b>از صفحه اجاره ، مکان مورد نظر خود را انتخاب کرده</b></h6>
                <h6 class="mt-4 pt-2"><b>و وارد صفحه جزئیات اجاره شوید و اقدام مورد نیاز</b></h6>
                <h6 class="mt-4 pt-2"><b>را انتخاب کنید و مبلغ درج شده را پرداخت کنید</b></h6>
                <h6 class="mt-4 pt-2"><b>و تماااااااااااام ، کمپ شما با موفقیت رزرو شد.</b></h6>

                <div class="text-center">
                    <a class="btn btn-danger btnbb6 btntt extra-content London-Extra2-Night mr-5 mt-5" href="rezery.php?item=tree&time=night">بزن بریم کمپ</a>
                    <a class="btn btn-danger btnbb6 btntt extra-content London-Extra2-Day mr-5 mt-5" href="rezery.php?item=tree&time=day">بزن بریم کمپ</a>
    
                    <a class="btn btn-warning btnbb7 btntt extra-content Paris-Extra2-Day mr-5 mt-5" href="rezery.php?item=cactus&time=day">بزن بریم کمپ</a>
                    <a class="btn btn-warning btnbb7 btntt extra-content Paris-Extra2-Night mr-5 mt-5" href="rezery.php?item=cactus&time=night">بزن بریم کمپ</a>
    
                    <a class="btn btn-primary btnbb8 btntt extra-content Tokyo-Extra2-Night mr-5 mt-5" href="rezery.php?item=mountain&time=day">بزن بریم کمپ</a>
                    <a class="btn btn-primary btnbb8 btntt extra-content Tokyo-Extra2-Day mr-5 mt-5" href="rezery.php?item=mountain&time=night">بزن بریم کمپ</a>
                </div>

            </div>
        </div>
        <div class="col-12">
            <div class="sub-content London-Extra2-Day London-Extra2-Night">
                <div class="background bg11-rm"></div>
                <div class="background bg12-rm"></div>
            </div>
            <div class="sub-content Paris-Extra2-Day Paris-Extra2-Night">
                <div class="background bg11-n"></div>
                <div class="background bg12-n"></div>
            </div>
            <div class="sub-content Tokyo-Extra2-Day Tokyo-Extra2-Night">
                <div class="background bg11-a"></div>
                <div class="background bg12-a"></div>
            </div>
        </div>
    </div>
</div>

<!-- استان گیلان -->
<!-- دستکتاپ -->
<div class="container-fluid text-center con-desktop" style="margin-top: 200px;">
    <h2 style="color: #ff4c00;">شهر آمل در استان گیلان</h2>
    <img src="img/Group 10.png" style="border-radius: 50px;" class="mt-4" width="1300px" alt="">
    <div class="row">
        <div class="col-md-6">
            <br><br>
            <img src="img/Group 12.png" style="border-radius: 50px;" width="500px" height="200px" alt="">
            <br><br>
            <img src="img/Group 15.png" style="border-radius: 50px;" width="500px" height="200px" alt="">
        </div>
        <div class="col-md-6">
            <br><br>
            <img src="img/Group 11.png" style="border-radius: 50px;" width="500px" height="200px" alt="">
            <br><br>
            <img src="img/Group 13.png" style="border-radius: 50px;" width="500px" height="200px" alt="">
        </div>
    </div>
</div>
<!-- موبایل -->
<div class="container-fluid text-center con-mobile" style="margin-top: 200px;">
    <h2 style="color: #ff4c00;">شهر آمل در استان گیلان</h2>
    <img src="img/Group 10.png" style="border-radius: 30px;" class="mt-4" width="400px" alt="">
    <div class="row">
        <div class="col-12">
            <br>
            <img src="img/Group 12.png" style="border-radius: 25px;" width="190px" height="85px" alt="">
            <img src="img/Group 15.png" style="border-radius: 25px;" width="190px" height="85px" alt="">
        </div>
        <div class="col-md-6 col-12">
            <br>
            <img src="img/Group 11.png" style="border-radius: 25px;" width="190px" height="85px" alt="">
            <img src="img/Group 13.png" style="border-radius: 25px;" width="190px" height="85px" alt="">
        </div>
    </div>
</div>

<!-- نظرات مردمی --> 
<!-- سبز روز -->
<div class="container-fluid text-center mt-5 extra-content London-Extra2-Day">

    <h2 class="extra-content London-Extra2-Day London-Extra2-Night mb-4" style="color: #347928;">نظرات مردمی</h2>
    <h2 class="extra-content Paris-Extra2-Day Paris-Extra2-Night mb-4" style="color: #ff6b00;">نظرات مردمی</h2>
    <h2 class="extra-content Tokyo-Extra2-Day Tokyo-Extra2-Night mb-4" style="color: #365ee2;">نظرات مردمی</h2>

    <!-- ردیف اول -->
    <div class="scroll-row row-1 mt-5">
        <div class="scroll-content">
            <div class="card p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #196600;">مسعود پزشکیان</h6>
                        <h6 style="color: #fb7b18;">چهارشنبه 20 فروردین</h6>
                    </div>
                </div>
                <p>ما هم باید یه تفریحی داشته باشیم دیگه دیگه گفتید بعد یک سال ریاست جمهوری کجا بریم از این سایت یک کمپ خوب انتخواب کردیم.</p>
            </div>
            <div class="card p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #196600;">مهران مدیری</h6>
                        <h6 style="color: #fb7b18;">سه‌شنبه 2 فروردین</h6>
                    </div>
                </div>
                <p>ما برای فیلم برداری فیلم قهوه پدری لوکیشن نداشتیم از این سایت یه لوکیشن خوب اجاره کردیم دست شما درد نکنه.</p>
            </div>
            <div class="card p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #196600;">ژاله صامتی</h6>
                        <h6 style="color: #fb7b18;">سه‌شنبه 28 اسفند</h6>
                    </div>
                </div>
                <p>ما با اقای مدیری یه مکان ظبط داشتیم برای قهوه پدری از این سایت اجاره کردن من هم برای خودم و خواندادم از این سایت اجاراه کردم.</p>
            </div>
            <div class="card p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #196600;">علی دایی</h6>
                        <h6 style="color: #fb7b18;">یکشنبه 25 اسفند</h6>
                    </div>
                </div>
                <p>به عنوان پیشکسوت فوتبال دنبال یه جای خوب برای کمپ بودم جایی پیدانکردم از این سایت یک جای خوب انتخواب کردم خیلی عالی.</p>
            </div>
            <div class="card p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #196600;">پژمان جمشیدی</h6>
                        <h6 style="color: #fb7b18;">شنبه 24 اسفند</h6>
                    </div>
                </div>
                <p>ما با خوانواده دنبال یه جایی برای کمپ بودیم که این سایت رو به ما پیشنهاد دادن سایت خیلی خوبیه دست شما درد نکنه.</p>
            </div>
            <div class="card p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #196600;">متین ستوده</h6>
                        <h6 style="color: #fb7b18;">دوشنبه 20 اسفند</h6>
                    </div>
                </div>
                <p>دست شما درد نکنه من تاحالا جایی کمپ نرفته بودم و به کسی اعتماد نداشتم تا و قتی که سایت شمارو دیدن دست شما درد نکنه.</p>
            </div>
            <div class="card p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #196600;">سام درخشانی</h6>
                        <h6 style="color: #fb7b18;">چهارشنبه 12 اسفند</h6>
                    </div>
                </div>
                <p>کپینگ مکان های خیلی خوبی داره من خودم این سایت رو به آقای مدیری گفتم که برای فیلم برداری قهوه پدری باشه خیلی عالی.</p>
            </div>
            <div class="card p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #196600;">علیرضا جهان بخش</h6>
                        <h6 style="color: #fb7b18;">سه‌شنبه 8 اسفند</h6>
                    </div>
                </div>
                <p>دیگه بعد از بازی های زیاد می خواستم استراحت کنم این سایت رو انتخواب کردم مکان های خیلی خوبی داره مرسی.</p>
            </div>
            <div class="card p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #196600;">نرگس محمدی</h6>
                        <h6 style="color: #fb7b18;">سه‌شنبه 5 اسفند</h6>
                    </div>
                </div>
                <p>من با همسرم رفته بودم یکی از مکان های این کمپ خیلی رازی بودیم مرسی دست شما درد نکنه بابت زدن این سایت</p>
            </div>
            <div class="card p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #196600;">علی اوجی</h6>
                        <h6 style="color: #fb7b18;">یکشنبه 5 اسفند</h6>
                    </div>
                </div>
                <p>دسستون درد نکنه بابت زدن این سایت من از الان دیگه نمی تونم ماهی دو بار کمپ نرم دست شما درد نکنه مرسی بابت سایتتون.</p>
            </div>
            <div class="card p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #196600;">قدرت الله ایزدی</h6>
                        <h6 style="color: #fb7b18;">شنبه 29 بهمن</h6>
                    </div>
                </div>
                <p>من خودم خیلی اهل کمپ نبودم ولی با کمپینگ اصلا اذیت نشدم و کامل با آرامش بودم و حس خیلی خوبی بود.</p>
            </div>
            <div class="card p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #196600;">گیتی قاسمی</h6>
                        <h6 style="color: #fb7b18;">دوشنبه 25 بهمن</h6>
                    </div>
                </div>
                <p>دست شما درد نکنه من تاحالا جایی کمپ نرفته بودم و به کسی اعتماد نداشتم تا و قتی که سایت شمارو دیدن دست شما درد نکنه.</p>
            </div>
        </div>
    </div>

    <!-- ردیف دوم -->
    <div class="scroll-row row-2">
        <div class="scroll-content">
            <div class="card p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #196600;">محمد صالح طابی</h6>
                        <h6 style="color: #fb7b18;">چهارشنبه 20 فروردین</h6>
                    </div>
                </div>
                <p>ما دیدم بچه ها زحمت کشیدن گفتیم خب حداقل ما هم یه کمکی بکنیم برای چند روز یکی مکان های کویر لوت رو انتخواب کردیم.</p>
            </div>
            <div class="card p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #196600;">علی ابراهیمی</h6>
                        <h6 style="color: #fb7b18;">سه‌شنبه 29 اسفند</h6>
                    </div>
                </div>
                <p>من خودم خیلی اهل کمپ نبودم ولی با کمپینگ اصلا اذیت نشدم و کامل با آرامش بودم و حس خیلی خوبی بود.</p>
            </div>
            <div class="card p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #196600;">فاطمه یاسینی</h6>
                        <h6 style="color: #fb7b18;">سه‌شنبه 5 اسفند</h6>
                    </div>
                </div>
                <p>دست شما درد نکنه من تاحالا جایی کمپ نرفته بودم و به کسی اعتماد نداشتم تا و قتی که سایت شمارو دیدن دست شما درد نکنه.</p>
            </div>
            <div class="card p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #196600;">علی بهمن آبادی</h6>
                        <h6 style="color: #fb7b18;">یکشنبه 15 بهمن</h6>
                    </div>
                </div>
                <p>ما دیدیم یه پیامک برای من امد نوشته بود کمپ رایگان برای شما ما هم دیدیم رایگان بود با امین و اردستانی و مخلصی رفتیم.</p>
            </div>
            <div class="card p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #196600;">امین دویران</h6>
                        <h6 style="color: #fb7b18;">شنبه 10 بهمن</h6>
                    </div>
                </div>
                <p>ما که دیدم اوینی اول نمیشیم گفتیم حد اقل از سایت برنده آوینی یه استفاده ایم بکنیم ما هم یه مکان داخل کرج گرفتیم.</p>
            </div>
            <div class="card p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #196600;">سارا نیکنامی</h6>
                        <h6 style="color: #fb7b18;">دوشنبه 9 بهمن</h6>
                    </div>
                </div>
                <p>من با همسرم زیاد کمپ رفته بودم ولی اصلا رازی نبودم تا وقتی که با این سایت آشناشدم خیلی خوب بود و مکان های خوبی داشت.</p>
            </div>
            <div class="card p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #196600;">امین گودرزی</h6>
                        <h6 style="color: #fb7b18;">سه‌شنبه 3 بهمن</h6>
                    </div>
                </div>
                <p>دیگه دیدیم قراره یه نفر رو داخل آوینی اول کنیم دیدم کی از همه بیشتر هدیه میده اون رو اول کنیم که کمپ به نظرم از همه بهتر بود.</p>
            </div>
            <div class="card p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #196600;">متین مومرشفان</h6>
                        <h6 style="color: #fb7b18;">چهارشنبه 5 بهمن</h6>
                    </div>
                </div>
                <p>من و امین با هم خیلی حرف زدم که آقا کجا بریم خوبه من نمی دونسم که کجا بریمو از کجا رزرو کنیم امین اینجا رو معرفی کرد .</p>
            </div>
            <div class="card p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #196600;">فاطمه اقایی</h6>
                        <h6 style="color: #fb7b18;">سه‌شنبه 1 بهمن</h6>
                    </div>
                </div>
                <p>دست شما درد نکنه من تاحالا جایی کمپ نرفته بودم و به کسی اعتماد نداشتم تا و قتی که سایت شمارو دیدن دست شما درد نکنه.</p>
            </div>
            <div class="card p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #196600;">اردستانی</h6>
                        <h6 style="color: #fb7b18;">یکشنبه 29 دی</h6>
                    </div>
                </div>
                <p>دیگه باید نمره های بچه هارو بالا می دادیم گفتیم چی کار کنیم گفتیم حداقل یه کمپ رایگان بریم دیگه چی کار میشه کرد.</p>
            </div>
            <div class="card p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #196600;">محمد مهدی کریمی</h6>
                        <h6 style="color: #fb7b18;">شنبه 20 دی</h6>
                    </div>
                </div>
                <p>من خودم خیلی اهل کمپ نبودم ولی با کمپینگ اصلا اذیت نشدم و کامل با آرامش بودم و حس خیلی خوبی بود.</p>
            </div>
            <div class="card p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #196600;">سارا شاهی</h6>
                        <h6 style="color: #fb7b18;">دوشنبه 20 دی</h6>
                    </div>
                </div>
                <p>دست شما درد نکنه من تاحالا جایی کمپ نرفته بودم و به کسی اعتماد نداشتم تا و قتی که سایت شمارو دیدن دست شما درد نکنه.</p>
            </div>
        </div>
    </div>

    <!-- ردیف سوم -->
    <div class="scroll-row row-3">
        <div class="scroll-content">
            <div class="card p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #196600;">علیرضا انصاریان</h6>
                        <h6 style="color: #fb7b18;">چهارشنبه 20 فروردین</h6>
                    </div>
                </div>
                <p>ما برای تعطیلات یه جا می خواستیم که این سایت رو دیدم مرسی بابت زدن ای سایت دست شما درد نکنه.</p>
            </div>
            <div class="card p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #196600;">حسین میرزایی</h6>
                        <h6 style="color: #fb7b18;">سه‌شنبه 29 اسفند</h6>
                    </div>
                </div>
                <p>من خودم خیلی اهل کمپ نبودم ولی با کمپینگ اصلا اذیت نشدم و کامل با آرامش بودم و حس خیلی خوبی بود.</p>
            </div>
            <div class="card p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #196600;">معصومه مرادی</h6>
                        <h6 style="color: #fb7b18;">سه‌شنبه 5 مهر</h6>
                    </div>
                </div>
                <p>دست شما درد نکنه من تاحالا جایی کمپ نرفته بودم و به کسی اعتماد نداشتم تا و قتی که سایت شمارو دیدن دست شما درد نکنه.</p>
            </div>
            <div class="card p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #196600;">محسن نیکخاه</h6>
                        <h6 style="color: #fb7b18;">یکشنبه 15 اردیبهشت</h6>
                    </div>
                </div>
                <p>دسستون درد نکنه بابت زدن این سایت من از الان دیگه نمی تونم ماهی دو بار کمپ نرم دست شما درد نکنه مرسی بابت سایتتون.</p>
            </div>
            <div class="card p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #196600;">علی کریمی</h6>
                        <h6 style="color: #fb7b18;">شنبه 10 تیر</h6>
                    </div>
                </div>
                <p>من خودم خیلی اهل کمپ نبودم ولی با کمپینگ اصلا اذیت نشدم و کامل با آرامش بودم و حس خیلی خوبی بود.</p>
            </div>
            <div class="card p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #196600;">عسل اسمانی</h6>
                        <h6 style="color: #fb7b18;">دوشنبه 20 آبان</h6>
                    </div>
                </div>
                <p>دست شما درد نکنه من تاحالا جایی کمپ نرفته بودم و به کسی اعتماد نداشتم تا و قتی که سایت شمارو دیدن دست شما درد نکنه.</p>
            </div>
            <div class="card p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #196600;">امیرحسین ابویی</h6>
                        <h6 style="color: #fb7b18;">چهارشنبه 20 فروردین</h6>
                    </div>
                </div>
                <p>دسستون درد نکنه بابت زدن این سایت من از الان دیگه نمی تونم ماهی دو بار کمپ نرم دست شما درد نکنه مرسی بابت سایتتون.</p>
            </div>
            <div class="card p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #196600;">علی اقایی</h6>
                        <h6 style="color: #fb7b18;">سه‌شنبه 29 اسفند</h6>
                    </div>
                </div>
                <p>من خودم خیلی اهل کمپ نبودم ولی با کمپینگ اصلا اذیت نشدم و کامل با آرامش بودم و حس خیلی خوبی بود.</p>
            </div>
            <div class="card p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #196600;">فاطی سادات</h6>
                        <h6 style="color: #fb7b18;">سه‌شنبه 5 مهر</h6>
                    </div>
                </div>
                <p>دست شما درد نکنه من تاحالا جایی کمپ نرفته بودم و به کسی اعتماد نداشتم تا و قتی که سایت شمارو دیدن دست شما درد نکنه.</p>
            </div>
            <div class="card p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #196600;">یاسر غروی</h6>
                        <h6 style="color: #fb7b18;">یکشنبه 15 اردیبهشت</h6>
                    </div>
                </div>
                <p>دسستون درد نکنه بابت زدن این سایت من از الان دیگه نمی تونم ماهی دو بار کمپ نرم دست شما درد نکنه مرسی بابت سایتتون.</p>
            </div>
            <div class="card p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #196600;">علی طارمی</h6>
                        <h6 style="color: #fb7b18;">شنبه 10 تیر</h6>
                    </div>
                </div>
                <p>من خودم خیلی اهل کمپ نبودم ولی با کمپینگ اصلا اذیت نشدم و کامل با آرامش بودم و حس خیلی خوبی بود.</p>
            </div>
            <div class="card p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #196600;">طلا عسل آبادی</h6>
                        <h6 style="color: #fb7b18;">دوشنبه 20 آبان</h6>
                    </div>
                </div>
                <p>دست شما درد نکنه من تاحالا جایی کمپ نرفته بودم و به کسی اعتماد نداشتم تا و قتی که سایت شمارو دیدن دست شما درد نکنه.</p>
            </div>
        </div>
    </div>
</div>
<!-- سبز شب -->
<div class="container-fluid text-center mt-5 extra-content London-Extra2-Night">

    <h2 class="extra-content London-Extra2-Day London-Extra2-Night mb-4" style="color: #347928;">نظرات مردمی</h2>
    <h2 class="extra-content Paris-Extra2-Day Paris-Extra2-Night mb-4" style="color: #ff6b00;">نظرات مردمی</h2>
    <h2 class="extra-content Tokyo-Extra2-Day Tokyo-Extra2-Night mb-4" style="color: #365ee2;">نظرات مردمی</h2>

    <!-- ردیف اول -->
    <div class="scroll-row row-1 mt-5">
        <div class="scroll-content">
            <div class="card2 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #c0eba5;">مسعود پزشکیان</h6>
                        <h6 style="color: #fb7b18;">چهارشنبه 20 فروردین</h6>
                    </div>
                </div>
                <p>ما هم باید یه تفریحی داشته باشیم دیگه دیگه گفتید بعد یک سال ریاست جمهوری کجا بریم از این سایت یک کمپ خوب انتخواب کردیم.</p>
            </div>
            <div class="card2 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #c0eba5;">مهران مدیری</h6>
                        <h6 style="color: #fb7b18;">سه‌شنبه 2 فروردین</h6>
                    </div>
                </div>
                <p>ما برای فیلم برداری فیلم قهوه پدری لوکیشن نداشتیم از این سایت یه لوکیشن خوب اجاره کردیم دست شما درد نکنه.</p>
            </div>
            <div class="card2 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #c0eba5;">ژاله صامتی</h6>
                        <h6 style="color: #fb7b18;">سه‌شنبه 28 اسفند</h6>
                    </div>
                </div>
                <p>ما با اقای مدیری یه مکان ظبط داشتیم برای قهوه پدری از این سایت اجاره کردن من هم برای خودم و خواندادم از این سایت اجاراه کردم.</p>
            </div>
            <div class="card2 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #c0eba5;">علی دایی</h6>
                        <h6 style="color: #fb7b18;">یکشنبه 25 اسفند</h6>
                    </div>
                </div>
                <p>به عنوان پیشکسوت فوتبال دنبال یه جای خوب برای کمپ بودم جایی پیدانکردم از این سایت یک جای خوب انتخواب کردم خیلی عالی.</p>
            </div>
            <div class="card2 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #c0eba5;">پژمان جمشیدی</h6>
                        <h6 style="color: #fb7b18;">شنبه 24 اسفند</h6>
                    </div>
                </div>
                <p>ما با خوانواده دنبال یه جایی برای کمپ بودیم که این سایت رو به ما پیشنهاد دادن سایت خیلی خوبیه دست شما درد نکنه.</p>
            </div>
            <div class="card2 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #c0eba5;">متین ستوده</h6>
                        <h6 style="color: #fb7b18;">دوشنبه 20 اسفند</h6>
                    </div>
                </div>
                <p>دست شما درد نکنه من تاحالا جایی کمپ نرفته بودم و به کسی اعتماد نداشتم تا و قتی که سایت شمارو دیدن دست شما درد نکنه.</p>
            </div>
            <div class="card2 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #c0eba5;">سام درخشانی</h6>
                        <h6 style="color: #fb7b18;">چهارشنبه 12 اسفند</h6>
                    </div>
                </div>
                <p>کپینگ مکان های خیلی خوبی داره من خودم این سایت رو به آقای مدیری گفتم که برای فیلم برداری قهوه پدری باشه خیلی عالی.</p>
            </div>
            <div class="card2 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #c0eba5;">علیرضا جهان بخش</h6>
                        <h6 style="color: #fb7b18;">سه‌شنبه 8 اسفند</h6>
                    </div>
                </div>
                <p>دیگه بعد از بازی های زیاد می خواستم استراحت کنم این سایت رو انتخواب کردم مکان های خیلی خوبی داره مرسی.</p>
            </div>
            <div class="card2 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #c0eba5;">نرگس محمدی</h6>
                        <h6 style="color: #fb7b18;">سه‌شنبه 5 اسفند</h6>
                    </div>
                </div>
                <p>من با همسرم رفته بودم یکی از مکان های این کمپ خیلی رازی بودیم مرسی دست شما درد نکنه بابت زدن این سایت</p>
            </div>
            <div class="card2 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #c0eba5;">علی اوجی</h6>
                        <h6 style="color: #fb7b18;">یکشنبه 5 اسفند</h6>
                    </div>
                </div>
                <p>دسستون درد نکنه بابت زدن این سایت من از الان دیگه نمی تونم ماهی دو بار کمپ نرم دست شما درد نکنه مرسی بابت سایتتون.</p>
            </div>
            <div class="card2 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #c0eba5;">قدرت الله ایزدی</h6>
                        <h6 style="color: #fb7b18;">شنبه 29 بهمن</h6>
                    </div>
                </div>
                <p>من خودم خیلی اهل کمپ نبودم ولی با کمپینگ اصلا اذیت نشدم و کامل با آرامش بودم و حس خیلی خوبی بود.</p>
            </div>
            <div class="card2 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #c0eba5;">گیتی قاسمی</h6>
                        <h6 style="color: #fb7b18;">دوشنبه 25 بهمن</h6>
                    </div>
                </div>
                <p>دست شما درد نکنه من تاحالا جایی کمپ نرفته بودم و به کسی اعتماد نداشتم تا و قتی که سایت شمارو دیدن دست شما درد نکنه.</p>
            </div>
        </div>
    </div>

    <!-- ردیف دوم -->
    <div class="scroll-row row-2">
        <div class="scroll-content">
            <div class="card2 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #c0eba5;">محمد صالح طابی</h6>
                        <h6 style="color: #fb7b18;">چهارشنبه 20 فروردین</h6>
                    </div>
                </div>
                <p>ما دیدم بچه ها زحمت کشیدن گفتیم خب حداقل ما هم یه کمکی بکنیم برای چند روز یکی مکان های کویر لوت رو انتخواب کردیم.</p>
            </div>
            <div class="card2 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #c0eba5;">علی ابراهیمی</h6>
                        <h6 style="color: #fb7b18;">سه‌شنبه 29 اسفند</h6>
                    </div>
                </div>
                <p>من خودم خیلی اهل کمپ نبودم ولی با کمپینگ اصلا اذیت نشدم و کامل با آرامش بودم و حس خیلی خوبی بود.</p>
            </div>
            <div class="card2 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #c0eba5;">فاطمه یاسینی</h6>
                        <h6 style="color: #fb7b18;">سه‌شنبه 5 اسفند</h6>
                    </div>
                </div>
                <p>دست شما درد نکنه من تاحالا جایی کمپ نرفته بودم و به کسی اعتماد نداشتم تا و قتی که سایت شمارو دیدن دست شما درد نکنه.</p>
            </div>
            <div class="card2 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #c0eba5;">علی بهمن آبادی</h6>
                        <h6 style="color: #fb7b18;">یکشنبه 15 بهمن</h6>
                    </div>
                </div>
                <p>ما دیدیم یه پیامک برای من امد نوشته بود کمپ رایگان برای شما ما هم دیدیم رایگان بود با امین و اردستانی و مخلصی رفتیم.</p>
            </div>
            <div class="card2 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #c0eba5;">امین دویران</h6>
                        <h6 style="color: #fb7b18;">شنبه 10 بهمن</h6>
                    </div>
                </div>
                <p>ما که دیدم اوینی اول نمیشیم گفتیم حد اقل از سایت برنده آوینی یه استفاده ایم بکنیم ما هم یه مکان داخل کرج گرفتیم.</p>
            </div>
            <div class="card2 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #c0eba5;">سارا نیکنامی</h6>
                        <h6 style="color: #fb7b18;">دوشنبه 9 بهمن</h6>
                    </div>
                </div>
                <p>من با همسرم زیاد کمپ رفته بودم ولی اصلا رازی نبودم تا وقتی که با این سایت آشناشدم خیلی خوب بود و مکان های خوبی داشت.</p>
            </div>
            <div class="card2 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #c0eba5;">امین گودرزی</h6>
                        <h6 style="color: #fb7b18;">سه‌شنبه 3 بهمن</h6>
                    </div>
                </div>
                <p>دیگه دیدیم قراره یه نفر رو داخل آوینی اول کنیم دیدم کی از همه بیشتر هدیه میده اون رو اول کنیم که کمپ به نظرم از همه بهتر بود.</p>
            </div>
            <div class="card2 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #c0eba5;">متین مومرشفان</h6>
                        <h6 style="color: #fb7b18;">چهارشنبه 5 بهمن</h6>
                    </div>
                </div>
                <p>من و امین با هم خیلی حرف زدم که آقا کجا بریم خوبه من نمی دونسم که کجا بریمو از کجا رزرو کنیم امین اینجا رو معرفی کرد .</p>
            </div>
            <div class="card2 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #c0eba5;">فاطمه اقایی</h6>
                        <h6 style="color: #fb7b18;">سه‌شنبه 1 بهمن</h6>
                    </div>
                </div>
                <p>دست شما درد نکنه من تاحالا جایی کمپ نرفته بودم و به کسی اعتماد نداشتم تا و قتی که سایت شمارو دیدن دست شما درد نکنه.</p>
            </div>
            <div class="card2 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #c0eba5;">اردستانی</h6>
                        <h6 style="color: #fb7b18;">یکشنبه 29 دی</h6>
                    </div>
                </div>
                <p>دیگه باید نمره های بچه هارو بالا می دادیم گفتیم چی کار کنیم گفتیم حداقل یه کمپ رایگان بریم دیگه چی کار میشه کرد.</p>
            </div>
            <div class="card2 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #c0eba5;">محمد مهدی کریمی</h6>
                        <h6 style="color: #fb7b18;">شنبه 20 دی</h6>
                    </div>
                </div>
                <p>من خودم خیلی اهل کمپ نبودم ولی با کمپینگ اصلا اذیت نشدم و کامل با آرامش بودم و حس خیلی خوبی بود.</p>
            </div>
            <div class="card2 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #c0eba5;">سارا شاهی</h6>
                        <h6 style="color: #fb7b18;">دوشنبه 20 دی</h6>
                    </div>
                </div>
                <p>دست شما درد نکنه من تاحالا جایی کمپ نرفته بودم و به کسی اعتماد نداشتم تا و قتی که سایت شمارو دیدن دست شما درد نکنه.</p>
            </div>
        </div>
    </div>

    <!-- ردیف سوم -->
    <div class="scroll-row row-3">
        <div class="scroll-content">
            <div class="card2 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #c0eba5;">علیرضا انصاریان</h6>
                        <h6 style="color: #fb7b18;">چهارشنبه 20 فروردین</h6>
                    </div>
                </div>
                <p>ما برای تعطیلات یه جا می خواستیم که این سایت رو دیدم مرسی بابت زدن ای سایت دست شما درد نکنه.</p>
            </div>
            <div class="card2 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #c0eba5;">حسین میرزایی</h6>
                        <h6 style="color: #fb7b18;">سه‌شنبه 29 اسفند</h6>
                    </div>
                </div>
                <p>من خودم خیلی اهل کمپ نبودم ولی با کمپینگ اصلا اذیت نشدم و کامل با آرامش بودم و حس خیلی خوبی بود.</p>
            </div>
            <div class="card2 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #c0eba5;">معصومه مرادی</h6>
                        <h6 style="color: #fb7b18;">سه‌شنبه 5 مهر</h6>
                    </div>
                </div>
                <p>دست شما درد نکنه من تاحالا جایی کمپ نرفته بودم و به کسی اعتماد نداشتم تا و قتی که سایت شمارو دیدن دست شما درد نکنه.</p>
            </div>
            <div class="card2 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #c0eba5;">محسن نیکخاه</h6>
                        <h6 style="color: #fb7b18;">یکشنبه 15 اردیبهشت</h6>
                    </div>
                </div>
                <p>دسستون درد نکنه بابت زدن این سایت من از الان دیگه نمی تونم ماهی دو بار کمپ نرم دست شما درد نکنه مرسی بابت سایتتون.</p>
            </div>
            <div class="card2 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #c0eba5;">علی کریمی</h6>
                        <h6 style="color: #fb7b18;">شنبه 10 تیر</h6>
                    </div>
                </div>
                <p>من خودم خیلی اهل کمپ نبودم ولی با کمپینگ اصلا اذیت نشدم و کامل با آرامش بودم و حس خیلی خوبی بود.</p>
            </div>
            <div class="card2 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #c0eba5;">عسل اسمانی</h6>
                        <h6 style="color: #fb7b18;">دوشنبه 20 آبان</h6>
                    </div>
                </div>
                <p>دست شما درد نکنه من تاحالا جایی کمپ نرفته بودم و به کسی اعتماد نداشتم تا و قتی که سایت شمارو دیدن دست شما درد نکنه.</p>
            </div>
            <div class="card2 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #c0eba5;">امیرحسین ابویی</h6>
                        <h6 style="color: #fb7b18;">چهارشنبه 20 فروردین</h6>
                    </div>
                </div>
                <p>دسستون درد نکنه بابت زدن این سایت من از الان دیگه نمی تونم ماهی دو بار کمپ نرم دست شما درد نکنه مرسی بابت سایتتون.</p>
            </div>
            <div class="card2 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #c0eba5;">علی اقایی</h6>
                        <h6 style="color: #fb7b18;">سه‌شنبه 29 اسفند</h6>
                    </div>
                </div>
                <p>من خودم خیلی اهل کمپ نبودم ولی با کمپینگ اصلا اذیت نشدم و کامل با آرامش بودم و حس خیلی خوبی بود.</p>
            </div>
            <div class="card2 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #c0eba5;">فاطی سادات</h6>
                        <h6 style="color: #fb7b18;">سه‌شنبه 5 مهر</h6>
                    </div>
                </div>
                <p>دست شما درد نکنه من تاحالا جایی کمپ نرفته بودم و به کسی اعتماد نداشتم تا و قتی که سایت شمارو دیدن دست شما درد نکنه.</p>
            </div>
            <div class="card2 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #c0eba5;">یاسر غروی</h6>
                        <h6 style="color: #fb7b18;">یکشنبه 15 اردیبهشت</h6>
                    </div>
                </div>
                <p>دسستون درد نکنه بابت زدن این سایت من از الان دیگه نمی تونم ماهی دو بار کمپ نرم دست شما درد نکنه مرسی بابت سایتتون.</p>
            </div>
            <div class="card2 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #c0eba5;">علی طارمی</h6>
                        <h6 style="color: #fb7b18;">شنبه 10 تیر</h6>
                    </div>
                </div>
                <p>من خودم خیلی اهل کمپ نبودم ولی با کمپینگ اصلا اذیت نشدم و کامل با آرامش بودم و حس خیلی خوبی بود.</p>
            </div>
            <div class="card2 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #c0eba5;">طلا عسل آبادی</h6>
                        <h6 style="color: #fb7b18;">دوشنبه 20 آبان</h6>
                    </div>
                </div>
                <p>دست شما درد نکنه من تاحالا جایی کمپ نرفته بودم و به کسی اعتماد نداشتم تا و قتی که سایت شمارو دیدن دست شما درد نکنه.</p>
            </div>
        </div>
    </div>
</div>
<!-- نارنجی روز -->
<div class="container-fluid text-center mt-5 extra-content Paris-Extra2-Day">

    <h2 class="extra-content London-Extra2-Day London-Extra2-Night mb-4" style="color: #347928;">نظرات مردمی</h2>
    <h2 class="extra-content Paris-Extra2-Day Paris-Extra2-Night mb-4" style="color: #ff6b00;">نظرات مردمی</h2>
    <h2 class="extra-content Tokyo-Extra2-Day Tokyo-Extra2-Night mb-4" style="color: #365ee2;">نظرات مردمی</h2>

    <!-- ردیف اول -->
    <div class="scroll-row row-1 mt-5">
        <div class="scroll-content">
            <div class="card3 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">مسعود پزشکیان</h6>
                        <h6 style="color: #fec35e;">چهارشنبه 20 فروردین</h6>
                    </div>
                </div>
                <p>ما هم باید یه تفریحی داشته باشیم دیگه دیگه گفتید بعد یک سال ریاست جمهوری کجا بریم از این سایت یک کمپ خوب انتخواب کردیم.</p>
            </div>
            <div class="card3 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">مهران مدیری</h6>
                        <h6 style="color: #fec35e;">سه‌شنبه 2 فروردین</h6>
                    </div>
                </div>
                <p>ما برای فیلم برداری فیلم قهوه پدری لوکیشن نداشتیم از این سایت یه لوکیشن خوب اجاره کردیم دست شما درد نکنه.</p>
            </div>
            <div class="card3 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">ژاله صامتی</h6>
                        <h6 style="color: #fec35e;">سه‌شنبه 28 اسفند</h6>
                    </div>
                </div>
                <p>ما با اقای مدیری یه مکان ظبط داشتیم برای قهوه پدری از این سایت اجاره کردن من هم برای خودم و خواندادم از این سایت اجاراه کردم.</p>
            </div>
            <div class="card3 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">علی دایی</h6>
                        <h6 style="color: #fec35e;">یکشنبه 25 اسفند</h6>
                    </div>
                </div>
                <p>به عنوان پیشکسوت فوتبال دنبال یه جای خوب برای کمپ بودم جایی پیدانکردم از این سایت یک جای خوب انتخواب کردم خیلی عالی.</p>
            </div>
            <div class="card3 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">پژمان جمشیدی</h6>
                        <h6 style="color: #fec35e;">شنبه 24 اسفند</h6>
                    </div>
                </div>
                <p>ما با خوانواده دنبال یه جایی برای کمپ بودیم که این سایت رو به ما پیشنهاد دادن سایت خیلی خوبیه دست شما درد نکنه.</p>
            </div>
            <div class="card3 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">متین ستوده</h6>
                        <h6 style="color: #fec35e;">دوشنبه 20 اسفند</h6>
                    </div>
                </div>
                <p>دست شما درد نکنه من تاحالا جایی کمپ نرفته بودم و به کسی اعتماد نداشتم تا و قتی که سایت شمارو دیدن دست شما درد نکنه.</p>
            </div>
            <div class="card3 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">سام درخشانی</h6>
                        <h6 style="color: #fec35e;">چهارشنبه 12 اسفند</h6>
                    </div>
                </div>
                <p>کپینگ مکان های خیلی خوبی داره من خودم این سایت رو به آقای مدیری گفتم که برای فیلم برداری قهوه پدری باشه خیلی عالی.</p>
            </div>
            <div class="card3 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">علیرضا جهان بخش</h6>
                        <h6 style="color: #fec35e;">سه‌شنبه 8 اسفند</h6>
                    </div>
                </div>
                <p>دیگه بعد از بازی های زیاد می خواستم استراحت کنم این سایت رو انتخواب کردم مکان های خیلی خوبی داره مرسی.</p>
            </div>
            <div class="card3 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">نرگس محمدی</h6>
                        <h6 style="color: #fec35e;">سه‌شنبه 5 اسفند</h6>
                    </div>
                </div>
                <p>من با همسرم رفته بودم یکی از مکان های این کمپ خیلی رازی بودیم مرسی دست شما درد نکنه بابت زدن این سایت</p>
            </div>
            <div class="card3 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">علی اوجی</h6>
                        <h6 style="color: #fec35e;">یکشنبه 5 اسفند</h6>
                    </div>
                </div>
                <p>دسستون درد نکنه بابت زدن این سایت من از الان دیگه نمی تونم ماهی دو بار کمپ نرم دست شما درد نکنه مرسی بابت سایتتون.</p>
            </div>
            <div class="card3 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">قدرت الله ایزدی</h6>
                        <h6 style="color: #fec35e;">شنبه 29 بهمن</h6>
                    </div>
                </div>
                <p>من خودم خیلی اهل کمپ نبودم ولی با کمپینگ اصلا اذیت نشدم و کامل با آرامش بودم و حس خیلی خوبی بود.</p>
            </div>
            <div class="card3 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">گیتی قاسمی</h6>
                        <h6 style="color: #fec35e;">دوشنبه 25 بهمن</h6>
                    </div>
                </div>
                <p>دست شما درد نکنه من تاحالا جایی کمپ نرفته بودم و به کسی اعتماد نداشتم تا و قتی که سایت شمارو دیدن دست شما درد نکنه.</p>
            </div>
        </div>
    </div>

    <!-- ردیف دوم -->
    <div class="scroll-row row-2">
        <div class="scroll-content">
            <div class="card3 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">محمد صالح طابی</h6>
                        <h6 style="color: #fec35e;">چهارشنبه 20 فروردین</h6>
                    </div>
                </div>
                <p>ما دیدم بچه ها زحمت کشیدن گفتیم خب حداقل ما هم یه کمکی بکنیم برای چند روز یکی مکان های کویر لوت رو انتخواب کردیم.</p>
            </div>
            <div class="card3 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">علی ابراهیمی</h6>
                        <h6 style="color: #fec35e;">سه‌شنبه 29 اسفند</h6>
                    </div>
                </div>
                <p>من خودم خیلی اهل کمپ نبودم ولی با کمپینگ اصلا اذیت نشدم و کامل با آرامش بودم و حس خیلی خوبی بود.</p>
            </div>
            <div class="card3 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">فاطمه یاسینی</h6>
                        <h6 style="color: #fec35e;">سه‌شنبه 5 اسفند</h6>
                    </div>
                </div>
                <p>دست شما درد نکنه من تاحالا جایی کمپ نرفته بودم و به کسی اعتماد نداشتم تا و قتی که سایت شمارو دیدن دست شما درد نکنه.</p>
            </div>
            <div class="card3 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">علی بهمن آبادی</h6>
                        <h6 style="color: #fec35e;">یکشنبه 15 بهمن</h6>
                    </div>
                </div>
                <p>ما دیدیم یه پیامک برای من امد نوشته بود کمپ رایگان برای شما ما هم دیدیم رایگان بود با امین و اردستانی و مخلصی رفتیم.</p>
            </div>
            <div class="card3 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">امین دویران</h6>
                        <h6 style="color: #fec35e;">شنبه 10 بهمن</h6>
                    </div>
                </div>
                <p>ما که دیدم اوینی اول نمیشیم گفتیم حد اقل از سایت برنده آوینی یه استفاده ایم بکنیم ما هم یه مکان داخل کرج گرفتیم.</p>
            </div>
            <div class="card3 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">سارا نیکنامی</h6>
                        <h6 style="color: #fec35e;">دوشنبه 9 بهمن</h6>
                    </div>
                </div>
                <p>من با همسرم زیاد کمپ رفته بودم ولی اصلا رازی نبودم تا وقتی که با این سایت آشناشدم خیلی خوب بود و مکان های خوبی داشت.</p>
            </div>
            <div class="card3 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">امین گودرزی</h6>
                        <h6 style="color: #fec35e;">سه‌شنبه 3 بهمن</h6>
                    </div>
                </div>
                <p>دیگه دیدیم قراره یه نفر رو داخل آوینی اول کنیم دیدم کی از همه بیشتر هدیه میده اون رو اول کنیم که کمپ به نظرم از همه بهتر بود.</p>
            </div>
            <div class="card3 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">متین مومرشفان</h6>
                        <h6 style="color: #fec35e;">چهارشنبه 5 بهمن</h6>
                    </div>
                </div>
                <p>من و امین با هم خیلی حرف زدم که آقا کجا بریم خوبه من نمی دونسم که کجا بریمو از کجا رزرو کنیم امین اینجا رو معرفی کرد .</p>
            </div>
            <div class="card3 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">فاطمه اقایی</h6>
                        <h6 style="color: #fec35e;">سه‌شنبه 1 بهمن</h6>
                    </div>
                </div>
                <p>دست شما درد نکنه من تاحالا جایی کمپ نرفته بودم و به کسی اعتماد نداشتم تا و قتی که سایت شمارو دیدن دست شما درد نکنه.</p>
            </div>
            <div class="card3 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">اردستانی</h6>
                        <h6 style="color: #fec35e;">یکشنبه 29 دی</h6>
                    </div>
                </div>
                <p>دیگه باید نمره های بچه هارو بالا می دادیم گفتیم چی کار کنیم گفتیم حداقل یه کمپ رایگان بریم دیگه چی کار میشه کرد.</p>
            </div>
            <div class="card3 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">محمد مهدی کریمی</h6>
                        <h6 style="color: #fec35e;">شنبه 20 دی</h6>
                    </div>
                </div>
                <p>من خودم خیلی اهل کمپ نبودم ولی با کمپینگ اصلا اذیت نشدم و کامل با آرامش بودم و حس خیلی خوبی بود.</p>
            </div>
            <div class="card3 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">سارا شاهی</h6>
                        <h6 style="color: #fec35e;">دوشنبه 20 دی</h6>
                    </div>
                </div>
                <p>دست شما درد نکنه من تاحالا جایی کمپ نرفته بودم و به کسی اعتماد نداشتم تا و قتی که سایت شمارو دیدن دست شما درد نکنه.</p>
            </div>
        </div>
    </div>

    <!-- ردیف سوم -->
    <div class="scroll-row row-3">
        <div class="scroll-content">
            <div class="card3 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">علیرضا انصاریان</h6>
                        <h6 style="color: #fec35e;">چهارشنبه 20 فروردین</h6>
                    </div>
                </div>
                <p>ما برای تعطیلات یه جا می خواستیم که این سایت رو دیدم مرسی بابت زدن ای سایت دست شما درد نکنه.</p>
            </div>
            <div class="card3 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">حسین میرزایی</h6>
                        <h6 style="color: #fec35e;">سه‌شنبه 29 اسفند</h6>
                    </div>
                </div>
                <p>من خودم خیلی اهل کمپ نبودم ولی با کمپینگ اصلا اذیت نشدم و کامل با آرامش بودم و حس خیلی خوبی بود.</p>
            </div>
            <div class="card3 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">معصومه مرادی</h6>
                        <h6 style="color: #fec35e;">سه‌شنبه 5 مهر</h6>
                    </div>
                </div>
                <p>دست شما درد نکنه من تاحالا جایی کمپ نرفته بودم و به کسی اعتماد نداشتم تا و قتی که سایت شمارو دیدن دست شما درد نکنه.</p>
            </div>
            <div class="card3 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">محسن نیکخاه</h6>
                        <h6 style="color: #fec35e;">یکشنبه 15 اردیبهشت</h6>
                    </div>
                </div>
                <p>دسستون درد نکنه بابت زدن این سایت من از الان دیگه نمی تونم ماهی دو بار کمپ نرم دست شما درد نکنه مرسی بابت سایتتون.</p>
            </div>
            <div class="card3 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">علی کریمی</h6>
                        <h6 style="color: #fec35e;">شنبه 10 تیر</h6>
                    </div>
                </div>
                <p>من خودم خیلی اهل کمپ نبودم ولی با کمپینگ اصلا اذیت نشدم و کامل با آرامش بودم و حس خیلی خوبی بود.</p>
            </div>
            <div class="card3 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">عسل اسمانی</h6>
                        <h6 style="color: #fec35e;">دوشنبه 20 آبان</h6>
                    </div>
                </div>
                <p>دست شما درد نکنه من تاحالا جایی کمپ نرفته بودم و به کسی اعتماد نداشتم تا و قتی که سایت شمارو دیدن دست شما درد نکنه.</p>
            </div>
            <div class="card3 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">امیرحسین ابویی</h6>
                        <h6 style="color: #fec35e;">چهارشنبه 20 فروردین</h6>
                    </div>
                </div>
                <p>دسستون درد نکنه بابت زدن این سایت من از الان دیگه نمی تونم ماهی دو بار کمپ نرم دست شما درد نکنه مرسی بابت سایتتون.</p>
            </div>
            <div class="card3 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">علی اقایی</h6>
                        <h6 style="color: #fec35e;">سه‌شنبه 29 اسفند</h6>
                    </div>
                </div>
                <p>من خودم خیلی اهل کمپ نبودم ولی با کمپینگ اصلا اذیت نشدم و کامل با آرامش بودم و حس خیلی خوبی بود.</p>
            </div>
            <div class="card3 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">فاطی سادات</h6>
                        <h6 style="color: #fec35e;">سه‌شنبه 5 مهر</h6>
                    </div>
                </div>
                <p>دست شما درد نکنه من تاحالا جایی کمپ نرفته بودم و به کسی اعتماد نداشتم تا و قتی که سایت شمارو دیدن دست شما درد نکنه.</p>
            </div>
            <div class="card3 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">یاسر غروی</h6>
                        <h6 style="color: #fec35e;">یکشنبه 15 اردیبهشت</h6>
                    </div>
                </div>
                <p>دسستون درد نکنه بابت زدن این سایت من از الان دیگه نمی تونم ماهی دو بار کمپ نرم دست شما درد نکنه مرسی بابت سایتتون.</p>
            </div>
            <div class="card3 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">علی طارمی</h6>
                        <h6 style="color: #fec35e;">شنبه 10 تیر</h6>
                    </div>
                </div>
                <p>من خودم خیلی اهل کمپ نبودم ولی با کمپینگ اصلا اذیت نشدم و کامل با آرامش بودم و حس خیلی خوبی بود.</p>
            </div>
            <div class="card3 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">طلا عسل آبادی</h6>
                        <h6 style="color: #fec35e;">دوشنبه 20 آبان</h6>
                    </div>
                </div>
                <p>دست شما درد نکنه من تاحالا جایی کمپ نرفته بودم و به کسی اعتماد نداشتم تا و قتی که سایت شمارو دیدن دست شما درد نکنه.</p>
            </div>
        </div>
    </div>
</div>
<!-- نارنجی شب -->
<div class="container-fluid text-center mt-5 extra-content Paris-Extra2-Night">

    <h2 class="extra-content London-Extra2-Day London-Extra2-Night mb-4" style="color: #347928;">نظرات مردمی</h2>
    <h2 class="extra-content Paris-Extra2-Day Paris-Extra2-Night mb-4" style="color: #ff6b00;">نظرات مردمی</h2>
    <h2 class="extra-content Tokyo-Extra2-Day Tokyo-Extra2-Night mb-4" style="color: #365ee2;">نظرات مردمی</h2>

    <!-- ردیف اول -->
    <div class="scroll-row row-1 mt-5">
        <div class="scroll-content">
            <div class="card4 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">مسعود پزشکیان</h6>
                        <h6 style="color: #fec35e;">چهارشنبه 20 فروردین</h6>
                    </div>
                </div>
                <p>ما هم باید یه تفریحی داشته باشیم دیگه دیگه گفتید بعد یک سال ریاست جمهوری کجا بریم از این سایت یک کمپ خوب انتخواب کردیم.</p>
            </div>
            <div class="card4 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">مهران مدیری</h6>
                        <h6 style="color: #fec35e;">سه‌شنبه 2 فروردین</h6>
                    </div>
                </div>
                <p>ما برای فیلم برداری فیلم قهوه پدری لوکیشن نداشتیم از این سایت یه لوکیشن خوب اجاره کردیم دست شما درد نکنه.</p>
            </div>
            <div class="card4 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">ژاله صامتی</h6>
                        <h6 style="color: #fec35e;">سه‌شنبه 28 اسفند</h6>
                    </div>
                </div>
                <p>ما با اقای مدیری یه مکان ظبط داشتیم برای قهوه پدری از این سایت اجاره کردن من هم برای خودم و خواندادم از این سایت اجاراه کردم.</p>
            </div>
            <div class="card4 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">علی دایی</h6>
                        <h6 style="color: #fec35e;">یکشنبه 25 اسفند</h6>
                    </div>
                </div>
                <p>به عنوان پیشکسوت فوتبال دنبال یه جای خوب برای کمپ بودم جایی پیدانکردم از این سایت یک جای خوب انتخواب کردم خیلی عالی.</p>
            </div>
            <div class="card4 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">پژمان جمشیدی</h6>
                        <h6 style="color: #fec35e;">شنبه 24 اسفند</h6>
                    </div>
                </div>
                <p>ما با خوانواده دنبال یه جایی برای کمپ بودیم که این سایت رو به ما پیشنهاد دادن سایت خیلی خوبیه دست شما درد نکنه.</p>
            </div>
            <div class="card4 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">متین ستوده</h6>
                        <h6 style="color: #fec35e;">دوشنبه 20 اسفند</h6>
                    </div>
                </div>
                <p>دست شما درد نکنه من تاحالا جایی کمپ نرفته بودم و به کسی اعتماد نداشتم تا و قتی که سایت شمارو دیدن دست شما درد نکنه.</p>
            </div>
            <div class="card4 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">سام درخشانی</h6>
                        <h6 style="color: #fec35e;">چهارشنبه 12 اسفند</h6>
                    </div>
                </div>
                <p>کپینگ مکان های خیلی خوبی داره من خودم این سایت رو به آقای مدیری گفتم که برای فیلم برداری قهوه پدری باشه خیلی عالی.</p>
            </div>
            <div class="card4 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">علیرضا جهان بخش</h6>
                        <h6 style="color: #fec35e;">سه‌شنبه 8 اسفند</h6>
                    </div>
                </div>
                <p>دیگه بعد از بازی های زیاد می خواستم استراحت کنم این سایت رو انتخواب کردم مکان های خیلی خوبی داره مرسی.</p>
            </div>
            <div class="card4 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">نرگس محمدی</h6>
                        <h6 style="color: #fec35e;">سه‌شنبه 5 اسفند</h6>
                    </div>
                </div>
                <p>من با همسرم رفته بودم یکی از مکان های این کمپ خیلی رازی بودیم مرسی دست شما درد نکنه بابت زدن این سایت</p>
            </div>
            <div class="card4 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">علی اوجی</h6>
                        <h6 style="color: #fec35e;">یکشنبه 5 اسفند</h6>
                    </div>
                </div>
                <p>دسستون درد نکنه بابت زدن این سایت من از الان دیگه نمی تونم ماهی دو بار کمپ نرم دست شما درد نکنه مرسی بابت سایتتون.</p>
            </div>
            <div class="card4 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">قدرت الله ایزدی</h6>
                        <h6 style="color: #fec35e;">شنبه 29 بهمن</h6>
                    </div>
                </div>
                <p>من خودم خیلی اهل کمپ نبودم ولی با کمپینگ اصلا اذیت نشدم و کامل با آرامش بودم و حس خیلی خوبی بود.</p>
            </div>
            <div class="card4 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">گیتی قاسمی</h6>
                        <h6 style="color: #fec35e;">دوشنبه 25 بهمن</h6>
                    </div>
                </div>
                <p>دست شما درد نکنه من تاحالا جایی کمپ نرفته بودم و به کسی اعتماد نداشتم تا و قتی که سایت شمارو دیدن دست شما درد نکنه.</p>
            </div>
        </div>
    </div>

    <!-- ردیف دوم -->
    <div class="scroll-row row-2">
        <div class="scroll-content">
            <div class="card4 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">محمد صالح طابی</h6>
                        <h6 style="color: #fec35e;">چهارشنبه 20 فروردین</h6>
                    </div>
                </div>
                <p>ما دیدم بچه ها زحمت کشیدن گفتیم خب حداقل ما هم یه کمکی بکنیم برای چند روز یکی مکان های کویر لوت رو انتخواب کردیم.</p>
            </div>
            <div class="card4 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">علی ابراهیمی</h6>
                        <h6 style="color: #fec35e;">سه‌شنبه 29 اسفند</h6>
                    </div>
                </div>
                <p>من خودم خیلی اهل کمپ نبودم ولی با کمپینگ اصلا اذیت نشدم و کامل با آرامش بودم و حس خیلی خوبی بود.</p>
            </div>
            <div class="card4 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">فاطمه یاسینی</h6>
                        <h6 style="color: #fec35e;">سه‌شنبه 5 اسفند</h6>
                    </div>
                </div>
                <p>دست شما درد نکنه من تاحالا جایی کمپ نرفته بودم و به کسی اعتماد نداشتم تا و قتی که سایت شمارو دیدن دست شما درد نکنه.</p>
            </div>
            <div class="card4 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">علی بهمن آبادی</h6>
                        <h6 style="color: #fec35e;">یکشنبه 15 بهمن</h6>
                    </div>
                </div>
                <p>ما دیدیم یه پیامک برای من امد نوشته بود کمپ رایگان برای شما ما هم دیدیم رایگان بود با امین و اردستانی و مخلصی رفتیم.</p>
            </div>
            <div class="card4 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">امین دویران</h6>
                        <h6 style="color: #fec35e;">شنبه 10 بهمن</h6>
                    </div>
                </div>
                <p>ما که دیدم اوینی اول نمیشیم گفتیم حد اقل از سایت برنده آوینی یه استفاده ایم بکنیم ما هم یه مکان داخل کرج گرفتیم.</p>
            </div>
            <div class="card4 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">سارا نیکنامی</h6>
                        <h6 style="color: #fec35e;">دوشنبه 9 بهمن</h6>
                    </div>
                </div>
                <p>من با همسرم زیاد کمپ رفته بودم ولی اصلا رازی نبودم تا وقتی که با این سایت آشناشدم خیلی خوب بود و مکان های خوبی داشت.</p>
            </div>
            <div class="card4 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">امین گودرزی</h6>
                        <h6 style="color: #fec35e;">سه‌شنبه 3 بهمن</h6>
                    </div>
                </div>
                <p>دیگه دیدیم قراره یه نفر رو داخل آوینی اول کنیم دیدم کی از همه بیشتر هدیه میده اون رو اول کنیم که کمپ به نظرم از همه بهتر بود.</p>
            </div>
            <div class="card4 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">متین مومرشفان</h6>
                        <h6 style="color: #fec35e;">چهارشنبه 5 بهمن</h6>
                    </div>
                </div>
                <p>من و امین با هم خیلی حرف زدم که آقا کجا بریم خوبه من نمی دونسم که کجا بریمو از کجا رزرو کنیم امین اینجا رو معرفی کرد .</p>
            </div>
            <div class="card4 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">فاطمه اقایی</h6>
                        <h6 style="color: #fec35e;">سه‌شنبه 1 بهمن</h6>
                    </div>
                </div>
                <p>دست شما درد نکنه من تاحالا جایی کمپ نرفته بودم و به کسی اعتماد نداشتم تا و قتی که سایت شمارو دیدن دست شما درد نکنه.</p>
            </div>
            <div class="card4 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">اردستانی</h6>
                        <h6 style="color: #fec35e;">یکشنبه 29 دی</h6>
                    </div>
                </div>
                <p>دیگه باید نمره های بچه هارو بالا می دادیم گفتیم چی کار کنیم گفتیم حداقل یه کمپ رایگان بریم دیگه چی کار میشه کرد.</p>
            </div>
            <div class="card4 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">محمد مهدی کریمی</h6>
                        <h6 style="color: #fec35e;">شنبه 20 دی</h6>
                    </div>
                </div>
                <p>من خودم خیلی اهل کمپ نبودم ولی با کمپینگ اصلا اذیت نشدم و کامل با آرامش بودم و حس خیلی خوبی بود.</p>
            </div>
            <div class="card4 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">سارا شاهی</h6>
                        <h6 style="color: #fec35e;">دوشنبه 20 دی</h6>
                    </div>
                </div>
                <p>دست شما درد نکنه من تاحالا جایی کمپ نرفته بودم و به کسی اعتماد نداشتم تا و قتی که سایت شمارو دیدن دست شما درد نکنه.</p>
            </div>
        </div>
    </div>

    <!-- ردیف سوم -->
    <div class="scroll-row row-3">
        <div class="scroll-content">
            <div class="card4 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">علیرضا انصاریان</h6>
                        <h6 style="color: #fec35e;">چهارشنبه 20 فروردین</h6>
                    </div>
                </div>
                <p>ما برای تعطیلات یه جا می خواستیم که این سایت رو دیدم مرسی بابت زدن ای سایت دست شما درد نکنه.</p>
            </div>
            <div class="card4 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">حسین میرزایی</h6>
                        <h6 style="color: #fec35e;">سه‌شنبه 29 اسفند</h6>
                    </div>
                </div>
                <p>من خودم خیلی اهل کمپ نبودم ولی با کمپینگ اصلا اذیت نشدم و کامل با آرامش بودم و حس خیلی خوبی بود.</p>
            </div>
            <div class="card4 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">معصومه مرادی</h6>
                        <h6 style="color: #fec35e;">سه‌شنبه 5 مهر</h6>
                    </div>
                </div>
                <p>دست شما درد نکنه من تاحالا جایی کمپ نرفته بودم و به کسی اعتماد نداشتم تا و قتی که سایت شمارو دیدن دست شما درد نکنه.</p>
            </div>
            <div class="card4 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">محسن نیکخاه</h6>
                        <h6 style="color: #fec35e;">یکشنبه 15 اردیبهشت</h6>
                    </div>
                </div>
                <p>دسستون درد نکنه بابت زدن این سایت من از الان دیگه نمی تونم ماهی دو بار کمپ نرم دست شما درد نکنه مرسی بابت سایتتون.</p>
            </div>
            <div class="card4 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">علی کریمی</h6>
                        <h6 style="color: #fec35e;">شنبه 10 تیر</h6>
                    </div>
                </div>
                <p>من خودم خیلی اهل کمپ نبودم ولی با کمپینگ اصلا اذیت نشدم و کامل با آرامش بودم و حس خیلی خوبی بود.</p>
            </div>
            <div class="card4 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">عسل اسمانی</h6>
                        <h6 style="color: #fec35e;">دوشنبه 20 آبان</h6>
                    </div>
                </div>
                <p>دست شما درد نکنه من تاحالا جایی کمپ نرفته بودم و به کسی اعتماد نداشتم تا و قتی که سایت شمارو دیدن دست شما درد نکنه.</p>
            </div>
            <div class="card4 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">امیرحسین ابویی</h6>
                        <h6 style="color: #fec35e;">چهارشنبه 20 فروردین</h6>
                    </div>
                </div>
                <p>دسستون درد نکنه بابت زدن این سایت من از الان دیگه نمی تونم ماهی دو بار کمپ نرم دست شما درد نکنه مرسی بابت سایتتون.</p>
            </div>
            <div class="card4 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">علی اقایی</h6>
                        <h6 style="color: #fec35e;">سه‌شنبه 29 اسفند</h6>
                    </div>
                </div>
                <p>من خودم خیلی اهل کمپ نبودم ولی با کمپینگ اصلا اذیت نشدم و کامل با آرامش بودم و حس خیلی خوبی بود.</p>
            </div>
            <div class="card4 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">فاطی سادات</h6>
                        <h6 style="color: #fec35e;">سه‌شنبه 5 مهر</h6>
                    </div>
                </div>
                <p>دست شما درد نکنه من تاحالا جایی کمپ نرفته بودم و به کسی اعتماد نداشتم تا و قتی که سایت شمارو دیدن دست شما درد نکنه.</p>
            </div>
            <div class="card4 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">یاسر غروی</h6>
                        <h6 style="color: #fec35e;">یکشنبه 15 اردیبهشت</h6>
                    </div>
                </div>
                <p>دسستون درد نکنه بابت زدن این سایت من از الان دیگه نمی تونم ماهی دو بار کمپ نرم دست شما درد نکنه مرسی بابت سایتتون.</p>
            </div>
            <div class="card4 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">علی طارمی</h6>
                        <h6 style="color: #fec35e;">شنبه 10 تیر</h6>
                    </div>
                </div>
                <p>من خودم خیلی اهل کمپ نبودم ولی با کمپینگ اصلا اذیت نشدم و کامل با آرامش بودم و حس خیلی خوبی بود.</p>
            </div>
            <div class="card4 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #ff6a00;">طلا عسل آبادی</h6>
                        <h6 style="color: #fec35e;">دوشنبه 20 آبان</h6>
                    </div>
                </div>
                <p>دست شما درد نکنه من تاحالا جایی کمپ نرفته بودم و به کسی اعتماد نداشتم تا و قتی که سایت شمارو دیدن دست شما درد نکنه.</p>
            </div>
        </div>
    </div>
</div>
<!-- آبی روز -->
<div class="container-fluid text-center mt-5 extra-content Tokyo-Extra2-Day">

    <h2 class="extra-content London-Extra2-Day London-Extra2-Night mb-4" style="color: #347928;">نظرات مردمی</h2>
    <h2 class="extra-content Paris-Extra2-Day Paris-Extra2-Night mb-4" style="color: #ff6b00;">نظرات مردمی</h2>
    <h2 class="extra-content Tokyo-Extra2-Day Tokyo-Extra2-Night mb-4" style="color: #365ee2;">نظرات مردمی</h2>

    <!-- ردیف اول -->
    <div class="scroll-row row-1 mt-5">
        <div class="scroll-content">
            <div class="card5 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">مسعود پزشکیان</h6>
                        <h6 style="color: #f7ac39;">چهارشنبه 20 فروردین</h6>
                    </div>
                </div>
                <p>ما هم باید یه تفریحی داشته باشیم دیگه دیگه گفتید بعد یک سال ریاست جمهوری کجا بریم از این سایت یک کمپ خوب انتخواب کردیم.</p>
            </div>
            <div class="card5 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">مهران مدیری</h6>
                        <h6 style="color: #f7ac39;">سه‌شنبه 2 فروردین</h6>
                    </div>
                </div>
                <p>ما برای فیلم برداری فیلم قهوه پدری لوکیشن نداشتیم از این سایت یه لوکیشن خوب اجاره کردیم دست شما درد نکنه.</p>
            </div>
            <div class="card5 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">ژاله صامتی</h6>
                        <h6 style="color: #f7ac39;">سه‌شنبه 28 اسفند</h6>
                    </div>
                </div>
                <p>ما با اقای مدیری یه مکان ظبط داشتیم برای قهوه پدری از این سایت اجاره کردن من هم برای خودم و خواندادم از این سایت اجاراه کردم.</p>
            </div>
            <div class="card5 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">علی دایی</h6>
                        <h6 style="color: #f7ac39;">یکشنبه 25 اسفند</h6>
                    </div>
                </div>
                <p>به عنوان پیشکسوت فوتبال دنبال یه جای خوب برای کمپ بودم جایی پیدانکردم از این سایت یک جای خوب انتخواب کردم خیلی عالی.</p>
            </div>
            <div class="card5 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">پژمان جمشیدی</h6>
                        <h6 style="color: #f7ac39;">شنبه 24 اسفند</h6>
                    </div>
                </div>
                <p>ما با خوانواده دنبال یه جایی برای کمپ بودیم که این سایت رو به ما پیشنهاد دادن سایت خیلی خوبیه دست شما درد نکنه.</p>
            </div>
            <div class="card5 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">متین ستوده</h6>
                        <h6 style="color: #f7ac39;">دوشنبه 20 اسفند</h6>
                    </div>
                </div>
                <p>دست شما درد نکنه من تاحالا جایی کمپ نرفته بودم و به کسی اعتماد نداشتم تا و قتی که سایت شمارو دیدن دست شما درد نکنه.</p>
            </div>
            <div class="card5 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">سام درخشانی</h6>
                        <h6 style="color: #f7ac39;">چهارشنبه 12 اسفند</h6>
                    </div>
                </div>
                <p>کپینگ مکان های خیلی خوبی داره من خودم این سایت رو به آقای مدیری گفتم که برای فیلم برداری قهوه پدری باشه خیلی عالی.</p>
            </div>
            <div class="card5 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">علیرضا جهان بخش</h6>
                        <h6 style="color: #f7ac39;">سه‌شنبه 8 اسفند</h6>
                    </div>
                </div>
                <p>دیگه بعد از بازی های زیاد می خواستم استراحت کنم این سایت رو انتخواب کردم مکان های خیلی خوبی داره مرسی.</p>
            </div>
            <div class="card5 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">نرگس محمدی</h6>
                        <h6 style="color: #f7ac39;">سه‌شنبه 5 اسفند</h6>
                    </div>
                </div>
                <p>من با همسرم رفته بودم یکی از مکان های این کمپ خیلی رازی بودیم مرسی دست شما درد نکنه بابت زدن این سایت</p>
            </div>
            <div class="card5 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">علی اوجی</h6>
                        <h6 style="color: #f7ac39;">یکشنبه 5 اسفند</h6>
                    </div>
                </div>
                <p>دسستون درد نکنه بابت زدن این سایت من از الان دیگه نمی تونم ماهی دو بار کمپ نرم دست شما درد نکنه مرسی بابت سایتتون.</p>
            </div>
            <div class="card5 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">قدرت الله ایزدی</h6>
                        <h6 style="color: #f7ac39;">شنبه 29 بهمن</h6>
                    </div>
                </div>
                <p>من خودم خیلی اهل کمپ نبودم ولی با کمپینگ اصلا اذیت نشدم و کامل با آرامش بودم و حس خیلی خوبی بود.</p>
            </div>
            <div class="card5 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">گیتی قاسمی</h6>
                        <h6 style="color: #f7ac39;">دوشنبه 25 بهمن</h6>
                    </div>
                </div>
                <p>دست شما درد نکنه من تاحالا جایی کمپ نرفته بودم و به کسی اعتماد نداشتم تا و قتی که سایت شمارو دیدن دست شما درد نکنه.</p>
            </div>
        </div>
    </div>

    <!-- ردیف دوم -->
    <div class="scroll-row row-2">
        <div class="scroll-content">
            <div class="card5 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">محمد صالح طابی</h6>
                        <h6 style="color: #f7ac39;">چهارشنبه 20 فروردین</h6>
                    </div>
                </div>
                <p>ما دیدم بچه ها زحمت کشیدن گفتیم خب حداقل ما هم یه کمکی بکنیم برای چند روز یکی مکان های کویر لوت رو انتخواب کردیم.</p>
            </div>
            <div class="card5 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">علی ابراهیمی</h6>
                        <h6 style="color: #f7ac39;">سه‌شنبه 29 اسفند</h6>
                    </div>
                </div>
                <p>من خودم خیلی اهل کمپ نبودم ولی با کمپینگ اصلا اذیت نشدم و کامل با آرامش بودم و حس خیلی خوبی بود.</p>
            </div>
            <div class="card5 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">فاطمه یاسینی</h6>
                        <h6 style="color: #f7ac39;">سه‌شنبه 5 اسفند</h6>
                    </div>
                </div>
                <p>دست شما درد نکنه من تاحالا جایی کمپ نرفته بودم و به کسی اعتماد نداشتم تا و قتی که سایت شمارو دیدن دست شما درد نکنه.</p>
            </div>
            <div class="card5 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">علی بهمن آبادی</h6>
                        <h6 style="color: #f7ac39;">یکشنبه 15 بهمن</h6>
                    </div>
                </div>
                <p>ما دیدیم یه پیامک برای من امد نوشته بود کمپ رایگان برای شما ما هم دیدیم رایگان بود با امین و اردستانی و مخلصی رفتیم.</p>
            </div>
            <div class="card5 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">امین دویران</h6>
                        <h6 style="color: #f7ac39;">شنبه 10 بهمن</h6>
                    </div>
                </div>
                <p>ما که دیدم اوینی اول نمیشیم گفتیم حد اقل از سایت برنده آوینی یه استفاده ایم بکنیم ما هم یه مکان داخل کرج گرفتیم.</p>
            </div>
            <div class="card5 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">سارا نیکنامی</h6>
                        <h6 style="color: #f7ac39;">دوشنبه 9 بهمن</h6>
                    </div>
                </div>
                <p>من با همسرم زیاد کمپ رفته بودم ولی اصلا رازی نبودم تا وقتی که با این سایت آشناشدم خیلی خوب بود و مکان های خوبی داشت.</p>
            </div>
            <div class="card5 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">امین گودرزی</h6>
                        <h6 style="color: #f7ac39;">سه‌شنبه 3 بهمن</h6>
                    </div>
                </div>
                <p>دیگه دیدیم قراره یه نفر رو داخل آوینی اول کنیم دیدم کی از همه بیشتر هدیه میده اون رو اول کنیم که کمپ به نظرم از همه بهتر بود.</p>
            </div>
            <div class="card5 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">متین مومرشفان</h6>
                        <h6 style="color: #f7ac39;">چهارشنبه 5 بهمن</h6>
                    </div>
                </div>
                <p>من و امین با هم خیلی حرف زدم که آقا کجا بریم خوبه من نمی دونسم که کجا بریمو از کجا رزرو کنیم امین اینجا رو معرفی کرد .</p>
            </div>
            <div class="card5 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">فاطمه اقایی</h6>
                        <h6 style="color: #f7ac39;">سه‌شنبه 1 بهمن</h6>
                    </div>
                </div>
                <p>دست شما درد نکنه من تاحالا جایی کمپ نرفته بودم و به کسی اعتماد نداشتم تا و قتی که سایت شمارو دیدن دست شما درد نکنه.</p>
            </div>
            <div class="card5 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">اردستانی</h6>
                        <h6 style="color: #f7ac39;">یکشنبه 29 دی</h6>
                    </div>
                </div>
                <p>دیگه باید نمره های بچه هارو بالا می دادیم گفتیم چی کار کنیم گفتیم حداقل یه کمپ رایگان بریم دیگه چی کار میشه کرد.</p>
            </div>
            <div class="card5 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">محمد مهدی کریمی</h6>
                        <h6 style="color: #f7ac39;">شنبه 20 دی</h6>
                    </div>
                </div>
                <p>من خودم خیلی اهل کمپ نبودم ولی با کمپینگ اصلا اذیت نشدم و کامل با آرامش بودم و حس خیلی خوبی بود.</p>
            </div>
            <div class="card5 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">سارا شاهی</h6>
                        <h6 style="color: #f7ac39;">دوشنبه 20 دی</h6>
                    </div>
                </div>
                <p>دست شما درد نکنه من تاحالا جایی کمپ نرفته بودم و به کسی اعتماد نداشتم تا و قتی که سایت شمارو دیدن دست شما درد نکنه.</p>
            </div>
        </div>
    </div>

    <!-- ردیف سوم -->
    <div class="scroll-row row-3">
        <div class="scroll-content">
            <div class="card5 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">علیرضا انصاریان</h6>
                        <h6 style="color: #f7ac39;">چهارشنبه 20 فروردین</h6>
                    </div>
                </div>
                <p>ما برای تعطیلات یه جا می خواستیم که این سایت رو دیدم مرسی بابت زدن ای سایت دست شما درد نکنه.</p>
            </div>
            <div class="card5 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">حسین میرزایی</h6>
                        <h6 style="color: #f7ac39;">سه‌شنبه 29 اسفند</h6>
                    </div>
                </div>
                <p>من خودم خیلی اهل کمپ نبودم ولی با کمپینگ اصلا اذیت نشدم و کامل با آرامش بودم و حس خیلی خوبی بود.</p>
            </div>
            <div class="card5 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">معصومه مرادی</h6>
                        <h6 style="color: #f7ac39;">سه‌شنبه 5 مهر</h6>
                    </div>
                </div>
                <p>دست شما درد نکنه من تاحالا جایی کمپ نرفته بودم و به کسی اعتماد نداشتم تا و قتی که سایت شمارو دیدن دست شما درد نکنه.</p>
            </div>
            <div class="card5 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">محسن نیکخاه</h6>
                        <h6 style="color: #f7ac39;">یکشنبه 15 اردیبهشت</h6>
                    </div>
                </div>
                <p>دسستون درد نکنه بابت زدن این سایت من از الان دیگه نمی تونم ماهی دو بار کمپ نرم دست شما درد نکنه مرسی بابت سایتتون.</p>
            </div>
            <div class="card5 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">علی کریمی</h6>
                        <h6 style="color: #f7ac39;">شنبه 10 تیر</h6>
                    </div>
                </div>
                <p>من خودم خیلی اهل کمپ نبودم ولی با کمپینگ اصلا اذیت نشدم و کامل با آرامش بودم و حس خیلی خوبی بود.</p>
            </div>
            <div class="card5 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">عسل اسمانی</h6>
                        <h6 style="color: #f7ac39;">دوشنبه 20 آبان</h6>
                    </div>
                </div>
                <p>دست شما درد نکنه من تاحالا جایی کمپ نرفته بودم و به کسی اعتماد نداشتم تا و قتی که سایت شمارو دیدن دست شما درد نکنه.</p>
            </div>
            <div class="card5 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">امیرحسین ابویی</h6>
                        <h6 style="color: #f7ac39;">چهارشنبه 20 فروردین</h6>
                    </div>
                </div>
                <p>دسستون درد نکنه بابت زدن این سایت من از الان دیگه نمی تونم ماهی دو بار کمپ نرم دست شما درد نکنه مرسی بابت سایتتون.</p>
            </div>
            <div class="card5 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">علی اقایی</h6>
                        <h6 style="color: #f7ac39;">سه‌شنبه 29 اسفند</h6>
                    </div>
                </div>
                <p>من خودم خیلی اهل کمپ نبودم ولی با کمپینگ اصلا اذیت نشدم و کامل با آرامش بودم و حس خیلی خوبی بود.</p>
            </div>
            <div class="card5 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">فاطی سادات</h6>
                        <h6 style="color: #f7ac39;">سه‌شنبه 5 مهر</h6>
                    </div>
                </div>
                <p>دست شما درد نکنه من تاحالا جایی کمپ نرفته بودم و به کسی اعتماد نداشتم تا و قتی که سایت شمارو دیدن دست شما درد نکنه.</p>
            </div>
            <div class="card5 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">یاسر غروی</h6>
                        <h6 style="color: #f7ac39;">یکشنبه 15 اردیبهشت</h6>
                    </div>
                </div>
                <p>دسستون درد نکنه بابت زدن این سایت من از الان دیگه نمی تونم ماهی دو بار کمپ نرم دست شما درد نکنه مرسی بابت سایتتون.</p>
            </div>
            <div class="card5 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">علی طارمی</h6>
                        <h6 style="color: #f7ac39;">شنبه 10 تیر</h6>
                    </div>
                </div>
                <p>من خودم خیلی اهل کمپ نبودم ولی با کمپینگ اصلا اذیت نشدم و کامل با آرامش بودم و حس خیلی خوبی بود.</p>
            </div>
            <div class="card5 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">طلا عسل آبادی</h6>
                        <h6 style="color: #f7ac39;">دوشنبه 20 آبان</h6>
                    </div>
                </div>
                <p>دست شما درد نکنه من تاحالا جایی کمپ نرفته بودم و به کسی اعتماد نداشتم تا و قتی که سایت شمارو دیدن دست شما درد نکنه.</p>
            </div>
        </div>
    </div>
</div>
<!-- آبی شب -->
<div class="container-fluid text-center mt-5 extra-content Tokyo-Extra2-Night">

    <h2 class="extra-content London-Extra2-Day London-Extra2-Night mb-4" style="color: #347928;">نظرات مردمی</h2>
    <h2 class="extra-content Paris-Extra2-Day Paris-Extra2-Night mb-4" style="color: #ff6b00;">نظرات مردمی</h2>
    <h2 class="extra-content Tokyo-Extra2-Day Tokyo-Extra2-Night mb-4" style="color: #365ee2;">نظرات مردمی</h2>

    <!-- ردیف اول -->
    <div class="scroll-row row-1 mt-5">
        <div class="scroll-content">
            <div class="card6 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">مسعود پزشکیان</h6>
                        <h6 style="color: #f7ac39;">چهارشنبه 20 فروردین</h6>
                    </div>
                </div>
                <p>ما هم باید یه تفریحی داشته باشیم دیگه دیگه گفتید بعد یک سال ریاست جمهوری کجا بریم از این سایت یک کمپ خوب انتخواب کردیم.</p>
            </div>
            <div class="card6 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">مهران مدیری</h6>
                        <h6 style="color: #f7ac39;">سه‌شنبه 2 فروردین</h6>
                    </div>
                </div>
                <p>ما برای فیلم برداری فیلم قهوه پدری لوکیشن نداشتیم از این سایت یه لوکیشن خوب اجاره کردیم دست شما درد نکنه.</p>
            </div>
            <div class="card6 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">ژاله صامتی</h6>
                        <h6 style="color: #f7ac39;">سه‌شنبه 28 اسفند</h6>
                    </div>
                </div>
                <p>ما با اقای مدیری یه مکان ظبط داشتیم برای قهوه پدری از این سایت اجاره کردن من هم برای خودم و خواندادم از این سایت اجاراه کردم.</p>
            </div>
            <div class="card6 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">علی دایی</h6>
                        <h6 style="color: #f7ac39;">یکشنبه 25 اسفند</h6>
                    </div>
                </div>
                <p>به عنوان پیشکسوت فوتبال دنبال یه جای خوب برای کمپ بودم جایی پیدانکردم از این سایت یک جای خوب انتخواب کردم خیلی عالی.</p>
            </div>
            <div class="card6 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">پژمان جمشیدی</h6>
                        <h6 style="color: #f7ac39;">شنبه 24 اسفند</h6>
                    </div>
                </div>
                <p>ما با خوانواده دنبال یه جایی برای کمپ بودیم که این سایت رو به ما پیشنهاد دادن سایت خیلی خوبیه دست شما درد نکنه.</p>
            </div>
            <div class="card6 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">متین ستوده</h6>
                        <h6 style="color: #f7ac39;">دوشنبه 20 اسفند</h6>
                    </div>
                </div>
                <p>دست شما درد نکنه من تاحالا جایی کمپ نرفته بودم و به کسی اعتماد نداشتم تا و قتی که سایت شمارو دیدن دست شما درد نکنه.</p>
            </div>
            <div class="card6 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">سام درخشانی</h6>
                        <h6 style="color: #f7ac39;">چهارشنبه 12 اسفند</h6>
                    </div>
                </div>
                <p>کپینگ مکان های خیلی خوبی داره من خودم این سایت رو به آقای مدیری گفتم که برای فیلم برداری قهوه پدری باشه خیلی عالی.</p>
            </div>
            <div class="card6 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">علیرضا جهان بخش</h6>
                        <h6 style="color: #f7ac39;">سه‌شنبه 8 اسفند</h6>
                    </div>
                </div>
                <p>دیگه بعد از بازی های زیاد می خواستم استراحت کنم این سایت رو انتخواب کردم مکان های خیلی خوبی داره مرسی.</p>
            </div>
            <div class="card6 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">نرگس محمدی</h6>
                        <h6 style="color: #f7ac39;">سه‌شنبه 5 اسفند</h6>
                    </div>
                </div>
                <p>من با همسرم رفته بودم یکی از مکان های این کمپ خیلی رازی بودیم مرسی دست شما درد نکنه بابت زدن این سایت</p>
            </div>
            <div class="card6 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">علی اوجی</h6>
                        <h6 style="color: #f7ac39;">یکشنبه 5 اسفند</h6>
                    </div>
                </div>
                <p>دسستون درد نکنه بابت زدن این سایت من از الان دیگه نمی تونم ماهی دو بار کمپ نرم دست شما درد نکنه مرسی بابت سایتتون.</p>
            </div>
            <div class="card6 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">قدرت الله ایزدی</h6>
                        <h6 style="color: #f7ac39;">شنبه 29 بهمن</h6>
                    </div>
                </div>
                <p>من خودم خیلی اهل کمپ نبودم ولی با کمپینگ اصلا اذیت نشدم و کامل با آرامش بودم و حس خیلی خوبی بود.</p>
            </div>
            <div class="card6 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">گیتی قاسمی</h6>
                        <h6 style="color: #f7ac39;">دوشنبه 25 بهمن</h6>
                    </div>
                </div>
                <p>دست شما درد نکنه من تاحالا جایی کمپ نرفته بودم و به کسی اعتماد نداشتم تا و قتی که سایت شمارو دیدن دست شما درد نکنه.</p>
            </div>
        </div>
    </div>

    <!-- ردیف دوم -->
    <div class="scroll-row row-2">
        <div class="scroll-content">
            <div class="card6 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">محمد صالح طابی</h6>
                        <h6 style="color: #f7ac39;">چهارشنبه 20 فروردین</h6>
                    </div>
                </div>
                <p>ما دیدم بچه ها زحمت کشیدن گفتیم خب حداقل ما هم یه کمکی بکنیم برای چند روز یکی مکان های کویر لوت رو انتخواب کردیم.</p>
            </div>
            <div class="card6 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">علی ابراهیمی</h6>
                        <h6 style="color: #f7ac39;">سه‌شنبه 29 اسفند</h6>
                    </div>
                </div>
                <p>من خودم خیلی اهل کمپ نبودم ولی با کمپینگ اصلا اذیت نشدم و کامل با آرامش بودم و حس خیلی خوبی بود.</p>
            </div>
            <div class="card6 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">فاطمه یاسینی</h6>
                        <h6 style="color: #f7ac39;">سه‌شنبه 5 اسفند</h6>
                    </div>
                </div>
                <p>دست شما درد نکنه من تاحالا جایی کمپ نرفته بودم و به کسی اعتماد نداشتم تا و قتی که سایت شمارو دیدن دست شما درد نکنه.</p>
            </div>
            <div class="card6 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">علی بهمن آبادی</h6>
                        <h6 style="color: #f7ac39;">یکشنبه 15 بهمن</h6>
                    </div>
                </div>
                <p>ما دیدیم یه پیامک برای من امد نوشته بود کمپ رایگان برای شما ما هم دیدیم رایگان بود با امین و اردستانی و مخلصی رفتیم.</p>
            </div>
            <div class="card6 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">امین دویران</h6>
                        <h6 style="color: #f7ac39;">شنبه 10 بهمن</h6>
                    </div>
                </div>
                <p>ما که دیدم اوینی اول نمیشیم گفتیم حد اقل از سایت برنده آوینی یه استفاده ایم بکنیم ما هم یه مکان داخل کرج گرفتیم.</p>
            </div>
            <div class="card6 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">سارا نیکنامی</h6>
                        <h6 style="color: #f7ac39;">دوشنبه 9 بهمن</h6>
                    </div>
                </div>
                <p>من با همسرم زیاد کمپ رفته بودم ولی اصلا رازی نبودم تا وقتی که با این سایت آشناشدم خیلی خوب بود و مکان های خوبی داشت.</p>
            </div>
            <div class="card6 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">امین گودرزی</h6>
                        <h6 style="color: #f7ac39;">سه‌شنبه 3 بهمن</h6>
                    </div>
                </div>
                <p>دیگه دیدیم قراره یه نفر رو داخل آوینی اول کنیم دیدم کی از همه بیشتر هدیه میده اون رو اول کنیم که کمپ به نظرم از همه بهتر بود.</p>
            </div>
            <div class="card6 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">متین مومرشفان</h6>
                        <h6 style="color: #f7ac39;">چهارشنبه 5 بهمن</h6>
                    </div>
                </div>
                <p>من و امین با هم خیلی حرف زدم که آقا کجا بریم خوبه من نمی دونسم که کجا بریمو از کجا رزرو کنیم امین اینجا رو معرفی کرد .</p>
            </div>
            <div class="card6 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">فاطمه اقایی</h6>
                        <h6 style="color: #f7ac39;">سه‌شنبه 1 بهمن</h6>
                    </div>
                </div>
                <p>دست شما درد نکنه من تاحالا جایی کمپ نرفته بودم و به کسی اعتماد نداشتم تا و قتی که سایت شمارو دیدن دست شما درد نکنه.</p>
            </div>
            <div class="card6 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">اردستانی</h6>
                        <h6 style="color: #f7ac39;">یکشنبه 29 دی</h6>
                    </div>
                </div>
                <p>دیگه باید نمره های بچه هارو بالا می دادیم گفتیم چی کار کنیم گفتیم حداقل یه کمپ رایگان بریم دیگه چی کار میشه کرد.</p>
            </div>
            <div class="card6 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">محمد مهدی کریمی</h6>
                        <h6 style="color: #f7ac39;">شنبه 20 دی</h6>
                    </div>
                </div>
                <p>من خودم خیلی اهل کمپ نبودم ولی با کمپینگ اصلا اذیت نشدم و کامل با آرامش بودم و حس خیلی خوبی بود.</p>
            </div>
            <div class="card6 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">سارا شاهی</h6>
                        <h6 style="color: #f7ac39;">دوشنبه 20 دی</h6>
                    </div>
                </div>
                <p>دست شما درد نکنه من تاحالا جایی کمپ نرفته بودم و به کسی اعتماد نداشتم تا و قتی که سایت شمارو دیدن دست شما درد نکنه.</p>
            </div>
        </div>
    </div>

    <!-- ردیف سوم -->
    <div class="scroll-row row-3">
        <div class="scroll-content">
            <div class="card6 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">علیرضا انصاریان</h6>
                        <h6 style="color: #f7ac39;">چهارشنبه 20 فروردین</h6>
                    </div>
                </div>
                <p>ما برای تعطیلات یه جا می خواستیم که این سایت رو دیدم مرسی بابت زدن ای سایت دست شما درد نکنه.</p>
            </div>
            <div class="card6 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">حسین میرزایی</h6>
                        <h6 style="color: #f7ac39;">سه‌شنبه 29 اسفند</h6>
                    </div>
                </div>
                <p>من خودم خیلی اهل کمپ نبودم ولی با کمپینگ اصلا اذیت نشدم و کامل با آرامش بودم و حس خیلی خوبی بود.</p>
            </div>
            <div class="card6 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">معصومه مرادی</h6>
                        <h6 style="color: #f7ac39;">سه‌شنبه 5 مهر</h6>
                    </div>
                </div>
                <p>دست شما درد نکنه من تاحالا جایی کمپ نرفته بودم و به کسی اعتماد نداشتم تا و قتی که سایت شمارو دیدن دست شما درد نکنه.</p>
            </div>
            <div class="card6 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">محسن نیکخاه</h6>
                        <h6 style="color: #f7ac39;">یکشنبه 15 اردیبهشت</h6>
                    </div>
                </div>
                <p>دسستون درد نکنه بابت زدن این سایت من از الان دیگه نمی تونم ماهی دو بار کمپ نرم دست شما درد نکنه مرسی بابت سایتتون.</p>
            </div>
            <div class="card6 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">علی کریمی</h6>
                        <h6 style="color: #f7ac39;">شنبه 10 تیر</h6>
                    </div>
                </div>
                <p>من خودم خیلی اهل کمپ نبودم ولی با کمپینگ اصلا اذیت نشدم و کامل با آرامش بودم و حس خیلی خوبی بود.</p>
            </div>
            <div class="card6 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">عسل اسمانی</h6>
                        <h6 style="color: #f7ac39;">دوشنبه 20 آبان</h6>
                    </div>
                </div>
                <p>دست شما درد نکنه من تاحالا جایی کمپ نرفته بودم و به کسی اعتماد نداشتم تا و قتی که سایت شمارو دیدن دست شما درد نکنه.</p>
            </div>
            <div class="card6 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">امیرحسین ابویی</h6>
                        <h6 style="color: #f7ac39;">چهارشنبه 20 فروردین</h6>
                    </div>
                </div>
                <p>دسستون درد نکنه بابت زدن این سایت من از الان دیگه نمی تونم ماهی دو بار کمپ نرم دست شما درد نکنه مرسی بابت سایتتون.</p>
            </div>
            <div class="card6 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">علی اقایی</h6>
                        <h6 style="color: #f7ac39;">سه‌شنبه 29 اسفند</h6>
                    </div>
                </div>
                <p>من خودم خیلی اهل کمپ نبودم ولی با کمپینگ اصلا اذیت نشدم و کامل با آرامش بودم و حس خیلی خوبی بود.</p>
            </div>
            <div class="card6 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">فاطی سادات</h6>
                        <h6 style="color: #f7ac39;">سه‌شنبه 5 مهر</h6>
                    </div>
                </div>
                <p>دست شما درد نکنه من تاحالا جایی کمپ نرفته بودم و به کسی اعتماد نداشتم تا و قتی که سایت شمارو دیدن دست شما درد نکنه.</p>
            </div>
            <div class="card6 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cc.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">یاسر غروی</h6>
                        <h6 style="color: #f7ac39;">یکشنبه 15 اردیبهشت</h6>
                    </div>
                </div>
                <p>دسستون درد نکنه بابت زدن این سایت من از الان دیگه نمی تونم ماهی دو بار کمپ نرم دست شما درد نکنه مرسی بابت سایتتون.</p>
            </div>
            <div class="card6 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cd.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">علی طارمی</h6>
                        <h6 style="color: #f7ac39;">شنبه 10 تیر</h6>
                    </div>
                </div>
                <p>من خودم خیلی اهل کمپ نبودم ولی با کمپینگ اصلا اذیت نشدم و کامل با آرامش بودم و حس خیلی خوبی بود.</p>
            </div>
            <div class="card6 p-3">
                <div class="d-flex align-items-center">
                    <img src="img/cb.jpg" width="60" alt="">
                    <div class="ml-3 text-right">
                        <h6 style="color: #365ee2;">طلا عسل آبادی</h6>
                        <h6 style="color: #f7ac39;">دوشنبه 20 آبان</h6>
                    </div>
                </div>
                <p>دست شما درد نکنه من تاحالا جایی کمپ نرفته بودم و به کسی اعتماد نداشتم تا و قتی که سایت شمارو دیدن دست شما درد نکنه.</p>
            </div>
        </div>
    </div>
</div>


<!-- پخش کننده صدا -->
<div class="container mt-5">
    <!-- تیتر اصلی -->
    <div class="header-text">
        <h2 class="extra-content London-Extra2-Day London-Extra2-Night" style="color: #347928;">شنیدن صدای طبیعت</h2>
        <h2 class="extra-content Paris-Extra2-Day Paris-Extra2-Night" style="color: #ff6b00;">شنیدن صدای طبیعت</h2>
        <h2 class="extra-content Tokyo-Extra2-Day Tokyo-Extra2-Night" style="color: #365ee2;">شنیدن صدای طبیعت</h2>
    </div>

    <!-- دکمه‌های صدا -->
    <div class="row mt-4">
        <!-- باران چند رنگ -->
        <div class="col-md-6 mb-3 extra-content London-Extra2-Day London-Extra2-Night">
            <button class="sound-button w-100 d-flex justify-content-between align-items-center" style="background-color: #28a745;" 
                    onclick="toggleSound(this, 'rain')" 
                    data-play-icon="img/play.png" 
                    data-pause-icon="img/pause.png">
                <span>صدای باران</span>
                <div class="play-icon">
                    <img src="img/play.png" alt="Play">
                </div>
            </button>
        </div>
        <div class="col-md-6 mb-3 extra-content Paris-Extra2-Day Paris-Extra2-Night">
            <button class="sound-button w-100 d-flex justify-content-between align-items-center" style="background-color: #28a745;" 
                    onclick="toggleSound(this, 'rain')" 
                    data-play-icon="img/playr.png" 
                    data-pause-icon="img/pauser.png">
                <span>صدای باران</span>
                <div class="play-icon">
                    <img src="img/playr.png" alt="Play">
                </div>
            </button>
        </div>
        <div class="col-md-6 mb-3 extra-content Tokyo-Extra2-Day Tokyo-Extra2-Night">
            <button class="sound-button w-100 d-flex justify-content-between align-items-center" style="background-color: #28a745;" 
                    onclick="toggleSound(this, 'rain')" 
                    data-play-icon="img/playb.png" 
                    data-pause-icon="img/pauseb.png">
                <span>صدای باران</span>
                <div class="play-icon">
                    <img src="img/playb.png" alt="Play">
                </div>
            </button>
        </div>
        <!-- دریای چند رنگ -->
        <div class="col-md-6 mb-3 extra-content London-Extra2-Day London-Extra2-Night">
            <button class="sound-button w-100 d-flex justify-content-between align-items-center" style="background-color: #28a745;" 
                    onclick="toggleSound(this, 'sea')" 
                    data-play-icon="img/play.png" 
                    data-pause-icon="img/pause.png">
                <span>صدای دریا</span>
                <div class="play-icon">
                    <img src="img/play.png" alt="Play">
                </div>
            </button>
        </div>
        <div class="col-md-6 mb-3 extra-content Paris-Extra2-Day Paris-Extra2-Night">
            <button class="sound-button w-100 d-flex justify-content-between align-items-center" style="background-color: #28a745;" 
                    onclick="toggleSound(this, 'sea')" 
                    data-play-icon="img/playr.png" 
                    data-pause-icon="img/pauser.png">
                <span>صدای دریا</span>
                <div class="play-icon">
                    <img src="img/playr.png" alt="Play">
                </div>
            </button>
        </div>
        <div class="col-md-6 mb-3 extra-content Tokyo-Extra2-Day Tokyo-Extra2-Night">
            <button class="sound-button w-100 d-flex justify-content-between align-items-center" style="background-color: #28a745;" 
                    onclick="toggleSound(this, 'sea')" 
                    data-play-icon="img/playb.png" 
                    data-pause-icon="img/pauseb.png">
                <span>صدای دریا</span>
                <div class="play-icon">
                    <img src="img/playb.png" alt="Play">
                </div>
            </button>
        </div>
        <!-- صدای جنگل چند رنگ -->
        <div class="col-md-6 mb-3 extra-content London-Extra2-Day London-Extra2-Night">
            <button class="sound-button w-100 d-flex justify-content-between align-items-center" style="background-color: #28a745;" 
                    onclick="toggleSound(this, 'forest')" 
                    data-play-icon="img/play.png" 
                    data-pause-icon="img/pause.png">
                <span>صدای جنگل</span>
                <div class="play-icon">
                    <img src="img/play.png" alt="Play">
                </div>
            </button>
        </div>
        <div class="col-md-6 mb-3 extra-content Paris-Extra2-Day Paris-Extra2-Night">
            <button class="sound-button w-100 d-flex justify-content-between align-items-center" style="background-color: #28a745;" 
                    onclick="toggleSound(this, 'forest')" 
                    data-play-icon="img/playr.png" 
                    data-pause-icon="img/pauser.png">
                <span>صدای جنگل</span>
                <div class="play-icon">
                    <img src="img/playr.png" alt="Play">
                </div>
            </button>
        </div>
        <div class="col-md-6 mb-3 extra-content Tokyo-Extra2-Day Tokyo-Extra2-Night">
            <button class="sound-button w-100 d-flex justify-content-between align-items-center" style="background-color: #28a745;" 
                    onclick="toggleSound(this, 'forest')" 
                    data-play-icon="img/playb.png" 
                    data-pause-icon="img/pauseb.png">
                <span>صدای جنگل</span>
                <div class="play-icon">
                    <img src="img/playb.png" alt="Play">
                </div>
            </button>
        </div>
        <!-- اتیش چند رنگ -->
        <div class="col-md-6 mb-3 extra-content London-Extra2-Day London-Extra2-Night">
            <button class="sound-button w-100 d-flex justify-content-between align-items-center" style="background-color: #28a745;"
                    onclick="toggleSound(this, 'fire')" 
                    data-play-icon="img/play.png" 
                    data-pause-icon="img/pause.png">
                <span>صدای آتش</span>
                <div class="play-icon">
                    <img src="img/play.png" alt="Play">
                </div>
            </button>
        </div>
        <div class="col-md-6 mb-3 extra-content Paris-Extra2-Day Paris-Extra2-Night">
            <button class="sound-button w-100 d-flex justify-content-between align-items-center" style="background-color: #28a745;"
                    onclick="toggleSound(this, 'fire')" 
                    data-play-icon="img/playr.png" 
                    data-pause-icon="img/pauser.png">
                <span>صدای آتش</span>
                <div class="play-icon">
                    <img src="img/playr.png" alt="Play">
                </div>
            </button>
        </div>
        <div class="col-md-6 mb-3 extra-content Tokyo-Extra2-Day Tokyo-Extra2-Night">
            <button class="sound-button w-100 d-flex justify-content-between align-items-center" style="background-color: #28a745;"
                    onclick="toggleSound(this, 'fire')" 
                    data-play-icon="img/playb.png" 
                    data-pause-icon="img/pauseb.png">
                <span>صدای آتش</span>
                <div class="play-icon">
                    <img src="img/playb.png" alt="Play">
                </div>
            </button>
        </div>
        <!--  -->
    </div>
</div>

<!-- فوتر -->
<!-- رنگ سبز -->
<div class="container-fluid pb-5 extra-content London-Extra2-Day London-Extra2-Night" style="margin-top: 100px; background-color: #347928;color: #fff;">
    <div class="container text-center">
        <div class="row">
            <div class="col-md-3 text-right pr-4 pt-5">
                <h3><b>ارتباط با ما</b></h3>
                <a href="darbaremaa.php"><h5 style="margin-top: 40px;">درباره ما</h5></a>
                <a href="hamkare.php"><h5 style="margin-top: 40px;">همکاری باما</h5></a>
                <a href="veblak.php"><h5 style="margin-top: 40px;">وبلاگ</h5></a>
            </div>
            <div class="col-md-3 text-right pr-4 pt-5">
                <h3><b>مجوز های قانونی</b></h3>
                <h5 style="margin-top: 40px;">مجوز اقامت</h5>
                <h5 style="margin-top: 40px;">مجوز کمپینگ</h5>
                <h5 style="margin-top: 40px;">مجوز افراد</h5>
            </div>            
            <div class="col-md-6 pt-5 text-right">
                <h3><b>فضای مجازی</b></h3>
                <div class="row">
                    <div class="col-md-6  pr-5">
                        <img src="img/telk.webp" width="60px" alt="">
                        <img src="img/Instagram-Logo.png" width="80px" alt="">
                        <img src="img/bale_200_200_c1.png" width="60px" alt="">
                    </div>
                    <div class="col-md-6">
                        <img src="img/i namad a.png" width="123px" alt="">
                        <img src="img/i namad ta.png" width="123px" alt="">
                    </div>
                    <h6 class="mb-2 pb-2 mt-4" style="border-bottom: 2px #ffc107 solid;">ثبت نام درخبرنامه</h6>
                    <p>برای اطلاع از تخفیف کمپینگ پست الکتریکی خود را در باکس زیر وارد کنید</p>
                    <input type="text" class="inp-et" style="width: 400px;height: 45px;border-radius: 15px;padding: 10px;" placeholder="آدرس ایمیل">
                </div>
            </div>
        </div>
    </div>
</div>
<!-- رنگ نارنجی -->
<div class="container-fluid pb-5 extra-content Paris-Extra2-Day Paris-Extra2-Night" style="margin-top: 100px; background-color: #ff6b01;color: #fff;">
    <div class="container text-center">
        <div class="row">
            <div class="col-md-3 text-right pr-4 pt-5">
                <h3><b>ارتباط با ما</b></h3>
                <h5 style="margin-top: 40px;">درباره ما</h5>
                <h5 style="margin-top: 40px;">همکاری باما</h5>
                <h5 style="margin-top: 40px;">تماس باما</h5>
            </div>
            <div class="col-md-3 text-right pr-4 pt-5">
                <h3><b>مجوز های قانونی</b></h3>
                <h5 style="margin-top: 40px;">مجوز اقامت</h5>
                <h5 style="margin-top: 40px;">مجوز کمپینگ</h5>
                <h5 style="margin-top: 40px;">مجوز افراد</h5>
            </div>            
            <div class="col-md-6 pt-5 text-right">
                <h3><b>فضای مجازی</b></h3>
                <div class="row">
                    <div class="col-md-6  pr-5">
                        <img src="img/telk.webp" width="60px" alt="">
                        <img src="img/Instagram-Logo.png" width="80px" alt="">
                        <img src="img/bale_200_200_c1.png" width="60px" alt="">
                    </div>
                    <div class="col-md-6">
                        <img src="img/i namad a.png" width="123px" alt="">
                        <img src="img/i namad ta.png" width="123px" alt="">
                    </div>
                    <h6 class="mb-2 pb-2 mt-4" style="border-bottom: 2px #ffc107 solid;">ثبت نام درخبرنامه</h6>
                    <p>برای اطلاع از تخفیف کمپینگ پست الکتریکی خود را در باکس زیر وارد کنید</p>
                    <input type="text" class="inp-et" style="width: 400px;height: 45px;border-radius: 15px;padding: 10px;" placeholder="آدرس ایمیل">
                </div>
            </div>
        </div>
    </div>
</div>
<!-- رنگ آبی -->
<div class="container-fluid pb-5 extra-content Tokyo-Extra2-Day Tokyo-Extra2-Night" style="margin-top: 100px; background-color: #365ee2;color: #fff;">
    <div class="container text-center">
        <div class="row">
            <div class="col-md-3 text-right pr-4 pt-5">
                <h3><b>ارتباط با ما</b></h3>
                <h5 style="margin-top: 40px;">درباره ما</h5>
                <h5 style="margin-top: 40px;">همکاری باما</h5>
                <h5 style="margin-top: 40px;">تماس باما</h5>
            </div>
            <div class="col-md-3 text-right pr-4 pt-5">
                <h3><b>مجوز های قانونی</b></h3>
                <h5 style="margin-top: 40px;">مجوز اقامت</h5>
                <h5 style="margin-top: 40px;">مجوز کمپینگ</h5>
                <h5 style="margin-top: 40px;">مجوز افراد</h5>
            </div>            
            <div class="col-md-6 pt-5 text-right">
                <h3><b>فضای مجازی</b></h3>
                <div class="row">
                    <div class="col-md-6  pr-5">
                        <img src="img/telk.webp" width="60px" alt="">
                        <img src="img/Instagram-Logo.png" width="80px" alt="">
                        <img src="img/bale_200_200_c1.png" width="60px" alt="">
                    </div>
                    <div class="col-md-6">
                        <img src="img/i namad a.png" width="123px" alt="">
                        <img src="img/i namad ta.png" width="123px" alt="">
                    </div>
                    <h6 class="mb-2 pb-2 mt-4" style="border-bottom: 2px #ffc107 solid;">ثبت نام درخبرنامه</h6>
                    <p>برای اطلاع از تخفیف کمپینگ پست الکتریکی خود را در باکس زیر وارد کنید</p>
                    <input type="text" class="inp-et" style="width: 400px;height: 45px;border-radius: 15px;padding: 10px;" placeholder="آدرس ایمیل">
                </div>
            </div>
        </div>
    </div>
</div>

</body>
<script src="script.js"></script>
<script>
        // برای اسلایدر مرحله ها
    const contents = document.querySelectorAll(".slider-content");
    const prevBtn = document.getElementById("prev-btn");
    const nextBtn = document.getElementById("next-btn");
    const indicators = {
        1: document.getElementById("step-1-img"),
        2: document.getElementById("step-2-img"),
        3: document.getElementById("step-3-img"),
    };
    let currentStep = 1;

    function updateSlider(step) {
        const currentContent = document.querySelector(".slider-content.active");
        const newContent = contents[step - 1];

        // افکت خروجی
        currentContent.classList.remove("active");
        currentContent.style.opacity = 0;
        currentContent.style.transform = "scale(0.9)";

        setTimeout(() => {
            currentContent.style.display = "none";
            newContent.style.display = "block";

            // افکت ورودی
            setTimeout(() => {
                newContent.classList.add("active");
                newContent.style.opacity = 1;
                newContent.style.transform = "scale(1)";
            }, 50);
        }, 600);

        // تغییر عکس شماره‌ها
        Object.keys(indicators).forEach((key) => {
            indicators[key].src = parseInt(key) === step ? `img/${key}.png` : `img/${key}.2.png`;
        });
    }

    nextBtn.addEventListener("click", () => {
        currentStep = currentStep === 3 ? 1 : currentStep + 1;
        updateSlider(currentStep);
    });

    prevBtn.addEventListener("click", () => {
        currentStep = currentStep === 1 ? 3 : currentStep - 1;
        updateSlider(currentStep);
    });

// 
    // ورود و ثبت نام
    var modal = document.getElementById('id01');
    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }

    function ali_baba_vorod(op)
    {
        let x='';
        if(op == 'sabt')
        {
            x='<form action="" method="post"><h4 style="margin-top: 70px;">ثبت نام</h4><h6 class="text-right mt-3" style="margin-right: 80px;" required>تلفن همراه:</h6><input type="phone" name="phone_number" id="phone_number" class="in-pha in-ba-im text-right mt-0" placeholder="09123456789" required><h6 class="text-right mt-3" style="margin-right: 80px;" required>رمز دلخواه:</h6><input type="password" id="password" name="password" class="in-pha in-ba-im text-right mt-0"><h6 class="text-right mt-3" style="margin-right: 80px;">تکرار رمز عبور:</h6><input type="text" class="in-pha in-ba-im text-right mt-0"><input type="submit" name="acoontss" id="acoontss" class="btn btn-success mt-3" style="width: 170px;" value="ورود به پنل کاربری"></form>'
            document.getElementById('bendaz').innerHTML=x;
        }
    }

    // 
    // منوی همبرگری
    function toggleNav() {
        document.getElementById("mySidenav").style.width = "250px";
        document.getElementById("overlay").classList.add("show");
    }

    function closeNav() {
        document.getElementById("mySidenav").style.width = "0";
        document.getElementById("overlay").classList.remove("show");
    }
    // 
    // 

// 
// افکت بارون و برف و ایست
let intervalId;

    // لایه افکت
    const effectLayer = document.getElementById('effect-layer');

    function createRaindrop() {
      const raindrop = document.createElement('div');
      const positionX = Math.random() * window.innerWidth;
      const duration = Math.random() * 2 + 1;
      const size = Math.random() * 20 + 15;

      raindrop.classList.add('raindrop');
      raindrop.style.left = `${positionX}px`;
      raindrop.style.animationDuration = `${duration}s`;
      raindrop.style.height = `${size}px`;

      effectLayer.appendChild(raindrop);

      setTimeout(() => {
        raindrop.remove();
      }, duration * 1000);
    }

    function createSnowflake() {
      const snowflake = document.createElement('div');
      const size = Math.random() * 10 + 5;
      const positionX = Math.random() * window.innerWidth;

      snowflake.classList.add('snowflake');
      snowflake.style.width = `${size}px`;
      snowflake.style.height = `${size}px`;
      snowflake.style.left = `${positionX}px`;
      snowflake.style.animationDuration = `${Math.random() * 3 + 2}s`;

      effectLayer.appendChild(snowflake);

      setTimeout(() => {
        snowflake.remove();
      }, parseFloat(snowflake.style.animationDuration) * 1000);
    }

    function startEffect(effectFunction) {
      clearEffect(); // پاک کردن افکت‌های قبلی
      intervalId = setInterval(effectFunction, 30);
    }

    function clearEffect() {
      clearInterval(intervalId); // متوقف کردن ایجاد عناصر
      effectLayer.innerHTML = ''; // حذف تمام عناصر موجود
    }

    // افزودن رویداد کلیک به تصاویر
    document.getElementById('rain-img').addEventListener('click', () => startEffect(createRaindrop));
    document.getElementById('snow-img').addEventListener('click', () => startEffect(createSnowflake));
    document.getElementById('clear-img').addEventListener('click', clearEffect);
// 
// تغیر رنگ سایت
let currentContent = 'London'; // Default content
let currentTime = 'Day'; // Default time (روز)

function toggleContent(city) {
  currentContent = city; // Set current content to the selected city

  // Reset active states for all main icons
  document.querySelectorAll('.icon-container').forEach(icon => icon.classList.remove('active'));
  // Set active state for selected icon
  document.getElementById(`icon-${city}`).classList.add('active');

  // Hide all main content
  document.querySelectorAll('.content').forEach(content => content.classList.remove('active'));
  // Show selected main content
  document.getElementById(city).classList.add('active');

  // Automatically show the current time (Day/Night) sub-content
  toggleDayNight(currentTime);
}

function toggleDayNight(time) {
  currentTime = time; // Update the current time (روز/شب)

  // Reset active states for day/night icons
  document.querySelectorAll('#icon-Day, #icon-Night').forEach(icon => icon.classList.remove('active'));
  // Set active state for selected time
  document.getElementById(`icon-${time}`).classList.add('active');

  // Hide all sub-content of the current main content
  document.querySelectorAll(`#${currentContent} .sub-content`).forEach(sub => sub.classList.remove('active'));
  // Show the selected sub-content (Day or Night)
  document.getElementById(`${currentContent}-${time}`).classList.add('active');

  // Hide all extra content by default
  document.querySelectorAll('.extra-content').forEach(extra => extra.style.display = 'none');
  
  // Show extra content based on the selected time (Day or Night)
  const extraContentElement = document.querySelector(`#${currentContent}-Extra-${time}`);
  if (extraContentElement) {
    extraContentElement.style.display = 'block';
  }

  // Hide extra content 2 based on the selected time (Day or Night)
  const extraContentElement2 = document.querySelector(`#${currentContent}-Extra2-${time}`);
  if (extraContentElement2) {
    extraContentElement2.style.display = 'block';
  }

    // Hide extra content 3 based on the selected time (Day or Night)
    const extraContentElement3 = document.querySelector(`#${currentContent}-Extra3-${time}`);
  if (extraContentElement3) {
    extraContentElement3.style.display = 'block';
  }

    // Hide extra content 4 based on the selected time (Day or Night)
    const extraContentElement4 = document.querySelector(`#${currentContent}-Extra4-${time}`);
if (extraContentElement4) {
    extraContentElement4.style.display = 'block';
}

    // Show extra content 2 with class با کلاس
    document.querySelectorAll(`.${currentContent}-Extra2-${time}`).forEach(extra2 => {
    extra2.style.display = 'block';
  });

  // تغییر رنگ پس‌زمینه و متن بر اساس روز یا شب
  if (time === 'Day') {
    document.body.style.backgroundColor = '#fffbe7'; // رنگ آبی روشن برای روز
    document.body.classList.remove('night-mode'); // حذف کلاس شب
  } else {
    document.body.style.backgroundColor = '#1b213b'; // رنگ سرمه‌ای برای شب
    document.body.classList.add('night-mode'); // اضافه کردن کلاس شب
  }
}

// Automatically open the default tab and sub-content
window.onload = function() {
  toggleContent('London');
};

// 
// پخش کننده صدا
let currentAudio = null;

        function toggleSound(button, type) {
            const soundMap = {
                rain: 'sounds/rain.mp3',
                sea: 'sounds/sea.mp3',
                forest: 'sounds/forest.mp3',
                fire: 'sounds/fire.mp3'
            };

            const playIconSrc = button.getAttribute('data-play-icon');
            const pauseIconSrc = button.getAttribute('data-pause-icon');
            const icon = button.querySelector('.play-icon img');

            // اگر صدای دیگری در حال پخش است، متوقف شود
            if (currentAudio && currentAudio.dataset.type !== type) {
                currentAudio.pause();
                document.querySelectorAll('.play-icon img').forEach(img => img.src = playIconSrc);
            }

            // بررسی وضعیت صدا
            if (!currentAudio || currentAudio.dataset.type !== type) {
                currentAudio = new Audio(soundMap[type]);
                currentAudio.dataset.type = type;

                currentAudio.play();
                icon.src = pauseIconSrc;

                currentAudio.onended = () => {
                    icon.src = playIconSrc;
                };
            } else if (currentAudio.paused) {
                currentAudio.play();
                icon.src = pauseIconSrc;
            } else {
                currentAudio.pause();
                icon.src = playIconSrc;
            }
        }

        function changeButtonColors(color) {
            document.querySelectorAll('.sound-button').forEach(button => {
                button.style.backgroundColor = color;
            });
        }
        
        // 
        // فارسی کردن عدد
function convertNumbersToPersian() {
    const persianNumbers = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
    document.querySelectorAll('.persian-number').forEach(el => {
        el.innerHTML = el.innerHTML.replace(/\d/g, d => persianNumbers[d]);
    });
}

  // وقتی صفحه لود شد اعداد فارسی شوند
document.addEventListener("DOMContentLoaded", convertNumbersToPersian);

</script>
</html>