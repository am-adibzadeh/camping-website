<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "camping";

// اتصال به پایگاه‌داده
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// بررسی لاگین بودن
if (!isset($_SESSION['id'])) {
    header('location: index.php');
    exit;
}


// گرفتن id کاربر مورد نظر برای ویرایش
if (isset($_GET['id'])) {
    $edit_id = intval($_GET['id']);
    $sql = "SELECT * FROM users WHERE id = $edit_id";
    $result = $conn->query($sql);
    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
    } else {
        echo "کاربر مورد نظر یافت نشد.";
        exit;
    }
} else {
    echo "هیچ کاربری برای ویرایش انتخاب نشده است.";
    exit;
}

// ذخیره تغییرات
if (isset($_POST["editsubmit"])) {
    $name = $_POST["name"];
    $codmidi = $_POST["codmidi"];
    $adres = $_POST["adres"];
    $email = $_POST["email"];
    $phone = $_POST["phone_number"];
    $role = $_POST["role"];
    $password = $_POST["password"];

    if ($password == '') {
        $sql = "UPDATE users SET phone_number='$phone', name='$name', codmidi='$codmidi', adres='$adres', email='$email', role='$role' WHERE id = $edit_id";
    } else {
        $sql = "UPDATE users SET phone_number='$phone', password='$password', name='$name', codmidi='$codmidi', adres='$adres', email='$email', role='$role' WHERE id = $edit_id";
    }

    $conn->query($sql);
    header('location: Account.admin.php'); // به صفحه مدیریت برمی‌گردی
    exit;
}
?>




<!DOCTYPE html>
<html lang="en" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <!-- jQuery library -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>
    <!-- Popper JS -->
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>

    <title>کمپینگ</title>

    <link rel="stylesheet" href="Account.css">

    <!-- لوگو سایت -->
    <link rel="icon" type="img/download.jpg" sizes="192x192" href="img/camping_1f3d5 1.png">
</head>
<body>
<form method="post">
    <div class="row pl-5 pr-5 mt-5">
        <div class="col-md-12">
            <div class="cr-zard">
                <div class="inner-box">
                    <div class="row">
                        <div class="col-md-10 text-center" style="padding-right: 200px;">
                            <h4>اطلاعات شخصی</h4>
                        </div>
                        <div class="col-md-2">
                            <div class="action-btns">
                                <button class="edit">
                                    <i class="fas fa-edit"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                    <img src="img/Line long.png" width="100%" height="100%" alt="">
                    <div class="col-md-12">
                        <div class="row text-right mt-4">
                            <div class="col-md-2">نام و نام خوانوادگی:</div>
                            <div class="col-md-2"><input type="name" name="name" id="name" class="form-control" value="<?php echo $row['name']; ?>"></div>
                            <div class="col-md-2">تاریخ تولد:</div>
                            <div class="col-md-2"><input type="text" name="" id="" class="form-control" value="1386/05/21"></div>
                            <div class="col-md-2">کدملی:</div>
                            <div class="col-md-2"><input type="text" name="codmidi" id="codmidi" class="form-control" value="<?php echo $row['codmidi']; ?>"></div>
                        </div>
                        <div class="row text-right mt-5">
                            <div class="col-md-2">آدرس اینترنتی:</div>
                            <div class="col-md-2"><input type="email" name="email" id="email" class="form-control" value="<?php echo $row["email"]; ?>"></div>
                            <div class="col-md-3"></div>
                            <div class="col-md-2">شماره تلفن:</div>
                            <div class="col-md-2"><input type="phone" name="phone_number" id="phone_number" class="form-control" value="<?php echo $row['phone_number']; ?>"></div>
                        </div>
                        <div class="row text-right mt-5">
                            <div class="col-md-2">آدرس محل سکونت:</div>
                                <input type="text" name="adres" id="adres" class="form-control" value="<?php echo $row["adres"]; ?>">
                        </div>
                        <div class="row text-right mt-5">
                            <div class="col-md-2 mt-4">رمز عبور:</div>
                            <div class="col-md-2 mt-4"><input type="text" name="password" id="password" class="form-control"></div>
                            <div class="col-md-3">
                            <div class="form-group">
                                <label for="">قابلیت</label>
                                <select name="role" id="role" class="form-control">
                                    <option value="admin" <?php if( $row["role"]=='admin'){ echo "selected"; } ?> >مدیر</option>
                                    <option value="user" <?php if( $row["role"]=='user'){ echo "selected"; } ?>>مشتری</option>
                                </select>
                            </div>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <input type="submit" class="btn btn-warning" value="ذخیره تغیرات" id="editsubmit" name="editsubmit">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>

</body>
</html>