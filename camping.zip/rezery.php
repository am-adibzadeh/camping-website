<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "camping";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

if(!isset($_SESSION['id'])) {
    header('location: index.php');
exit;
}
?>


<!DOCTYPE html>
<html lang="en" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <!-- jQuery library -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>
    <!-- Popper JS -->
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>

    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="rezery.css">

    <title>رزرو کمپینگ</title>

    <!-- لوگو سایت -->
    <link rel="icon" type="img/download.jpg" sizes="192x192" href="img/camping_1f3d5 1.png">
</head>
<body>

<!-- هدر -->
<div class="container-fluid text-center sticky-top" style="color: #000;">
    <div class="row shadow bg-warning mt-4 p-2 mr-5 ml-5" style="border-radius: 15px; position: relative; z-index: 3;">
        <!-- عنوان کمپینگ -->
        <div class="col-md-2 pl-md-5" style="font-family: yekanBlack;">
            <h2 style="color: #000;"><b>کمپینگ</b></h2>
        </div>

        <!-- دکمه همبرگر و ورود/ثبت‌نام برای موبایل -->
        <div class="container-fluid d-md-none">
            <div class="row">
                <div class="col-10">            
                <?php
                    if (isset($_SESSION['id'])) {
                        $userId = $_SESSION['id'];
                        $sql = "SELECT * FROM users WHERE id = '$userId'";
                        $result = $conn->query($sql);
                        
                        if ($result->num_rows > 0) {
                            $row = $result->fetch_assoc();
                    ?>
                            <div class="dropdown ml-auto mt-1">
                                <a class="dropdown-toggle d-flex align-items-center" href="#" id="userDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <img src="img/icons8-user-96.png" class="ml-1" height="30px" alt="">
                                    <?php echo '<p class="persian-number pt-3">' . $row['phone_number'] . '</p>'; ?>
                                </a>
                                <div class="dropdown-menu dropdown-menu-left text-right" aria-labelledby="userDropdown">
                                    <a class="dropdown-item" href="#">اطلاعات حساب کاربری</a>
                                    <a class="dropdown-item" href="#"></a>
                                    <a class="dropdown-item" href="#">اعلان ها</a>
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item text-danger" href="logout.php">خروج</a>
                                </div>
                            </div>
                    <?php
                        }
                    } else {
                    ?>
                        <!-- دکمه ورود/ثبت‌نام برای زمانی که لاگین نیست -->
                        <div class="col-md-2 text-left pt-1 d-none d-md-block">
                            <button type="button" class="btn btn-success" onclick="document.getElementById('id01').style.display='block'">ورود / ثبت نام</button>
                        </div>
                    <?php
                    }
                    ?>                
                </div>
                <div class="col-2 text-left">
                    <button class="navbar-toggler" type="button" onclick="toggleNav()">
                        <img src="img/icons8-menu-208.png" width="20px" alt="">
                    </button>
                </div>
            </div>
        </div>

        <!-- منوی ناوبری (فقط در دسکتاپ نمایش داده شود) -->
        <div class="col-md-8 pr-md-5 pl-md-5 d-none d-md-block">
            <ul class="nav navbar justify-content-center">
                <a href="index.php"><li class="nav-item mx-5">صفحه اصلی</li></a>
                <a href="rezery.php?item=tree&time=day"><li class="nav-item mx-5">رزروکمپ</li></a>
                <a href="http://localhost:5000/" onclick="alert('این هوش مصنوعی برای کمپینگ است و به سوال‌های غیر مرتبط پاسخ نمی‌دهد.')">
                    <li class="nav-item mx-5">هوش مصنوعی <small style="font-size: 8px;color: red;">(جدید)</small></li>
                </a>
                <a href="tamasbama.php"><li class="nav-item mx-5">تماس باما</li></a>
            </ul>
        </div>

        <?php
    if (isset($_SESSION['id'])) {
        $userId = $_SESSION['id'];
        $sql = "SELECT * FROM users WHERE id = '$userId'";
        $result = $conn->query($sql);
        
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
    ?>
    <div class="dropdown ml-auto mt-1 con-desktop">
        <a class="dropdown-toggle d-flex align-items-center" href="#" id="userDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <img src="img/icons8-user-96.png" class="ml-1" height="30px" alt="">
            <?php echo '<p class="persian-number pt-3">' . $row['phone_number'] . '</p>'; ?>
        </a>
        <div class="dropdown-menu dropdown-menu-left text-right" aria-labelledby="userDropdown">
            <a class="dropdown-item" href="Account.php">اطلاعات حساب کاربری</a>
            
            <?php
            // اینجا چک میکنیم اگر نقش admin بود، لینک تنظیمات رو هم نشون بده
            if (isset($row['role']) && $row['role'] === 'admin') {
                echo '<a class="dropdown-item" href="Account.admin.php">تنظیمات</a>';
            }
            ?>

            <a class="dropdown-item" href="#">اعلان ها</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item text-danger" href="logout.php">خروج</a>
        </div>
    </div>
<?php
    }
} else {
?>
    <!-- دکمه ورود/ثبت‌نام برای زمانی که لاگین نیست -->
    <div class="col-md-2 text-left pt-1 d-none d-md-block">
        <button type="button" class="btn btn-success" onclick="document.getElementById('id01').style.display='block'">ورود / ثبت نام</button>
    </div>
<?php
}
?>

    </div>
</div>

<!-- ساید ناوبری برای موبایل -->
<div id="mySidenav" class="sidenav">
    <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
    <a href="index.php">صفحه اصلی</a>
    <a href="rezery.php">رزروکمپ</a>
    <a href="ai camping.php" onclick="alert('این هوش مصنوعی برای کمپینگ است و به سوال‌های غیر مرتبط پاسخ نمی‌دهد.')">هوش مصنوعی <small style="font-size: 8px;color: red;">(جدید)</small></a>
    <a href="">تماس باما</a>
</div>

<!-- پس‌زمینه‌ی تاریک هنگام باز شدن منوی موبایل -->
<div id="overlay" class="overlay" onclick="closeNav()"></div>





<!-- درخت روز -->
<div id="tree-day" class="content-section">

    <!-- مرحله ها -->
    <div class="container-fluid">
        <div class="row mt-4">
            <div class="col-md-1"></div>
            <!-- لیست اول (تصاویر) -->
            <ul class="col-11 col-md-10 nav navbar pb-0 d-flex justify-content-center flex-wrap mr-2">
                <li><img src="img/1.png" width="45px" class="navbar-brand" alt=""></li>
                <li><img src="img/titi.png" width="300px" class="navbar-brand" height="25px" alt=""></li>
                <li><img src="img/2.2.png" width="45px" class="navbar-brand" alt=""></li>
                <li><img src="img/titi.png" width="300px" class="navbar-brand" height="25px" alt=""></li>
                <li><img src="img/3.2.png" width="45px" class="navbar-brand" alt=""></li>
                <li><img src="img/titi.png" width="300px" class="navbar-brand" height="25px" alt=""></li>
                <li><img src="img/4.2.png" width="45px" class="navbar-brand" alt=""></li>
            </ul>
            
            <!-- لیست دوم (متن‌ها) -->
            <div class="col-md-3 pr-5 text-center con-desktop">
                <h6>انتخاب محل کمپ</h6>
            </div>
            <div class="col-md-3 text-center pr-5 con-desktop">
                <h6>انتخاب منطقه</h6>
            </div>
            <div class="col-md-3 text-center pr-5 con-desktop">
                <h6>اجاره ابزارآلات</h6>
            </div>
            <div class="col-md-3 text-center pr-5 con-desktop">
                <h6>پرداخت</h6>
            </div>
        </div>
    </div>


    <!-- جستوجو -->
    <div class="container mt-5">
        <div class="row">
            <div class="col-sm-10 col-md-12 text-center">
                <input id="search-1" type="text" class="in-serg" placeholder="اسم منطقه کمپ، شهر، روستا، جنگل، کویر و ..." style="width: 100%;">
            </div>
        </div>
    </div>


    <!-- پربازدید ها -->
    <div class="container-fluid text-center p-5">
        <div class="row text-right cor-1">
            <h5>برترین های جنگل</h5>
        </div>
        <div class="row mt-4">

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1 text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/pictures-template-2(17).jpg" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۴.۶</p>
                        <div class="col-md-12 m-0 p-0"><h6>جنگل المیستان ، <small style="font-size: 11px;color: #c6c6c6;">استان مازندران - بابل</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=tree&time=day">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1 text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/53b9c6469c5b76c007b96ff6.jpg" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۵.۰</p>
                        <div class="col-md-12 m-0 p-0"><h6>جنگل ابر، <small style="font-size: 11px;color: #c6c6c6;">شاهرود</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=tree&time=day">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1 text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/ییلاق-ماسال-1.webp" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۴.۲</p>
                        <div class="col-md-12 m-0 p-0"><h6>جنگل ییلاقات ماسال، <small style="font-size: 11px;color: #c6c6c6;">استان مازندران - گیلان</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=tree&time=day">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1 text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/جنگل-دالخانی.webp" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۴.۵</p>
                        <div class="col-md-12 m-0 p-0"><h6>جنگل دالخانی، <small style="font-size: 11px;color: #c6c6c6;">رامسر</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=tree&time=day">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>
            
        </div>

        <!-- برترین های کویر -->
        <div class="row text-right cor-1 mt-4">
            <h5>برترین های کویر</h5>
        </div>
        <div class="row mt-4">

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1 text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/The-Maranjab-Desert-ezgif.com-optiwebp.webp" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۴.۸</p>
                        <div class="col-md-12 m-0 p-0"><h6>کویر مرنجاب، <small style="font-size: 11px;color: #c6c6c6;">استان اصفهان</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=tree&time=day">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1 text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/loot-sh.jpg_34xzfheh.uqc.jpg" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۵.۰</p>
                        <div class="col-md-12 m-0 p-0"><h6>کویر لوت، <small style="font-size: 11px;color: #c6c6c6;">استان‌های کرمان</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=tree&time=day">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1 text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/Articlee14fe676-9263-4e65-920e-357d46501de9_mihmansho.jpg" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۵.۰</p>
                        <div class="col-md-12 m-0 p-0"><h6>کویر زردگاه، <small style="font-size: 11px;color: #c6c6c6;">استان خراسان جنوبی</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=tree&time=day">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1 text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/1195fa02-fae7-461b-944a-e76b9e1c789c.webp" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۴.۵</p>
                        <div class="col-md-12 m-0 p-0"><h6>کویر ریگ جن، <small style="font-size: 11px;color: #c6c6c6;">استان‌های سمنان</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=tree&time=day">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>
            
        </div>

        <!-- برترین های کوهستانی -->
        <div class="row text-right cor-1 mt-4">
            <h5>برترین های کوهستانی</h5>
        </div>
        <div class="row mt-4">

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1 text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/981012-Damavand-South-IMG_9861-2.jpg" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۴.۳</p>
                        <div class="col-md-12 m-0 p-0"><h6>کوه دماوند، <small style="font-size: 11px;color: #c6c6c6;">استان البرز</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=tree&time=day">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1 text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/رشته-کوه-زاگرس.jpg" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۴.۱</p>
                        <div class="col-md-12 m-0 p-0"><h6>رشته کوه زاگرس، <small style="font-size: 11px;color: #c6c6c6;">استان‌ کردستان</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=tree&time=day">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1 text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/114839.jpg" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۳.۲</p>
                        <div class="col-md-12 m-0 p-0"><h6>قله الوند، <small style="font-size: 11px;color: #c6c6c6;">استان همدان</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=tree&time=day">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1 text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/c2461595-3144-4b98-9116-d96359d4a7b1.webp" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۲.۹</p>
                        <div class="col-md-12 m-0 p-0"><h6>قلهٔ بینالود، <small style="font-size: 11px;color: #c6c6c6;">استان خراسان رضوی</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=tree&time=day">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>
            
        </div>

            <!-- پرطرفدار ترین -->
            <div class="row text-right cor-1 mt-4">
                <h5>پرطرفدار ترین</h5>
            </div>
            <div class="row mt-4">
        
                <div class="col-md-3 col-12 mb-2">
                    <div class="container-fluid codr-1 text-right" style="padding: 13px 30px;">
                        <div class="row">
                            <img src="img/چالوس-جاده-1.jpg" class="im-1" width="100%" height="190px" alt="">
                            <img src="img/star.gif" width="20px" height="20px" alt="">
                            <p style="font-size: 11px;" class="mt-1">۴.۶</p>
                            <div class="col-md-12 m-0 p-0"><h6>فین چالوس، <small style="font-size: 11px;color: #c6c6c6;">استان مازندران</small></h6></div>
                            <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=tree&time=day">جزئیات و رزرو</a></div>
                        </div>
                    </div>
                </div>
        
                <div class="col-md-3 col-12 mb-2">
                    <div class="container-fluid codr-1 text-right" style="padding: 13px 30px;">
                        <div class="row">
                            <img src="img/خارا.jpg" class="im-1" width="100%" height="190px" alt="">
                            <img src="img/star.gif" width="20px" height="20px" alt="">
                            <p style="font-size: 11px;" class="mt-1">۴.۶</p>
                            <div class="col-md-12 m-0 p-0"><h6>کویر خارا، <small style="font-size: 11px;color: #c6c6c6;">استان‌ اصفهان</small></h6></div>
                            <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=tree&time=day">جزئیات و رزرو</a></div>
                        </div>
                    </div>
                </div>
        
                <div class="col-md-3 col-12 mb-2">
                    <div class="container-fluid codr-1 text-right" style="padding: 13px 30px;">
                        <div class="row">
                            <img src="img/981012-Damavand-South-IMG_9861-2.jpg" class="im-1" width="100%" height="190px" alt="">
                            <img src="img/star.gif" width="20px" height="20px" alt="">
                            <p style="font-size: 11px;" class="mt-1">۴.۳</p>
                            <div class="col-md-12 m-0 p-0"><h6>کوه دماوند، <small style="font-size: 11px;color: #c6c6c6;">استان البرز</small></h6></div>
                            <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=tree&time=day">جزئیات و رزرو</a></div>
                        </div>
                    </div>
                </div>
        
                <div class="col-md-3 col-12 mb-2">
                    <div class="container-fluid codr-1 text-right" style="padding: 13px 30px;">
                        <div class="row">
                            <img src="img/WhatsApp_Image_2021-12-13_at_12.06.25.jpg " class="im-1" width="100%" height="190px" alt="">
                            <img src="img/star.gif" width="20px" height="20px" alt="">
                            <p style="font-size: 11px;" class="mt-1">۴.۶</p>
                            <div class="col-md-12 m-0 p-0"><h6>ساحل گیسوم ، <small style="font-size: 11px;color: #c6c6c6;">استان هرمزگان</small></h6></div>
                            <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=tree&time=day">جزئیات و رزرو</a></div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- بالاترین نمره -->
            <div class="row text-right cor-1 mt-4">
                <h5>بالاترین نمره</h5>
            </div>
            <div class="row mt-4">
        
                <div class="col-md-3 col-12 mb-2">
                    <div class="container-fluid codr-1 text-right" style="padding: 13px 30px;">
                        <div class="row">
                            <img src="img/53b9c6469c5b76c007b96ff6.jpg" class="im-1" width="100%" height="190px" alt="">
                            <img src="img/star.gif" width="20px" height="20px" alt="">
                            <p style="font-size: 11px;" class="mt-1">۵.۰</p>
                            <div class="col-md-12 m-0 p-0"><h6>جنگل ابر، <small style="font-size: 11px;color: #c6c6c6;">شاهرود</small></h6></div>
                            <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=tree&time=day">جزئیات و رزرو</a></div>
                        </div>
                    </div>
                </div>
        
                <div class="col-md-3 col-12 mb-2">
                    <div class="container-fluid codr-1 text-right" style="padding: 13px 30px;">
                        <div class="row">
                            <img src="img/Articlee14fe676-9263-4e65-920e-357d46501de9_mihmansho.jpg" class="im-1" width="100%" height="190px" alt="">
                            <img src="img/star.gif" width="20px" height="20px" alt="">
                            <p style="font-size: 11px;" class="mt-1">۵.۰</p>
                            <div class="col-md-12 m-0 p-0"><h6>کویر زردگاه، <small style="font-size: 11px;color: #c6c6c6;">استان خراسان جنوبی</small></h6></div>
                            <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=tree&time=day">جزئیات و رزرو</a></div>
                        </div>
                    </div>
                </div>
        
                <div class="col-md-3 col-12 mb-2">
                    <div class="container-fluid codr-1 text-right" style="padding: 13px 30px;">
                        <div class="row">
                            <img src="img/Google-Maps-11-1.jpg" class="im-1" width="100%" height="190px" alt="">
                            <img src="img/star.gif" width="20px" height="20px" alt="">
                            <p style="font-size: 11px;" class="mt-1">۵.۰</p>
                            <div class="col-md-12 m-0 p-0"><h6>جنگل راش سنگده، <small style="font-size: 11px;color: #c6c6c6;">استان مازندران</small></h6></div>
                            <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=tree&time=day">جزئیات و رزرو</a></div>
                        </div>
                    </div>
                </div>
        
                <div class="col-md-3 col-12 mb-2">
                    <div class="container-fluid codr-1 text-right" style="padding: 13px 30px;">
                        <div class="row">
                            <img src="img/hirkani-jungle.webp" class="im-1" width="100%" height="190px" alt="">
                            <img src="img/star.gif" width="20px" height="20px" alt="">
                            <p style="font-size: 11px;" class="mt-1">۵.۰</p>
                            <div class="col-md-12 m-0 p-0"><h6>جنگل سیاه بیشه، <small style="font-size: 11px;color: #c6c6c6;">استان مازندران</small></h6></div>
                            <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=tree&time=day">جزئیات و رزرو</a></div>
                        </div>
                    </div>
                </div>
            </div>
    </div>

    <!-- نقشه ایران -->
    <div class="container-fluid text-center mt-5 map-desktop">
        <h2>از روی نقشه انتخاب کنید</h2>
        <div style="background-image: url(img/dayere-posht-naghshe.png); width: 100%;height: 1460px;">
                <img src="img/ir_map.png" usemap="#image-map">
                <map name="image-map">
                    <area target="_blank" alt="خراسان شمالی" title="خراسان شمالی" href="mantagi.php?item=tree&time=day" coords="813,172,821,170,832,178,845,177,848,168,854,172,855,184,863,196,879,196,907,206,926,218,929,211,938,225,922,259,931,270,913,282,915,300,898,300,861,278,837,281,813,296,781,285,784,264,767,247,796,222,790,214,785,189,804,172" shape="poly">
                    <area target="_blank" alt="خراسان رضوی" title="خراسان رضوی" href="mantagi.php?item=tree&time=day" coords="931,213,979,224,989,244,1028,254,1043,285,1092,282,1095,302,1107,360,1097,393,1093,437,1078,440,1089,454,1067,473,1068,489,1048,497,1031,484,1011,488,995,478,951,481,939,464,908,461,884,434,893,420,862,408,820,431,796,438,827,406,840,391,854,373,825,340,825,317,827,303,815,299,840,278,863,282,905,305,915,299,909,285,932,270,920,259,938,232" shape="poly">
                    <area target="_blank" alt="خراسان جنوبی" title="خراسان جنوبی" href="mantagi.php?item=tree&time=day" coords="1067,490,1067,513,1097,519,1074,551,1096,625,1097,669,1117,676,1111,717,1117,751,1102,755,1089,736,1070,729,1014,748,991,706,827,638,811,623,804,600,763,573,740,538,746,520,749,469,774,469,793,441,857,407,893,419,885,435,902,458,938,461,952,482,992,477,1011,488,1031,483,1045,496" shape="poly">
                    <area target="_blank" alt="سیستان و بلوچستان" title="سیستان و بلوچستان" href="mantagi.php?item=tree&time=day" coords="1117,676,1160,679,1163,719,1110,795,1144,831,1167,875,1185,890,1224,901,1228,908,1242,908,1252,966,1250,981,1279,983,1289,989,1279,1025,1234,1037,1197,1066,1183,1147,1167,1153,1115,1142,1014,1139,1007,1115,984,1100,990,1045,979,1004,986,936,993,923,983,911,1016,888,1007,863,1013,852,1013,822,1004,811,1014,748,1070,732,1092,739,1101,751,1117,748,1109,718" shape="poly">
                    <area target="_blank" alt="گلستان" title="گلستان" href="mantagi.php?item=tree&time=day" coords="782,187,763,182,744,185,725,199,705,213,703,230,692,235,667,244,645,244,658,276,650,284,668,299,675,313,693,308,719,287,751,288,761,248,775,232,798,223,787,215" shape="poly">
                    <area target="_blank" alt="مازندران" title="مازندران" href="mantagi.php?item=tree&time=day" coords="673,308,667,297,650,289,635,283,627,278,582,290,532,300,504,297,479,289,448,270,440,272,431,285,464,317,481,323,497,334,520,340,534,355,549,360,567,346,582,358,588,348,604,358,631,354,654,325,657,314" shape="poly">
                    <area target="_blank" alt="گیلان" title="گیلان" href="mantagi.php?item=tree&time=day" coords="449,269,440,264,431,254,426,236,409,230,378,225,358,211,349,197,346,176,346,153,332,155,337,164,332,178,327,201,335,222,344,237,344,248,364,275,390,295,432,289,437,277" shape="poly">
                    <area target="_blank" alt="اردبیل" title="اردبیل" href="mantagi.php?item=tree&time=day" coords="341,244,339,231,325,199,334,164,321,141,301,124,303,111,319,108,305,88,320,79,301,55,291,54,241,84,246,109,264,97,267,112,260,121,267,131,254,154,269,166,281,162,285,190,296,193,293,218,304,231,307,243,316,247,332,254" shape="poly">
                    <area target="_blank" alt="آذربایجان شرقی" title="آذربایجان شرقی" href="mantagi.php?item=tree&time=day" coords="238,84,227,93,211,112,187,112,150,100,140,107,140,120,123,143,129,160,127,187,134,201,137,220,157,235,187,256,197,250,207,246,219,261,216,273,238,276,257,252,279,247,298,252,308,247,302,232,298,196,285,189,279,162,269,166,255,154,266,130,257,124,268,114,263,97,244,106" shape="poly">
                    <area target="_blank" alt="آذربایجان غربی" title="آذربایجان غربی" href="mantagi.php?item=tree&time=day" coords="145,95,139,80,128,73,119,57,100,35,87,46,86,59,63,54,69,73,75,123,80,142,66,169,84,189,84,207,96,224,93,239,99,247,93,255,107,269,107,284,117,294,121,312,121,321,132,323,143,307,163,302,166,292,208,293,222,302,240,299,244,289,237,276,222,274,219,259,207,246,186,254,139,221,128,188,123,141,138,120" shape="poly">
                    <area target="_blank" alt="کردستان" title="کردستان" href="mantagi.php?item=tree&time=day" coords="239,305,244,291,267,300,281,314,278,341,288,350,272,356,278,377,291,397,270,407,250,396,229,408,223,419,199,423,184,389,167,382,160,363,162,353,181,341,156,343,134,326,138,307,160,303,168,291,204,291,223,300" shape="poly">
                    <area target="_blank" alt="زنجان" title="زنجان" href="mantagi.php?item=tree&time=day" coords="345,248,327,252,311,244,305,249,276,246,260,255,239,275,241,290,274,300,280,319,279,337,290,350,309,361,337,364,331,343,339,338,364,338,370,317,348,291,363,279,360,269" shape="poly">
                    <area target="_blank" alt="قزوین " title="قزوین " href="mantagi.php?item=tree&time=day" coords="369,306,352,297,350,285,362,275,378,287,399,293,435,290,469,314,438,313,448,326,443,340,425,350,421,361,408,366,392,372,378,376,362,376,346,369,340,361,332,349,340,337,356,342,369,335,373,323" shape="poly">
                    <area target="_blank" alt="همدان" title="همدان" href="mantagi.php?item=tree&time=day" coords="341,369,325,365,308,361,291,361,275,360,276,377,288,390,288,405,276,406,269,411,268,423,261,430,278,442,269,446,269,459,282,471,302,477,322,477,334,485,346,476,345,459,337,441,345,434,350,423,354,417,364,417,372,431,378,426,372,413,362,408,369,405,369,394,375,382,363,375" shape="poly">
                    <area target="_blank" alt="کرمانشاه " title="کرمانشاه " href="mantagi.php?item=tree&time=day" coords="266,406,247,397,235,405,221,419,202,422,182,384,168,387,149,400,134,420,119,449,127,461,114,477,132,504,139,476,161,476,180,485,194,494,229,488,243,467,255,459,268,449,278,441,260,428" shape="poly">
                    <area target="_blank" alt="ایلام" title="ایلام" href="mantagi.php?item=tree&time=day" coords="195,491,171,478,147,473,134,500,159,537,153,555,175,564,218,599,229,599,241,624,252,617,252,608,267,587,258,561,232,534,221,531,209,507,222,502,241,495,244,483" shape="poly">
                    <area target="_blank" alt="اراک" title="اراک" href="mantagi.php?item=tree&time=day" coords="449,419,462,377,449,367,421,364,377,373,363,406,378,424,373,434,362,422,348,428,338,438,345,467,337,488,338,506,355,506,363,495,374,497,377,510,392,516,403,523,461,502,468,485,457,477,444,478,432,467,415,471,407,447,413,428,437,420" shape="poly">
                    <area target="_blank" alt="فارسی" title="فارسی" href="mantagi.php?item=tree&time=day" coords="769,241,754,266,754,284,713,287,696,308,673,309,656,314,654,334,628,356,604,360,605,375,596,389,573,395,533,382,525,382,534,403,523,422,521,447,544,459,560,457,585,471,746,469,775,467,852,373,826,343,827,302,811,295,785,287,782,260" shape="poly">
                    <area target="_blank" alt="تهران" title="تهران" href="mantagi.php?item=tree&time=day" coords="601,372,603,356,587,349,583,357,568,347,550,359,528,355,525,342,498,336,492,342,483,353,462,355,451,366,462,377,457,396,467,400,524,421,533,407,525,384,532,376,546,387,573,394,597,388" shape="poly">
                    <area target="_blank" alt="البرز" title="البرز" href="mantagi.php?item=tree&time=day" coords="492,334,481,324,464,317,445,314,443,320,446,331,440,344,428,350,422,356,429,365,454,369,461,355,481,354,488,342" shape="poly">
                    <area target="_blank" alt="قم" title="قم" href="mantagi.php?item=tree&time=day" coords="523,419,460,397,449,417,415,430,410,447,416,469,431,466,445,478,468,473,473,458,522,448,525,431" shape="poly">
                    <area target="_blank" alt="اصفهان" title="اصفهان" href="mantagi.php?item=tree&time=day" coords="748,471,584,473,564,456,542,462,521,454,472,460,467,477,472,486,402,523,398,548,368,576,382,586,384,597,407,592,420,602,452,594,464,623,480,641,474,667,481,701,474,711,505,733,517,694,508,683,534,668,544,682,584,674,587,611,609,596,645,600,707,576,726,542,742,539,746,521" shape="poly">
                    <area target="_blank" alt="لرستان" title="لرستان" href="mantagi.php?item=tree&time=day" coords="369,572,374,566,385,554,405,531,382,514,376,495,364,496,351,507,337,502,335,485,316,479,293,477,262,452,247,464,233,479,245,484,240,493,211,506,222,531,235,532,257,561,264,584,284,558,298,560,315,557,327,564,339,564,350,576,358,577" shape="poly">
                    <area target="_blank" alt="خوزستان" title="خوزستان" href="mantagi.php?item=tree&time=day" coords="243,624,254,614,252,602,280,557,302,559,313,557,340,563,364,577,384,589,390,625,410,653,419,669,413,681,392,695,394,714,404,724,420,742,415,759,419,777,398,771,388,779,362,795,354,783,337,781,329,771,325,787,309,788,290,788,280,766,266,752,269,714,245,708,251,678,257,654" shape="poly">
                    <area target="_blank" alt="چهارمحال بختیاری" title="چهارمحال بختیاری" href="mantagi.php?item=tree&time=day" coords="404,638,390,623,382,601,408,591,415,596,448,593,468,611,479,638,479,667,481,693,475,706,457,712,438,693,413,678,420,667" shape="poly">
                    <area target="_blank" alt="یزد" title="یزد" href="mantagi.php?item=tree&time=day" coords="582,670,582,652,588,638,584,610,607,598,643,599,711,575,723,540,739,538,757,569,802,600,811,623,827,638,810,657,770,673,769,712,704,722,684,739,696,770,698,792,697,804,681,805,656,795,658,775,640,748,608,685" shape="poly">
                    <area target="_blank" alt="کهکیوره و بویر احمد" title="کهکیوره و بویر احمد" href="mantagi.php?item=tree&time=day" coords="502,731,501,743,488,751,464,742,468,763,464,775,448,779,433,781,421,777,414,760,417,739,402,730,391,698,413,682,432,688,452,710,474,701" shape="poly">
                    <area target="_blank" alt="بوشهر" title="بوشهر" href="mantagi.php?item=tree&time=day" coords="391,778,397,770,426,776,439,805,469,810,478,832,495,841,502,864,521,894,524,917,541,933,555,970,579,993,563,1000,556,982,543,976,521,963,501,962,477,948,460,913,460,899,448,888,448,863,433,835,402,800" shape="poly">
                    <area target="_blank" alt="فارس" title="فارس" href="mantagi.php?item=tree&time=day" coords="431,779,469,770,466,745,501,754,515,687,534,669,544,678,591,677,613,695,655,770,655,790,680,804,698,835,723,842,733,878,734,893,755,914,752,940,760,955,739,965,720,987,696,984,664,988,650,998,654,1008,640,1011,605,1002,580,993,558,971,542,933,520,916,520,890,501,864,497,845,480,833,472,808,433,804" shape="poly">
                    <area target="_blank" alt="کرمان" title="کرمان" href="mantagi.php?item=tree&time=day" coords="685,808,696,803,701,778,689,742,701,719,770,712,770,666,811,655,823,641,986,705,1013,746,1005,805,1011,818,1010,850,1008,858,1014,888,984,907,990,923,976,999,987,1041,951,1049,934,1023,916,1029,889,1019,881,962,858,943,857,923,846,920,828,936,797,925,795,879,782,877,762,888,752,877,729,868,725,843,692,835" shape="poly">
                    <area target="_blank" alt="هرمزگان" title="هرمزگان" href="mantagi.php?item=tree&time=day" coords="563,1000,582,989,648,1011,656,1006,654,996,703,984,725,988,732,966,761,956,752,941,756,914,734,891,735,874,760,888,781,879,796,879,796,919,825,936,846,920,856,923,856,942,881,956,887,1018,914,1026,932,1023,946,1043,985,1040,987,1097,1007,1115,1011,1137,989,1130,940,1132,922,1123,889,1115,866,1067,852,1021,826,1009,793,1009,774,1026,745,1043,710,1064,684,1055,656,1048,627,1047,620,1026,590,1021" shape="poly">
                    <area target="_blank" alt="قشم" title="قشم" href="mantagi.php?item=tree&time=day" coords="742,1070,742,1058,774,1047,770,1035,789,1036,805,1029,816,1031,804,1037,801,1049,790,1054,779,1052" shape="poly">
                </map>
        </div>
    </div>
    <!-- نقشه ایران -->
    <div class="container-fluid text-center mt-5 map-mobile">
        <h5>از روی نقشه انتخاب کنید</h5>
        <div style="background-image: url(img/dayere-posht-naghshe.png); width: 100px;height: 500px;">
                <img src="img/ir_map.png" usemap="#image-map" style="width: 400px;">
                <map name="image-map">
                    <area target="_blank" alt="خراسان شمالی" title="خراسان شمالی" href="mantagi.php?item=tree&time=day" coords="813,172,821,170,832,178,845,177,848,168,854,172,855,184,863,196,879,196,907,206,926,218,929,211,938,225,922,259,931,270,913,282,915,300,898,300,861,278,837,281,813,296,781,285,784,264,767,247,796,222,790,214,785,189,804,172" shape="poly">
                    <area target="_blank" alt="خراسان رضوی" title="خراسان رضوی" href="mantagi.php?item=tree&time=day" coords="931,213,979,224,989,244,1028,254,1043,285,1092,282,1095,302,1107,360,1097,393,1093,437,1078,440,1089,454,1067,473,1068,489,1048,497,1031,484,1011,488,995,478,951,481,939,464,908,461,884,434,893,420,862,408,820,431,796,438,827,406,840,391,854,373,825,340,825,317,827,303,815,299,840,278,863,282,905,305,915,299,909,285,932,270,920,259,938,232" shape="poly">
                    <area target="_blank" alt="خراسان جنوبی" title="خراسان جنوبی" href="mantagi.php?item=tree&time=day" coords="1067,490,1067,513,1097,519,1074,551,1096,625,1097,669,1117,676,1111,717,1117,751,1102,755,1089,736,1070,729,1014,748,991,706,827,638,811,623,804,600,763,573,740,538,746,520,749,469,774,469,793,441,857,407,893,419,885,435,902,458,938,461,952,482,992,477,1011,488,1031,483,1045,496" shape="poly">
                    <area target="_blank" alt="سیستان و بلوچستان" title="سیستان و بلوچستان" href="mantagi.php?item=tree&time=day" coords="1117,676,1160,679,1163,719,1110,795,1144,831,1167,875,1185,890,1224,901,1228,908,1242,908,1252,966,1250,981,1279,983,1289,989,1279,1025,1234,1037,1197,1066,1183,1147,1167,1153,1115,1142,1014,1139,1007,1115,984,1100,990,1045,979,1004,986,936,993,923,983,911,1016,888,1007,863,1013,852,1013,822,1004,811,1014,748,1070,732,1092,739,1101,751,1117,748,1109,718" shape="poly">
                    <area target="_blank" alt="گلستان" title="گلستان" href="mantagi.php?item=tree&time=day" coords="782,187,763,182,744,185,725,199,705,213,703,230,692,235,667,244,645,244,658,276,650,284,668,299,675,313,693,308,719,287,751,288,761,248,775,232,798,223,787,215" shape="poly">
                    <area target="_blank" alt="مازندران" title="مازندران" href="mantagi.php?item=tree&time=day" coords="673,308,667,297,650,289,635,283,627,278,582,290,532,300,504,297,479,289,448,270,440,272,431,285,464,317,481,323,497,334,520,340,534,355,549,360,567,346,582,358,588,348,604,358,631,354,654,325,657,314" shape="poly">
                    <area target="_blank" alt="گیلان" title="گیلان" href="mantagi.php?item=tree&time=day" coords="449,269,440,264,431,254,426,236,409,230,378,225,358,211,349,197,346,176,346,153,332,155,337,164,332,178,327,201,335,222,344,237,344,248,364,275,390,295,432,289,437,277" shape="poly">
                    <area target="_blank" alt="اردبیل" title="اردبیل" href="mantagi.php?item=tree&time=day" coords="341,244,339,231,325,199,334,164,321,141,301,124,303,111,319,108,305,88,320,79,301,55,291,54,241,84,246,109,264,97,267,112,260,121,267,131,254,154,269,166,281,162,285,190,296,193,293,218,304,231,307,243,316,247,332,254" shape="poly">
                    <area target="_blank" alt="آذربایجان شرقی" title="آذربایجان شرقی" href="mantagi.php?item=tree&time=day" coords="238,84,227,93,211,112,187,112,150,100,140,107,140,120,123,143,129,160,127,187,134,201,137,220,157,235,187,256,197,250,207,246,219,261,216,273,238,276,257,252,279,247,298,252,308,247,302,232,298,196,285,189,279,162,269,166,255,154,266,130,257,124,268,114,263,97,244,106" shape="poly">
                    <area target="_blank" alt="آذربایجان غربی" title="آذربایجان غربی" href="mantagi.php?item=tree&time=day" coords="145,95,139,80,128,73,119,57,100,35,87,46,86,59,63,54,69,73,75,123,80,142,66,169,84,189,84,207,96,224,93,239,99,247,93,255,107,269,107,284,117,294,121,312,121,321,132,323,143,307,163,302,166,292,208,293,222,302,240,299,244,289,237,276,222,274,219,259,207,246,186,254,139,221,128,188,123,141,138,120" shape="poly">
                    <area target="_blank" alt="کردستان" title="کردستان" href="mantagi.php?item=tree&time=day" coords="239,305,244,291,267,300,281,314,278,341,288,350,272,356,278,377,291,397,270,407,250,396,229,408,223,419,199,423,184,389,167,382,160,363,162,353,181,341,156,343,134,326,138,307,160,303,168,291,204,291,223,300" shape="poly">
                    <area target="_blank" alt="زنجان" title="زنجان" href="mantagi.php?item=tree&time=day" coords="345,248,327,252,311,244,305,249,276,246,260,255,239,275,241,290,274,300,280,319,279,337,290,350,309,361,337,364,331,343,339,338,364,338,370,317,348,291,363,279,360,269" shape="poly">
                    <area target="_blank" alt="قزوین " title="قزوین " href="mantagi.php?item=tree&time=day" coords="369,306,352,297,350,285,362,275,378,287,399,293,435,290,469,314,438,313,448,326,443,340,425,350,421,361,408,366,392,372,378,376,362,376,346,369,340,361,332,349,340,337,356,342,369,335,373,323" shape="poly">
                    <area target="_blank" alt="همدان" title="همدان" href="mantagi.php?item=tree&time=day" coords="341,369,325,365,308,361,291,361,275,360,276,377,288,390,288,405,276,406,269,411,268,423,261,430,278,442,269,446,269,459,282,471,302,477,322,477,334,485,346,476,345,459,337,441,345,434,350,423,354,417,364,417,372,431,378,426,372,413,362,408,369,405,369,394,375,382,363,375" shape="poly">
                    <area target="_blank" alt="کرمانشاه " title="کرمانشاه " href="mantagi.php?item=tree&time=day" coords="266,406,247,397,235,405,221,419,202,422,182,384,168,387,149,400,134,420,119,449,127,461,114,477,132,504,139,476,161,476,180,485,194,494,229,488,243,467,255,459,268,449,278,441,260,428" shape="poly">
                    <area target="_blank" alt="ایلام" title="ایلام" href="mantagi.php?item=tree&time=day" coords="195,491,171,478,147,473,134,500,159,537,153,555,175,564,218,599,229,599,241,624,252,617,252,608,267,587,258,561,232,534,221,531,209,507,222,502,241,495,244,483" shape="poly">
                    <area target="_blank" alt="اراک" title="اراک" href="mantagi.php?item=tree&time=day" coords="449,419,462,377,449,367,421,364,377,373,363,406,378,424,373,434,362,422,348,428,338,438,345,467,337,488,338,506,355,506,363,495,374,497,377,510,392,516,403,523,461,502,468,485,457,477,444,478,432,467,415,471,407,447,413,428,437,420" shape="poly">
                    <area target="_blank" alt="فارسی" title="فارسی" href="mantagi.php?item=tree&time=day" coords="769,241,754,266,754,284,713,287,696,308,673,309,656,314,654,334,628,356,604,360,605,375,596,389,573,395,533,382,525,382,534,403,523,422,521,447,544,459,560,457,585,471,746,469,775,467,852,373,826,343,827,302,811,295,785,287,782,260" shape="poly">
                    <area target="_blank" alt="تهران" title="تهران" href="mantagi.php?item=tree&time=day" coords="601,372,603,356,587,349,583,357,568,347,550,359,528,355,525,342,498,336,492,342,483,353,462,355,451,366,462,377,457,396,467,400,524,421,533,407,525,384,532,376,546,387,573,394,597,388" shape="poly">
                    <area target="_blank" alt="البرز" title="البرز" href="mantagi.php?item=tree&time=day" coords="492,334,481,324,464,317,445,314,443,320,446,331,440,344,428,350,422,356,429,365,454,369,461,355,481,354,488,342" shape="poly">
                    <area target="_blank" alt="قم" title="قم" href="mantagi.php?item=tree&time=day" coords="523,419,460,397,449,417,415,430,410,447,416,469,431,466,445,478,468,473,473,458,522,448,525,431" shape="poly">
                    <area target="_blank" alt="اصفهان" title="اصفهان" href="mantagi.php?item=tree&time=day" coords="748,471,584,473,564,456,542,462,521,454,472,460,467,477,472,486,402,523,398,548,368,576,382,586,384,597,407,592,420,602,452,594,464,623,480,641,474,667,481,701,474,711,505,733,517,694,508,683,534,668,544,682,584,674,587,611,609,596,645,600,707,576,726,542,742,539,746,521" shape="poly">
                    <area target="_blank" alt="لرستان" title="لرستان" href="mantagi.php?item=tree&time=day" coords="369,572,374,566,385,554,405,531,382,514,376,495,364,496,351,507,337,502,335,485,316,479,293,477,262,452,247,464,233,479,245,484,240,493,211,506,222,531,235,532,257,561,264,584,284,558,298,560,315,557,327,564,339,564,350,576,358,577" shape="poly">
                    <area target="_blank" alt="خوزستان" title="خوزستان" href="mantagi.php?item=tree&time=day" coords="243,624,254,614,252,602,280,557,302,559,313,557,340,563,364,577,384,589,390,625,410,653,419,669,413,681,392,695,394,714,404,724,420,742,415,759,419,777,398,771,388,779,362,795,354,783,337,781,329,771,325,787,309,788,290,788,280,766,266,752,269,714,245,708,251,678,257,654" shape="poly">
                    <area target="_blank" alt="چهارمحال بختیاری" title="چهارمحال بختیاری" href="mantagi.php?item=tree&time=day" coords="404,638,390,623,382,601,408,591,415,596,448,593,468,611,479,638,479,667,481,693,475,706,457,712,438,693,413,678,420,667" shape="poly">
                    <area target="_blank" alt="یزد" title="یزد" href="mantagi.php?item=tree&time=day" coords="582,670,582,652,588,638,584,610,607,598,643,599,711,575,723,540,739,538,757,569,802,600,811,623,827,638,810,657,770,673,769,712,704,722,684,739,696,770,698,792,697,804,681,805,656,795,658,775,640,748,608,685" shape="poly">
                    <area target="_blank" alt="کهکیوره و بویر احمد" title="کهکیوره و بویر احمد" href="mantagi.php?item=tree&time=day" coords="502,731,501,743,488,751,464,742,468,763,464,775,448,779,433,781,421,777,414,760,417,739,402,730,391,698,413,682,432,688,452,710,474,701" shape="poly">
                    <area target="_blank" alt="بوشهر" title="بوشهر" href="mantagi.php?item=tree&time=day" coords="391,778,397,770,426,776,439,805,469,810,478,832,495,841,502,864,521,894,524,917,541,933,555,970,579,993,563,1000,556,982,543,976,521,963,501,962,477,948,460,913,460,899,448,888,448,863,433,835,402,800" shape="poly">
                    <area target="_blank" alt="فارس" title="فارس" href="mantagi.php?item=tree&time=day" coords="431,779,469,770,466,745,501,754,515,687,534,669,544,678,591,677,613,695,655,770,655,790,680,804,698,835,723,842,733,878,734,893,755,914,752,940,760,955,739,965,720,987,696,984,664,988,650,998,654,1008,640,1011,605,1002,580,993,558,971,542,933,520,916,520,890,501,864,497,845,480,833,472,808,433,804" shape="poly">
                    <area target="_blank" alt="کرمان" title="کرمان" href="mantagi.php?item=tree&time=day" coords="685,808,696,803,701,778,689,742,701,719,770,712,770,666,811,655,823,641,986,705,1013,746,1005,805,1011,818,1010,850,1008,858,1014,888,984,907,990,923,976,999,987,1041,951,1049,934,1023,916,1029,889,1019,881,962,858,943,857,923,846,920,828,936,797,925,795,879,782,877,762,888,752,877,729,868,725,843,692,835" shape="poly">
                    <area target="_blank" alt="هرمزگان" title="هرمزگان" href="mantagi.php?item=tree&time=day" coords="563,1000,582,989,648,1011,656,1006,654,996,703,984,725,988,732,966,761,956,752,941,756,914,734,891,735,874,760,888,781,879,796,879,796,919,825,936,846,920,856,923,856,942,881,956,887,1018,914,1026,932,1023,946,1043,985,1040,987,1097,1007,1115,1011,1137,989,1130,940,1132,922,1123,889,1115,866,1067,852,1021,826,1009,793,1009,774,1026,745,1043,710,1064,684,1055,656,1048,627,1047,620,1026,590,1021" shape="poly">
                    <area target="_blank" alt="قشم" title="قشم" href="mantagi.php?item=tree&time=day" coords="742,1070,742,1058,774,1047,770,1035,789,1036,805,1029,816,1031,804,1037,801,1049,790,1054,779,1052" shape="poly">
                </map>
        </div>
    </div> 

    <!-- فوتر -->
    <!-- رنگ سبز -->
    <div class="container-fluid pb-5" style="margin-top: 100px; background-color: #347928;color: #fff;">
        <div class="container text-center">
            <div class="row">
                <div class="col-md-3 text-right pr-4 pt-5">
                    <h3><b>ارتباط با ما</b></h3>
                    <a href="darbaremaa.php"><h5 style="margin-top: 40px;">درباره ما</h5></a>
                    <a href="hamkare.php"><h5 style="margin-top: 40px;">همکاری باما</h5></a>
                    <a href="veblak.php"><h5 style="margin-top: 40px;">وبلاگ</h5></a>
                </div>
                <div class="col-md-3 text-right pr-4 pt-5">
                    <h3><b>مجوز های قانونی</b></h3>
                    <h5 style="margin-top: 40px;">مجوز اقامت</h5>
                    <h5 style="margin-top: 40px;">مجوز کمپینگ</h5>
                    <h5 style="margin-top: 40px;">مجوز افراد</h5>
                </div>            
                <div class="col-md-6 pt-5 text-right">
                    <h3><b>فضای مجازی</b></h3>
                    <div class="row">
                        <div class="col-md-6  pr-5">
                            <img src="img/telk.webp" width="60px" alt="">
                            <img src="img/Instagram-Logo.png" width="80px" alt="">
                            <img src="img/bale_200_200_c1.png" width="60px" alt="">
                        </div>
                        <div class="col-md-6">
                            <img src="img/i namad a.png" width="123px" alt="">
                            <img src="img/i namad ta.png" width="123px" alt="">
                        </div>
                        <h6 class="mb-2 pb-2 mt-4" style="border-bottom: 2px #ffc107 solid;">ثبت نام درخبرنامه</h6>
                        <p>برای اطلاع از تخفیف کمپینگ پست الکتریکی خود را در باکس زیر وارد کنید</p>
                        <input type="text" class="inp-et" style="width: 400px;height: 45px;border-radius: 15px;padding: 10px;" placeholder="آدرس ایمیل">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- درخت شب -->
<div id="tree-night" class="content-section">

    <!-- مرحله ها -->
    <div class="container-fluid">
        <div class="row mt-4">
            <div class="col-md-1"></div>
            <!-- لیست اول (تصاویر) -->
            <ul class="col-11 col-md-10 nav navbar pb-0 d-flex justify-content-center flex-wrap mr-2">
                <li><img src="img/1.png" width="45px" class="navbar-brand" alt=""></li>
                <li><img src="img/titi.png" width="300px" class="navbar-brand" height="25px" alt=""></li>
                <li><img src="img/2.2.png" width="45px" class="navbar-brand" alt=""></li>
                <li><img src="img/titi.png" width="300px" class="navbar-brand" height="25px" alt=""></li>
                <li><img src="img/3.2.png" width="45px" class="navbar-brand" alt=""></li>
                <li><img src="img/titi.png" width="300px" class="navbar-brand" height="25px" alt=""></li>
                <li><img src="img/4.2.png" width="45px" class="navbar-brand" alt=""></li>
            </ul>
            
            <!-- لیست دوم (متن‌ها) -->
            <div class="col-md-3 pr-5 text-center text-light">
                <h6>انتخاب محل کمپ</h6>
            </div>
            <div class="col-md-3 text-center pr-5 text-light">
                <h6>انتخاب منطقه</h6>
            </div>
            <div class="col-md-3 text-center pr-5 text-light">
                <h6>اجاره ابزارآلات</h6>
            </div>
            <div class="col-md-3 text-center pr-5 text-light">
                <h6>پرداخت</h6>
            </div>
        </div>
    </div>
    
    <!-- جستوجو -->
    <div class="container mt-5">
        <div class="row">
            <div class="col-sm-10 col-md-12 text-center">
                <input id="search-2" type="text" class="in-serg" placeholder="اسم منطقه کمپ، شهر، روستا، جنگل، کویر و ..." style="width: 100%;">
            </div>
        </div>
    </div>


    <!-- پربازدید ها -->
    <div class="container-fluid text-center p-5">
        <div class="row text-right cor-1">
            <h5>برترین های جنگل</h5>
        </div>
        <div class="row mt-4">

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1 text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/pictures-template-2(17).jpg" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۴.۶</p>
                        <div class="col-md-12 m-0 p-0"><h6>جنگل المیستان ، <small style="font-size: 11px;color: #c6c6c6;">استان مازندران - بابل</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=tree&time=night">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1 text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/53b9c6469c5b76c007b96ff6.jpg" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۵.۰</p>
                        <div class="col-md-12 m-0 p-0"><h6>جنگل ابر، <small style="font-size: 11px;color: #c6c6c6;">شاهرود</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=tree&time=night">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1 text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/ییلاق-ماسال-1.webp" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۴.۲</p>
                        <div class="col-md-12 m-0 p-0"><h6>جنگل ییلاقات ماسال، <small style="font-size: 11px;color: #c6c6c6;">استان مازندران - گیلان</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=tree&time=night">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1 text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/جنگل-دالخانی.webp" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۴.۵</p>
                        <div class="col-md-12 m-0 p-0"><h6>جنگل دالخانی، <small style="font-size: 11px;color: #c6c6c6;">رامسر</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=tree&time=night">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>
            
        </div>

        <!-- برترین های کویر -->
        <div class="row text-right cor-1 mt-4">
            <h5>برترین های کویر</h5>
        </div>
        <div class="row mt-4">

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1 text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/The-Maranjab-Desert-ezgif.com-optiwebp.webp" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۴.۸</p>
                        <div class="col-md-12 m-0 p-0"><h6>کویر مرنجاب، <small style="font-size: 11px;color: #c6c6c6;">استان اصفهان</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=tree&time=night">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1 text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/loot-sh.jpg_34xzfheh.uqc.jpg" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۵.۰</p>
                        <div class="col-md-12 m-0 p-0"><h6>کویر لوت، <small style="font-size: 11px;color: #c6c6c6;">استان‌های کرمان</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=tree&time=night">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1 text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/Articlee14fe676-9263-4e65-920e-357d46501de9_mihmansho.jpg" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۵.۰</p>
                        <div class="col-md-12 m-0 p-0"><h6>کویر زردگاه، <small style="font-size: 11px;color: #c6c6c6;">استان خراسان جنوبی</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=tree&time=night">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1 text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/1195fa02-fae7-461b-944a-e76b9e1c789c.webp" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۴.۵</p>
                        <div class="col-md-12 m-0 p-0"><h6>کویر ریگ جن، <small style="font-size: 11px;color: #c6c6c6;">استان‌های سمنان</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=tree&time=night">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>
            
        </div>

        <!-- برترین های کوهستانی -->
        <div class="row text-right cor-1 mt-4">
            <h5>برترین های کوهستانی</h5>
        </div>
        <div class="row mt-4">

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1 text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/981012-Damavand-South-IMG_9861-2.jpg" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۴.۳</p>
                        <div class="col-md-12 m-0 p-0"><h6>کوه دماوند، <small style="font-size: 11px;color: #c6c6c6;">استان البرز</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=tree&time=night">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1 text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/رشته-کوه-زاگرس.jpg" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۴.۱</p>
                        <div class="col-md-12 m-0 p-0"><h6>رشته کوه زاگرس، <small style="font-size: 11px;color: #c6c6c6;">استان‌ کردستان</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=tree&time=night">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1 text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/114839.jpg" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۳.۲</p>
                        <div class="col-md-12 m-0 p-0"><h6>قله الوند، <small style="font-size: 11px;color: #c6c6c6;">استان همدان</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=tree&time=night">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1 text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/c2461595-3144-4b98-9116-d96359d4a7b1.webp" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۲.۹</p>
                        <div class="col-md-12 m-0 p-0"><h6>قلهٔ بینالود، <small style="font-size: 11px;color: #c6c6c6;">استان خراسان رضوی</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=tree&time=night">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>
            
        </div>

            <!-- پرطرفدار ترین -->
            <div class="row text-right cor-1 mt-4">
                <h5>پرطرفدار ترین</h5>
            </div>
            <div class="row mt-4">
        
                <div class="col-md-3 col-12 mb-2">
                    <div class="container-fluid codr-1 text-right" style="padding: 13px 30px;">
                        <div class="row">
                            <img src="img/چالوس-جاده-1.jpg" class="im-1" width="100%" height="190px" alt="">
                            <img src="img/star.gif" width="20px" height="20px" alt="">
                            <p style="font-size: 11px;" class="mt-1">۴.۶</p>
                            <div class="col-md-12 m-0 p-0"><h6>فین چالوس، <small style="font-size: 11px;color: #c6c6c6;">استان مازندران</small></h6></div>
                            <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=tree&time=night">جزئیات و رزرو</a></div>
                        </div>
                    </div>
                </div>
        
                <div class="col-md-3 col-12 mb-2">
                    <div class="container-fluid codr-1 text-right" style="padding: 13px 30px;">
                        <div class="row">
                            <img src="img/خارا.jpg" class="im-1" width="100%" height="190px" alt="">
                            <img src="img/star.gif" width="20px" height="20px" alt="">
                            <p style="font-size: 11px;" class="mt-1">۴.۶</p>
                            <div class="col-md-12 m-0 p-0"><h6>کویر خارا، <small style="font-size: 11px;color: #c6c6c6;">استان‌ اصفهان</small></h6></div>
                            <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=tree&time=night">جزئیات و رزرو</a></div>
                        </div>
                    </div>
                </div>
        
                <div class="col-md-3 col-12 mb-2">
                    <div class="container-fluid codr-1 text-right" style="padding: 13px 30px;">
                        <div class="row">
                            <img src="img/981012-Damavand-South-IMG_9861-2.jpg" class="im-1" width="100%" height="190px" alt="">
                            <img src="img/star.gif" width="20px" height="20px" alt="">
                            <p style="font-size: 11px;" class="mt-1">۴.۳</p>
                            <div class="col-md-12 m-0 p-0"><h6>کوه دماوند، <small style="font-size: 11px;color: #c6c6c6;">استان البرز</small></h6></div>
                            <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=tree&time=night">جزئیات و رزرو</a></div>
                        </div>
                    </div>
                </div>
        
                <div class="col-md-3 col-12 mb-2">
                    <div class="container-fluid codr-1 text-right" style="padding: 13px 30px;">
                        <div class="row">
                            <img src="img/WhatsApp_Image_2021-12-13_at_12.06.25.jpg " class="im-1" width="100%" height="190px" alt="">
                            <img src="img/star.gif" width="20px" height="20px" alt="">
                            <p style="font-size: 11px;" class="mt-1">۴.۶</p>
                            <div class="col-md-12 m-0 p-0"><h6>ساحل گیسوم ، <small style="font-size: 11px;color: #c6c6c6;">استان هرمزگان</small></h6></div>
                            <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=tree&time=night">جزئیات و رزرو</a></div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- بالاترین نمره -->
            <div class="row text-right cor-1 mt-4">
                <h5>بالاترین نمره</h5>
            </div>
            <div class="row mt-4">
        
                <div class="col-md-3 col-12 mb-2">
                    <div class="container-fluid codr-1 text-right" style="padding: 13px 30px;">
                        <div class="row">
                            <img src="img/53b9c6469c5b76c007b96ff6.jpg" class="im-1" width="100%" height="190px" alt="">
                            <img src="img/star.gif" width="20px" height="20px" alt="">
                            <p style="font-size: 11px;" class="mt-1">۵.۰</p>
                            <div class="col-md-12 m-0 p-0"><h6>جنگل ابر، <small style="font-size: 11px;color: #c6c6c6;">شاهرود</small></h6></div>
                            <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=tree&time=night">جزئیات و رزرو</a></div>
                        </div>
                    </div>
                </div>
        
                <div class="col-md-3 col-12 mb-2">
                    <div class="container-fluid codr-1 text-right" style="padding: 13px 30px;">
                        <div class="row">
                            <img src="img/Articlee14fe676-9263-4e65-920e-357d46501de9_mihmansho.jpg" class="im-1" width="100%" height="190px" alt="">
                            <img src="img/star.gif" width="20px" height="20px" alt="">
                            <p style="font-size: 11px;" class="mt-1">۵.۰</p>
                            <div class="col-md-12 m-0 p-0"><h6>کویر زردگاه، <small style="font-size: 11px;color: #c6c6c6;">استان خراسان جنوبی</small></h6></div>
                            <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=tree&time=night">جزئیات و رزرو</a></div>
                        </div>
                    </div>
                </div>
        
                <div class="col-md-3 col-12 mb-2">
                    <div class="container-fluid codr-1 text-right" style="padding: 13px 30px;">
                        <div class="row">
                            <img src="img/Google-Maps-11-1.jpg" class="im-1" width="100%" height="190px" alt="">
                            <img src="img/star.gif" width="20px" height="20px" alt="">
                            <p style="font-size: 11px;" class="mt-1">۵.۰</p>
                            <div class="col-md-12 m-0 p-0"><h6>جنگل راش سنگده، <small style="font-size: 11px;color: #c6c6c6;">استان مازندران</small></h6></div>
                            <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=tree&time=night">جزئیات و رزرو</a></div>
                        </div>
                    </div>
                </div>
        
                <div class="col-md-3 col-12 mb-2">
                    <div class="container-fluid codr-1 text-right" style="padding: 13px 30px;">
                        <div class="row">
                            <img src="img/hirkani-jungle.webp" class="im-1" width="100%" height="190px" alt="">
                            <img src="img/star.gif" width="20px" height="20px" alt="">
                            <p style="font-size: 11px;" class="mt-1">۵.۰</p>
                            <div class="col-md-12 m-0 p-0"><h6>جنگل سیاه بیشه، <small style="font-size: 11px;color: #c6c6c6;">استان مازندران</small></h6></div>
                            <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=tree&time=night">جزئیات و رزرو</a></div>
                        </div>
                    </div>
                </div>
            </div>
    </div>

    <!-- نقشه ایران -->
    <div class="container-fluid text-center mt-5 map-desktop">
        <h2>از روی نقشه انتخاب کنید</h2>
        <div style="background-image: url(img/dayere-posht-naghshe.png); width: 100%;height: 1460px;">
                <img src="img/ir_map.png" usemap="#image-map">
                <map name="image-map">
                    <area target="_blank" alt="خراسان شمالی" title="خراسان شمالی" href="ali.php" coords="813,172,821,170,832,178,845,177,848,168,854,172,855,184,863,196,879,196,907,206,926,218,929,211,938,225,922,259,931,270,913,282,915,300,898,300,861,278,837,281,813,296,781,285,784,264,767,247,796,222,790,214,785,189,804,172" shape="poly">
                    <area target="_blank" alt="خراسان رضوی" title="خراسان رضوی" href="ali.php" coords="931,213,979,224,989,244,1028,254,1043,285,1092,282,1095,302,1107,360,1097,393,1093,437,1078,440,1089,454,1067,473,1068,489,1048,497,1031,484,1011,488,995,478,951,481,939,464,908,461,884,434,893,420,862,408,820,431,796,438,827,406,840,391,854,373,825,340,825,317,827,303,815,299,840,278,863,282,905,305,915,299,909,285,932,270,920,259,938,232" shape="poly">
                    <area target="_blank" alt="خراسان جنوبی" title="خراسان جنوبی" href="ali.php" coords="1067,490,1067,513,1097,519,1074,551,1096,625,1097,669,1117,676,1111,717,1117,751,1102,755,1089,736,1070,729,1014,748,991,706,827,638,811,623,804,600,763,573,740,538,746,520,749,469,774,469,793,441,857,407,893,419,885,435,902,458,938,461,952,482,992,477,1011,488,1031,483,1045,496" shape="poly">
                    <area target="_blank" alt="سیستان و بلوچستان" title="سیستان و بلوچستان" href="ali.php" coords="1117,676,1160,679,1163,719,1110,795,1144,831,1167,875,1185,890,1224,901,1228,908,1242,908,1252,966,1250,981,1279,983,1289,989,1279,1025,1234,1037,1197,1066,1183,1147,1167,1153,1115,1142,1014,1139,1007,1115,984,1100,990,1045,979,1004,986,936,993,923,983,911,1016,888,1007,863,1013,852,1013,822,1004,811,1014,748,1070,732,1092,739,1101,751,1117,748,1109,718" shape="poly">
                    <area target="_blank" alt="گلستان" title="گلستان" href="ali.php" coords="782,187,763,182,744,185,725,199,705,213,703,230,692,235,667,244,645,244,658,276,650,284,668,299,675,313,693,308,719,287,751,288,761,248,775,232,798,223,787,215" shape="poly">
                    <area target="_blank" alt="مازندران" title="مازندران" href="ali.php" coords="673,308,667,297,650,289,635,283,627,278,582,290,532,300,504,297,479,289,448,270,440,272,431,285,464,317,481,323,497,334,520,340,534,355,549,360,567,346,582,358,588,348,604,358,631,354,654,325,657,314" shape="poly">
                    <area target="_blank" alt="گیلان" title="گیلان" href="ali.php" coords="449,269,440,264,431,254,426,236,409,230,378,225,358,211,349,197,346,176,346,153,332,155,337,164,332,178,327,201,335,222,344,237,344,248,364,275,390,295,432,289,437,277" shape="poly">
                    <area target="_blank" alt="اردبیل" title="اردبیل" href="ali.php" coords="341,244,339,231,325,199,334,164,321,141,301,124,303,111,319,108,305,88,320,79,301,55,291,54,241,84,246,109,264,97,267,112,260,121,267,131,254,154,269,166,281,162,285,190,296,193,293,218,304,231,307,243,316,247,332,254" shape="poly">
                    <area target="_blank" alt="آذربایجان شرقی" title="آذربایجان شرقی" href="ali.php" coords="238,84,227,93,211,112,187,112,150,100,140,107,140,120,123,143,129,160,127,187,134,201,137,220,157,235,187,256,197,250,207,246,219,261,216,273,238,276,257,252,279,247,298,252,308,247,302,232,298,196,285,189,279,162,269,166,255,154,266,130,257,124,268,114,263,97,244,106" shape="poly">
                    <area target="_blank" alt="آذربایجان غربی" title="آذربایجان غربی" href="ali.php" coords="145,95,139,80,128,73,119,57,100,35,87,46,86,59,63,54,69,73,75,123,80,142,66,169,84,189,84,207,96,224,93,239,99,247,93,255,107,269,107,284,117,294,121,312,121,321,132,323,143,307,163,302,166,292,208,293,222,302,240,299,244,289,237,276,222,274,219,259,207,246,186,254,139,221,128,188,123,141,138,120" shape="poly">
                    <area target="_blank" alt="کردستان" title="کردستان" href="ali.php" coords="239,305,244,291,267,300,281,314,278,341,288,350,272,356,278,377,291,397,270,407,250,396,229,408,223,419,199,423,184,389,167,382,160,363,162,353,181,341,156,343,134,326,138,307,160,303,168,291,204,291,223,300" shape="poly">
                    <area target="_blank" alt="زنجان" title="زنجان" href="ali.php" coords="345,248,327,252,311,244,305,249,276,246,260,255,239,275,241,290,274,300,280,319,279,337,290,350,309,361,337,364,331,343,339,338,364,338,370,317,348,291,363,279,360,269" shape="poly">
                    <area target="_blank" alt="قزوین " title="قزوین " href="ali.php" coords="369,306,352,297,350,285,362,275,378,287,399,293,435,290,469,314,438,313,448,326,443,340,425,350,421,361,408,366,392,372,378,376,362,376,346,369,340,361,332,349,340,337,356,342,369,335,373,323" shape="poly">
                    <area target="_blank" alt="همدان" title="همدان" href="ali.php" coords="341,369,325,365,308,361,291,361,275,360,276,377,288,390,288,405,276,406,269,411,268,423,261,430,278,442,269,446,269,459,282,471,302,477,322,477,334,485,346,476,345,459,337,441,345,434,350,423,354,417,364,417,372,431,378,426,372,413,362,408,369,405,369,394,375,382,363,375" shape="poly">
                    <area target="_blank" alt="کرمانشاه " title="کرمانشاه " href="ali.php" coords="266,406,247,397,235,405,221,419,202,422,182,384,168,387,149,400,134,420,119,449,127,461,114,477,132,504,139,476,161,476,180,485,194,494,229,488,243,467,255,459,268,449,278,441,260,428" shape="poly">
                    <area target="_blank" alt="ایلام" title="ایلام" href="ali.php" coords="195,491,171,478,147,473,134,500,159,537,153,555,175,564,218,599,229,599,241,624,252,617,252,608,267,587,258,561,232,534,221,531,209,507,222,502,241,495,244,483" shape="poly">
                    <area target="_blank" alt="اراک" title="اراک" href="ali.php" coords="449,419,462,377,449,367,421,364,377,373,363,406,378,424,373,434,362,422,348,428,338,438,345,467,337,488,338,506,355,506,363,495,374,497,377,510,392,516,403,523,461,502,468,485,457,477,444,478,432,467,415,471,407,447,413,428,437,420" shape="poly">
                    <area target="_blank" alt="فارسی" title="فارسی" href="ali.php" coords="769,241,754,266,754,284,713,287,696,308,673,309,656,314,654,334,628,356,604,360,605,375,596,389,573,395,533,382,525,382,534,403,523,422,521,447,544,459,560,457,585,471,746,469,775,467,852,373,826,343,827,302,811,295,785,287,782,260" shape="poly">
                    <area target="_blank" alt="تهران" title="تهران" href="ali.php" coords="601,372,603,356,587,349,583,357,568,347,550,359,528,355,525,342,498,336,492,342,483,353,462,355,451,366,462,377,457,396,467,400,524,421,533,407,525,384,532,376,546,387,573,394,597,388" shape="poly">
                    <area target="_blank" alt="البرز" title="البرز" href="ali.php" coords="492,334,481,324,464,317,445,314,443,320,446,331,440,344,428,350,422,356,429,365,454,369,461,355,481,354,488,342" shape="poly">
                    <area target="_blank" alt="قم" title="قم" href="ali.php" coords="523,419,460,397,449,417,415,430,410,447,416,469,431,466,445,478,468,473,473,458,522,448,525,431" shape="poly">
                    <area target="_blank" alt="اصفهان" title="اصفهان" href="ali.php" coords="748,471,584,473,564,456,542,462,521,454,472,460,467,477,472,486,402,523,398,548,368,576,382,586,384,597,407,592,420,602,452,594,464,623,480,641,474,667,481,701,474,711,505,733,517,694,508,683,534,668,544,682,584,674,587,611,609,596,645,600,707,576,726,542,742,539,746,521" shape="poly">
                    <area target="_blank" alt="لرستان" title="لرستان" href="ali.php" coords="369,572,374,566,385,554,405,531,382,514,376,495,364,496,351,507,337,502,335,485,316,479,293,477,262,452,247,464,233,479,245,484,240,493,211,506,222,531,235,532,257,561,264,584,284,558,298,560,315,557,327,564,339,564,350,576,358,577" shape="poly">
                    <area target="_blank" alt="خوزستان" title="خوزستان" href="ali.php" coords="243,624,254,614,252,602,280,557,302,559,313,557,340,563,364,577,384,589,390,625,410,653,419,669,413,681,392,695,394,714,404,724,420,742,415,759,419,777,398,771,388,779,362,795,354,783,337,781,329,771,325,787,309,788,290,788,280,766,266,752,269,714,245,708,251,678,257,654" shape="poly">
                    <area target="_blank" alt="چهارمحال بختیاری" title="چهارمحال بختیاری" href="ali.php" coords="404,638,390,623,382,601,408,591,415,596,448,593,468,611,479,638,479,667,481,693,475,706,457,712,438,693,413,678,420,667" shape="poly">
                    <area target="_blank" alt="یزد" title="یزد" href="ali.php" coords="582,670,582,652,588,638,584,610,607,598,643,599,711,575,723,540,739,538,757,569,802,600,811,623,827,638,810,657,770,673,769,712,704,722,684,739,696,770,698,792,697,804,681,805,656,795,658,775,640,748,608,685" shape="poly">
                    <area target="_blank" alt="کهکیوره و بویر احمد" title="کهکیوره و بویر احمد" href="ali.php" coords="502,731,501,743,488,751,464,742,468,763,464,775,448,779,433,781,421,777,414,760,417,739,402,730,391,698,413,682,432,688,452,710,474,701" shape="poly">
                    <area target="_blank" alt="بوشهر" title="بوشهر" href="ali.php" coords="391,778,397,770,426,776,439,805,469,810,478,832,495,841,502,864,521,894,524,917,541,933,555,970,579,993,563,1000,556,982,543,976,521,963,501,962,477,948,460,913,460,899,448,888,448,863,433,835,402,800" shape="poly">
                    <area target="_blank" alt="فارس" title="فارس" href="ali.php" coords="431,779,469,770,466,745,501,754,515,687,534,669,544,678,591,677,613,695,655,770,655,790,680,804,698,835,723,842,733,878,734,893,755,914,752,940,760,955,739,965,720,987,696,984,664,988,650,998,654,1008,640,1011,605,1002,580,993,558,971,542,933,520,916,520,890,501,864,497,845,480,833,472,808,433,804" shape="poly">
                    <area target="_blank" alt="کرمان" title="کرمان" href="ali.php" coords="685,808,696,803,701,778,689,742,701,719,770,712,770,666,811,655,823,641,986,705,1013,746,1005,805,1011,818,1010,850,1008,858,1014,888,984,907,990,923,976,999,987,1041,951,1049,934,1023,916,1029,889,1019,881,962,858,943,857,923,846,920,828,936,797,925,795,879,782,877,762,888,752,877,729,868,725,843,692,835" shape="poly">
                    <area target="_blank" alt="هرمزگان" title="هرمزگان" href="ali.php" coords="563,1000,582,989,648,1011,656,1006,654,996,703,984,725,988,732,966,761,956,752,941,756,914,734,891,735,874,760,888,781,879,796,879,796,919,825,936,846,920,856,923,856,942,881,956,887,1018,914,1026,932,1023,946,1043,985,1040,987,1097,1007,1115,1011,1137,989,1130,940,1132,922,1123,889,1115,866,1067,852,1021,826,1009,793,1009,774,1026,745,1043,710,1064,684,1055,656,1048,627,1047,620,1026,590,1021" shape="poly">
                    <area target="_blank" alt="قشم" title="قشم" href="ali.php" coords="742,1070,742,1058,774,1047,770,1035,789,1036,805,1029,816,1031,804,1037,801,1049,790,1054,779,1052" shape="poly">
                </map>
        </div>
    </div>
    <!-- نقشه ایران -->
    <div class="container-fluid text-center mt-5 map-mobile">
        <h5>از روی نقشه انتخاب کنید</h5>
        <div style="background-image: url(img/dayere-posht-naghshe.png); width: 100px;height: 500px;">
                <img src="img/ir_map.png" usemap="#image-map" style="width: 400px;">
                <map name="image-map">
                    <area target="_blank" alt="خراسان شمالی" title="خراسان شمالی" href="ali.php" coords="813,172,821,170,832,178,845,177,848,168,854,172,855,184,863,196,879,196,907,206,926,218,929,211,938,225,922,259,931,270,913,282,915,300,898,300,861,278,837,281,813,296,781,285,784,264,767,247,796,222,790,214,785,189,804,172" shape="poly">
                    <area target="_blank" alt="خراسان رضوی" title="خراسان رضوی" href="ali.php" coords="931,213,979,224,989,244,1028,254,1043,285,1092,282,1095,302,1107,360,1097,393,1093,437,1078,440,1089,454,1067,473,1068,489,1048,497,1031,484,1011,488,995,478,951,481,939,464,908,461,884,434,893,420,862,408,820,431,796,438,827,406,840,391,854,373,825,340,825,317,827,303,815,299,840,278,863,282,905,305,915,299,909,285,932,270,920,259,938,232" shape="poly">
                    <area target="_blank" alt="خراسان جنوبی" title="خراسان جنوبی" href="ali.php" coords="1067,490,1067,513,1097,519,1074,551,1096,625,1097,669,1117,676,1111,717,1117,751,1102,755,1089,736,1070,729,1014,748,991,706,827,638,811,623,804,600,763,573,740,538,746,520,749,469,774,469,793,441,857,407,893,419,885,435,902,458,938,461,952,482,992,477,1011,488,1031,483,1045,496" shape="poly">
                    <area target="_blank" alt="سیستان و بلوچستان" title="سیستان و بلوچستان" href="ali.php" coords="1117,676,1160,679,1163,719,1110,795,1144,831,1167,875,1185,890,1224,901,1228,908,1242,908,1252,966,1250,981,1279,983,1289,989,1279,1025,1234,1037,1197,1066,1183,1147,1167,1153,1115,1142,1014,1139,1007,1115,984,1100,990,1045,979,1004,986,936,993,923,983,911,1016,888,1007,863,1013,852,1013,822,1004,811,1014,748,1070,732,1092,739,1101,751,1117,748,1109,718" shape="poly">
                    <area target="_blank" alt="گلستان" title="گلستان" href="ali.php" coords="782,187,763,182,744,185,725,199,705,213,703,230,692,235,667,244,645,244,658,276,650,284,668,299,675,313,693,308,719,287,751,288,761,248,775,232,798,223,787,215" shape="poly">
                    <area target="_blank" alt="مازندران" title="مازندران" href="ali.php" coords="673,308,667,297,650,289,635,283,627,278,582,290,532,300,504,297,479,289,448,270,440,272,431,285,464,317,481,323,497,334,520,340,534,355,549,360,567,346,582,358,588,348,604,358,631,354,654,325,657,314" shape="poly">
                    <area target="_blank" alt="گیلان" title="گیلان" href="ali.php" coords="449,269,440,264,431,254,426,236,409,230,378,225,358,211,349,197,346,176,346,153,332,155,337,164,332,178,327,201,335,222,344,237,344,248,364,275,390,295,432,289,437,277" shape="poly">
                    <area target="_blank" alt="اردبیل" title="اردبیل" href="ali.php" coords="341,244,339,231,325,199,334,164,321,141,301,124,303,111,319,108,305,88,320,79,301,55,291,54,241,84,246,109,264,97,267,112,260,121,267,131,254,154,269,166,281,162,285,190,296,193,293,218,304,231,307,243,316,247,332,254" shape="poly">
                    <area target="_blank" alt="آذربایجان شرقی" title="آذربایجان شرقی" href="ali.php" coords="238,84,227,93,211,112,187,112,150,100,140,107,140,120,123,143,129,160,127,187,134,201,137,220,157,235,187,256,197,250,207,246,219,261,216,273,238,276,257,252,279,247,298,252,308,247,302,232,298,196,285,189,279,162,269,166,255,154,266,130,257,124,268,114,263,97,244,106" shape="poly">
                    <area target="_blank" alt="آذربایجان غربی" title="آذربایجان غربی" href="ali.php" coords="145,95,139,80,128,73,119,57,100,35,87,46,86,59,63,54,69,73,75,123,80,142,66,169,84,189,84,207,96,224,93,239,99,247,93,255,107,269,107,284,117,294,121,312,121,321,132,323,143,307,163,302,166,292,208,293,222,302,240,299,244,289,237,276,222,274,219,259,207,246,186,254,139,221,128,188,123,141,138,120" shape="poly">
                    <area target="_blank" alt="کردستان" title="کردستان" href="ali.php" coords="239,305,244,291,267,300,281,314,278,341,288,350,272,356,278,377,291,397,270,407,250,396,229,408,223,419,199,423,184,389,167,382,160,363,162,353,181,341,156,343,134,326,138,307,160,303,168,291,204,291,223,300" shape="poly">
                    <area target="_blank" alt="زنجان" title="زنجان" href="ali.php" coords="345,248,327,252,311,244,305,249,276,246,260,255,239,275,241,290,274,300,280,319,279,337,290,350,309,361,337,364,331,343,339,338,364,338,370,317,348,291,363,279,360,269" shape="poly">
                    <area target="_blank" alt="قزوین " title="قزوین " href="ali.php" coords="369,306,352,297,350,285,362,275,378,287,399,293,435,290,469,314,438,313,448,326,443,340,425,350,421,361,408,366,392,372,378,376,362,376,346,369,340,361,332,349,340,337,356,342,369,335,373,323" shape="poly">
                    <area target="_blank" alt="همدان" title="همدان" href="ali.php" coords="341,369,325,365,308,361,291,361,275,360,276,377,288,390,288,405,276,406,269,411,268,423,261,430,278,442,269,446,269,459,282,471,302,477,322,477,334,485,346,476,345,459,337,441,345,434,350,423,354,417,364,417,372,431,378,426,372,413,362,408,369,405,369,394,375,382,363,375" shape="poly">
                    <area target="_blank" alt="کرمانشاه " title="کرمانشاه " href="ali.php" coords="266,406,247,397,235,405,221,419,202,422,182,384,168,387,149,400,134,420,119,449,127,461,114,477,132,504,139,476,161,476,180,485,194,494,229,488,243,467,255,459,268,449,278,441,260,428" shape="poly">
                    <area target="_blank" alt="ایلام" title="ایلام" href="ali.php" coords="195,491,171,478,147,473,134,500,159,537,153,555,175,564,218,599,229,599,241,624,252,617,252,608,267,587,258,561,232,534,221,531,209,507,222,502,241,495,244,483" shape="poly">
                    <area target="_blank" alt="اراک" title="اراک" href="ali.php" coords="449,419,462,377,449,367,421,364,377,373,363,406,378,424,373,434,362,422,348,428,338,438,345,467,337,488,338,506,355,506,363,495,374,497,377,510,392,516,403,523,461,502,468,485,457,477,444,478,432,467,415,471,407,447,413,428,437,420" shape="poly">
                    <area target="_blank" alt="فارسی" title="فارسی" href="ali.php" coords="769,241,754,266,754,284,713,287,696,308,673,309,656,314,654,334,628,356,604,360,605,375,596,389,573,395,533,382,525,382,534,403,523,422,521,447,544,459,560,457,585,471,746,469,775,467,852,373,826,343,827,302,811,295,785,287,782,260" shape="poly">
                    <area target="_blank" alt="تهران" title="تهران" href="ali.php" coords="601,372,603,356,587,349,583,357,568,347,550,359,528,355,525,342,498,336,492,342,483,353,462,355,451,366,462,377,457,396,467,400,524,421,533,407,525,384,532,376,546,387,573,394,597,388" shape="poly">
                    <area target="_blank" alt="البرز" title="البرز" href="ali.php" coords="492,334,481,324,464,317,445,314,443,320,446,331,440,344,428,350,422,356,429,365,454,369,461,355,481,354,488,342" shape="poly">
                    <area target="_blank" alt="قم" title="قم" href="ali.php" coords="523,419,460,397,449,417,415,430,410,447,416,469,431,466,445,478,468,473,473,458,522,448,525,431" shape="poly">
                    <area target="_blank" alt="اصفهان" title="اصفهان" href="ali.php" coords="748,471,584,473,564,456,542,462,521,454,472,460,467,477,472,486,402,523,398,548,368,576,382,586,384,597,407,592,420,602,452,594,464,623,480,641,474,667,481,701,474,711,505,733,517,694,508,683,534,668,544,682,584,674,587,611,609,596,645,600,707,576,726,542,742,539,746,521" shape="poly">
                    <area target="_blank" alt="لرستان" title="لرستان" href="ali.php" coords="369,572,374,566,385,554,405,531,382,514,376,495,364,496,351,507,337,502,335,485,316,479,293,477,262,452,247,464,233,479,245,484,240,493,211,506,222,531,235,532,257,561,264,584,284,558,298,560,315,557,327,564,339,564,350,576,358,577" shape="poly">
                    <area target="_blank" alt="خوزستان" title="خوزستان" href="ali.php" coords="243,624,254,614,252,602,280,557,302,559,313,557,340,563,364,577,384,589,390,625,410,653,419,669,413,681,392,695,394,714,404,724,420,742,415,759,419,777,398,771,388,779,362,795,354,783,337,781,329,771,325,787,309,788,290,788,280,766,266,752,269,714,245,708,251,678,257,654" shape="poly">
                    <area target="_blank" alt="چهارمحال بختیاری" title="چهارمحال بختیاری" href="ali.php" coords="404,638,390,623,382,601,408,591,415,596,448,593,468,611,479,638,479,667,481,693,475,706,457,712,438,693,413,678,420,667" shape="poly">
                    <area target="_blank" alt="یزد" title="یزد" href="ali.php" coords="582,670,582,652,588,638,584,610,607,598,643,599,711,575,723,540,739,538,757,569,802,600,811,623,827,638,810,657,770,673,769,712,704,722,684,739,696,770,698,792,697,804,681,805,656,795,658,775,640,748,608,685" shape="poly">
                    <area target="_blank" alt="کهکیوره و بویر احمد" title="کهکیوره و بویر احمد" href="ali.php" coords="502,731,501,743,488,751,464,742,468,763,464,775,448,779,433,781,421,777,414,760,417,739,402,730,391,698,413,682,432,688,452,710,474,701" shape="poly">
                    <area target="_blank" alt="بوشهر" title="بوشهر" href="ali.php" coords="391,778,397,770,426,776,439,805,469,810,478,832,495,841,502,864,521,894,524,917,541,933,555,970,579,993,563,1000,556,982,543,976,521,963,501,962,477,948,460,913,460,899,448,888,448,863,433,835,402,800" shape="poly">
                    <area target="_blank" alt="فارس" title="فارس" href="ali.php" coords="431,779,469,770,466,745,501,754,515,687,534,669,544,678,591,677,613,695,655,770,655,790,680,804,698,835,723,842,733,878,734,893,755,914,752,940,760,955,739,965,720,987,696,984,664,988,650,998,654,1008,640,1011,605,1002,580,993,558,971,542,933,520,916,520,890,501,864,497,845,480,833,472,808,433,804" shape="poly">
                    <area target="_blank" alt="کرمان" title="کرمان" href="ali.php" coords="685,808,696,803,701,778,689,742,701,719,770,712,770,666,811,655,823,641,986,705,1013,746,1005,805,1011,818,1010,850,1008,858,1014,888,984,907,990,923,976,999,987,1041,951,1049,934,1023,916,1029,889,1019,881,962,858,943,857,923,846,920,828,936,797,925,795,879,782,877,762,888,752,877,729,868,725,843,692,835" shape="poly">
                    <area target="_blank" alt="هرمزگان" title="هرمزگان" href="ali.php" coords="563,1000,582,989,648,1011,656,1006,654,996,703,984,725,988,732,966,761,956,752,941,756,914,734,891,735,874,760,888,781,879,796,879,796,919,825,936,846,920,856,923,856,942,881,956,887,1018,914,1026,932,1023,946,1043,985,1040,987,1097,1007,1115,1011,1137,989,1130,940,1132,922,1123,889,1115,866,1067,852,1021,826,1009,793,1009,774,1026,745,1043,710,1064,684,1055,656,1048,627,1047,620,1026,590,1021" shape="poly">
                    <area target="_blank" alt="قشم" title="قشم" href="ali.php" coords="742,1070,742,1058,774,1047,770,1035,789,1036,805,1029,816,1031,804,1037,801,1049,790,1054,779,1052" shape="poly">
                </map>
        </div>
    </div> 

    <!-- فوتر -->
    <!-- رنگ سبز -->
    <div class="container-fluid pb-5" style="margin-top: 100px; background-color: #347928;color: #fff;">
        <div class="container text-center">
            <div class="row">
                <div class="col-md-3 text-right pr-4 pt-5">
                    <h3><b>ارتباط با ما</b></h3>
                    <a href="darbaremaa.php"><h5 style="margin-top: 40px;">درباره ما</h5></a>
                    <a href="hamkare.php"><h5 style="margin-top: 40px;">همکاری باما</h5></a>
                    <a href="veblak.php"><h5 style="margin-top: 40px;">وبلاگ</h5></a>
                </div>
                <div class="col-md-3 text-right pr-4 pt-5">
                    <h3><b>مجوز های قانونی</b></h3>
                    <h5 style="margin-top: 40px;">مجوز اقامت</h5>
                    <h5 style="margin-top: 40px;">مجوز کمپینگ</h5>
                    <h5 style="margin-top: 40px;">مجوز افراد</h5>
                </div>            
                <div class="col-md-6 pt-5 text-right">
                    <h3><b>فضای مجازی</b></h3>
                    <div class="row">
                        <div class="col-md-6  pr-5">
                            <img src="img/telk.webp" width="60px" alt="">
                            <img src="img/Instagram-Logo.png" width="80px" alt="">
                            <img src="img/bale_200_200_c1.png" width="60px" alt="">
                        </div>
                        <div class="col-md-6">
                            <img src="img/i namad a.png" width="123px" alt="">
                            <img src="img/i namad ta.png" width="123px" alt="">
                        </div>
                        <h6 class="mb-2 pb-2 mt-4" style="border-bottom: 2px #ffc107 solid;">ثبت نام درخبرنامه</h6>
                        <p>برای اطلاع از تخفیف کمپینگ پست الکتریکی خود را در باکس زیر وارد کنید</p>
                        <input type="text" class="inp-et" style="width: 400px;height: 45px;border-radius: 15px;padding: 10px;" placeholder="آدرس ایمیل">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- کاکتوث روز -->
<div id="cactus-day" class="content-section">

        <!-- مرحله ها -->
        <div class="container-fluid">
            <div class="row mt-4">
                <div class="col-md-1"></div>
                <!-- لیست اول (تصاویر) -->
                <ul class="col-11 col-md-10 nav navbar pb-0 d-flex justify-content-center flex-wrap mr-2">
                    <li><img src="img/1R.png" width="45px" class="navbar-brand" alt=""></li>
                    <li><img src="img/titir.png" width="300px" class="navbar-brand" height="25px" alt=""></li>
                    <li><img src="img/2.2r.png" width="45px" class="navbar-brand" alt=""></li>
                    <li><img src="img/titir.png" width="300px" class="navbar-brand" height="25px" alt=""></li>
                    <li><img src="img/3.2r.png" width="45px" class="navbar-brand" alt=""></li>
                    <li><img src="img/titir.png" width="300px" class="navbar-brand" height="25px" alt=""></li>
                    <li><img src="img/4.2r.png" width="45px" class="navbar-brand" alt=""></li>
                </ul>
                
                <!-- لیست دوم (متن‌ها) -->
                <div class="col-md-3 pr-5 text-center">
                    <h6>انتخاب محل کمپ</h6>
                </div>
                <div class="col-md-3 text-center pr-5">
                    <h6>انتخاب منطقه</h6>
                </div>
                <div class="col-md-3 text-center pr-5">
                    <h6>اجاره ابزارآلات</h6>
                </div>
                <div class="col-md-3 text-center pr-5">
                    <h6>پرداخت</h6>
                </div>
            </div>
        </div>

        <!-- جستوجو -->
        <div class="container mt-5">
            <div class="row">
                <div class="col-sm-10 col-md-12 text-center">
                    <input id="search-3" type="text" class="in-serg-r" placeholder="اسم منطقه کمپ، شهر، روستا، جنگل، کویر و ..." style="width: 100%;">
                </div>
            </div>
        </div>

        <!-- پربازدید ها -->
        <div class="container-fluid text-center p-5">
            <div class="row text-right cor-1">
                <h5>برترین های جنگل</h5>
            </div>
            <div class="row mt-4">

                <div class="col-md-3 col-12 mb-2">
                    <div class="container-fluid codr-1-r text-right" style="padding: 13px 30px;">
                        <div class="row">
                            <img src="img/pictures-template-2(17).jpg" class="im-1" width="100%" height="190px" alt="">
                            <img src="img/star.gif" width="20px" height="20px" alt="">
                            <p style="font-size: 11px;" class="mt-1">۴.۶</p>
                            <div class="col-md-12 m-0 p-0"><h6>جنگل المیستان ، <small style="font-size: 11px;color: #c6c6c6;">استان مازندران - بابل</small></h6></div>
                            <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=cactus&time=day">جزئیات و رزرو</a></div>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 col-12 mb-2">
                    <div class="container-fluid codr-1-r text-right" style="padding: 13px 30px;">
                        <div class="row">
                            <img src="img/53b9c6469c5b76c007b96ff6.jpg" class="im-1" width="100%" height="190px" alt="">
                            <img src="img/star.gif" width="20px" height="20px" alt="">
                            <p style="font-size: 11px;" class="mt-1">۵.۰</p>
                            <div class="col-md-12 m-0 p-0"><h6>جنگل ابر، <small style="font-size: 11px;color: #c6c6c6;">شاهرود</small></h6></div>
                            <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=cactus&time=day">جزئیات و رزرو</a></div>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 col-12 mb-2">
                    <div class="container-fluid codr-1-r text-right" style="padding: 13px 30px;">
                        <div class="row">
                            <img src="img/ییلاق-ماسال-1.webp" class="im-1" width="100%" height="190px" alt="">
                            <img src="img/star.gif" width="20px" height="20px" alt="">
                            <p style="font-size: 11px;" class="mt-1">۴.۲</p>
                            <div class="col-md-12 m-0 p-0"><h6>جنگل ییلاقات ماسال، <small style="font-size: 11px;color: #c6c6c6;">استان مازندران - گیلان</small></h6></div>
                            <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=cactus&time=day">جزئیات و رزرو</a></div>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 col-12 mb-2">
                    <div class="container-fluid codr-1-r text-right" style="padding: 13px 30px;">
                        <div class="row">
                            <img src="img/جنگل-دالخانی.webp" class="im-1" width="100%" height="190px" alt="">
                            <img src="img/star.gif" width="20px" height="20px" alt="">
                            <p style="font-size: 11px;" class="mt-1">۴.۵</p>
                            <div class="col-md-12 m-0 p-0"><h6>جنگل دالخانی، <small style="font-size: 11px;color: #c6c6c6;">رامسر</small></h6></div>
                            <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=cactus&time=day">جزئیات و رزرو</a></div>
                        </div>
                    </div>
                </div>
                
            </div>

            <!-- برترین های کویر -->
            <div class="row text-right cor-1 mt-4">
                <h5>برترین های کویر</h5>
            </div>
            <div class="row mt-4">

                <div class="col-md-3 col-12 mb-2">
                    <div class="container-fluid codr-1-r text-right" style="padding: 13px 30px;">
                        <div class="row">
                            <img src="img/The-Maranjab-Desert-ezgif.com-optiwebp.webp" class="im-1" width="100%" height="190px" alt="">
                            <img src="img/star.gif" width="20px" height="20px" alt="">
                            <p style="font-size: 11px;" class="mt-1">۴.۸</p>
                            <div class="col-md-12 m-0 p-0"><h6>کویر مرنجاب، <small style="font-size: 11px;color: #c6c6c6;">استان اصفهان</small></h6></div>
                            <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=cactus&time=day">جزئیات و رزرو</a></div>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 col-12 mb-2">
                    <div class="container-fluid codr-1-r text-right" style="padding: 13px 30px;">
                        <div class="row">
                            <img src="img/loot-sh.jpg_34xzfheh.uqc.jpg" class="im-1" width="100%" height="190px" alt="">
                            <img src="img/star.gif" width="20px" height="20px" alt="">
                            <p style="font-size: 11px;" class="mt-1">۵.۰</p>
                            <div class="col-md-12 m-0 p-0"><h6>کویر لوت، <small style="font-size: 11px;color: #c6c6c6;">استان‌های کرمان</small></h6></div>
                            <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=cactus&time=day">جزئیات و رزرو</a></div>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 col-12 mb-2">
                    <div class="container-fluid codr-1-r text-right" style="padding: 13px 30px;">
                        <div class="row">
                            <img src="img/Articlee14fe676-9263-4e65-920e-357d46501de9_mihmansho.jpg" class="im-1" width="100%" height="190px" alt="">
                            <img src="img/star.gif" width="20px" height="20px" alt="">
                            <p style="font-size: 11px;" class="mt-1">۵.۰</p>
                            <div class="col-md-12 m-0 p-0"><h6>کویر زردگاه، <small style="font-size: 11px;color: #c6c6c6;">استان خراسان جنوبی</small></h6></div>
                            <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=cactus&time=day">جزئیات و رزرو</a></div>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 col-12 mb-2">
                    <div class="container-fluid codr-1-r text-right" style="padding: 13px 30px;">
                        <div class="row">
                            <img src="img/1195fa02-fae7-461b-944a-e76b9e1c789c.webp" class="im-1" width="100%" height="190px" alt="">
                            <img src="img/star.gif" width="20px" height="20px" alt="">
                            <p style="font-size: 11px;" class="mt-1">۴.۵</p>
                            <div class="col-md-12 m-0 p-0"><h6>کویر ریگ جن، <small style="font-size: 11px;color: #c6c6c6;">استان‌های سمنان</small></h6></div>
                            <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=cactus&time=day">جزئیات و رزرو</a></div>
                        </div>
                    </div>
                </div>
                
            </div>

            <!-- برترین های کوهستانی -->
            <div class="row text-right cor-1 mt-4">
                <h5>برترین های کوهستانی</h5>
            </div>
            <div class="row mt-4">

                <div class="col-md-3 col-12 mb-2">
                    <div class="container-fluid codr-1-r text-right" style="padding: 13px 30px;">
                        <div class="row">
                            <img src="img/981012-Damavand-South-IMG_9861-2.jpg" class="im-1" width="100%" height="190px" alt="">
                            <img src="img/star.gif" width="20px" height="20px" alt="">
                            <p style="font-size: 11px;" class="mt-1">۴.۳</p>
                            <div class="col-md-12 m-0 p-0"><h6>کوه دماوند، <small style="font-size: 11px;color: #c6c6c6;">استان البرز</small></h6></div>
                            <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=cactus&time=day">جزئیات و رزرو</a></div>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 col-12 mb-2">
                    <div class="container-fluid codr-1-r text-right" style="padding: 13px 30px;">
                        <div class="row">
                            <img src="img/رشته-کوه-زاگرس.jpg" class="im-1" width="100%" height="190px" alt="">
                            <img src="img/star.gif" width="20px" height="20px" alt="">
                            <p style="font-size: 11px;" class="mt-1">۴.۱</p>
                            <div class="col-md-12 m-0 p-0"><h6>رشته کوه زاگرس، <small style="font-size: 11px;color: #c6c6c6;">استان‌ کردستان</small></h6></div>
                            <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=cactus&time=day">جزئیات و رزرو</a></div>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 col-12 mb-2">
                    <div class="container-fluid codr-1-r text-right" style="padding: 13px 30px;">
                        <div class="row">
                            <img src="img/114839.jpg" class="im-1" width="100%" height="190px" alt="">
                            <img src="img/star.gif" width="20px" height="20px" alt="">
                            <p style="font-size: 11px;" class="mt-1">۳.۲</p>
                            <div class="col-md-12 m-0 p-0"><h6>قله الوند، <small style="font-size: 11px;color: #c6c6c6;">استان همدان</small></h6></div>
                            <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=cactus&time=day">جزئیات و رزرو</a></div>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 col-12 mb-2">
                    <div class="container-fluid codr-1-r text-right" style="padding: 13px 30px;">
                        <div class="row">
                            <img src="img/c2461595-3144-4b98-9116-d96359d4a7b1.webp" class="im-1" width="100%" height="190px" alt="">
                            <img src="img/star.gif" width="20px" height="20px" alt="">
                            <p style="font-size: 11px;" class="mt-1">۲.۹</p>
                            <div class="col-md-12 m-0 p-0"><h6>قلهٔ بینالود، <small style="font-size: 11px;color: #c6c6c6;">استان خراسان رضوی</small></h6></div>
                            <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=cactus&time=day">جزئیات و رزرو</a></div>
                        </div>
                    </div>
                </div>
                
            </div>

                <!-- پرطرفدار ترین -->
                <div class="row text-right cor-1 mt-4">
                    <h5>پرطرفدار ترین</h5>
                </div>
                <div class="row mt-4">
            
                    <div class="col-md-3 col-12 mb-2">
                        <div class="container-fluid codr-1-r text-right" style="padding: 13px 30px;">
                            <div class="row">
                                <img src="img/چالوس-جاده-1.jpg" class="im-1" width="100%" height="190px" alt="">
                                <img src="img/star.gif" width="20px" height="20px" alt="">
                                <p style="font-size: 11px;" class="mt-1">۴.۶</p>
                                <div class="col-md-12 m-0 p-0"><h6>فین چالوس، <small style="font-size: 11px;color: #c6c6c6;">استان مازندران</small></h6></div>
                                <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=cactus&time=day">جزئیات و رزرو</a></div>
                            </div>
                        </div>
                    </div>
            
                    <div class="col-md-3 col-12 mb-2">
                        <div class="container-fluid codr-1-r text-right" style="padding: 13px 30px;">
                            <div class="row">
                                <img src="img/خارا.jpg" class="im-1" width="100%" height="190px" alt="">
                                <img src="img/star.gif" width="20px" height="20px" alt="">
                                <p style="font-size: 11px;" class="mt-1">۴.۶</p>
                                <div class="col-md-12 m-0 p-0"><h6>کویر خارا، <small style="font-size: 11px;color: #c6c6c6;">استان‌ اصفهان</small></h6></div>
                                <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=cactus&time=day">جزئیات و رزرو</a></div>
                            </div>
                        </div>
                    </div>
            
                    <div class="col-md-3 col-12 mb-2">
                        <div class="container-fluid codr-1-r text-right" style="padding: 13px 30px;">
                            <div class="row">
                                <img src="img/981012-Damavand-South-IMG_9861-2.jpg" class="im-1" width="100%" height="190px" alt="">
                                <img src="img/star.gif" width="20px" height="20px" alt="">
                                <p style="font-size: 11px;" class="mt-1">۴.۳</p>
                                <div class="col-md-12 m-0 p-0"><h6>کوه دماوند، <small style="font-size: 11px;color: #c6c6c6;">استان البرز</small></h6></div>
                                <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=cactus&time=day">جزئیات و رزرو</a></div>
                            </div>
                        </div>
                    </div>
            
                    <div class="col-md-3 col-12 mb-2">
                        <div class="container-fluid codr-1-r text-right" style="padding: 13px 30px;">
                            <div class="row">
                                <img src="img/WhatsApp_Image_2021-12-13_at_12.06.25.jpg " class="im-1" width="100%" height="190px" alt="">
                                <img src="img/star.gif" width="20px" height="20px" alt="">
                                <p style="font-size: 11px;" class="mt-1">۴.۶</p>
                                <div class="col-md-12 m-0 p-0"><h6>ساحل گیسوم ، <small style="font-size: 11px;color: #c6c6c6;">استان هرمزگان</small></h6></div>
                                <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=cactus&time=day">جزئیات و رزرو</a></div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- بالاترین نمره -->
                <div class="row text-right cor-1 mt-4">
                    <h5>بالاترین نمره</h5>
                </div>
                <div class="row mt-4">
            
                    <div class="col-md-3 col-12 mb-2">
                        <div class="container-fluid codr-1-r text-right" style="padding: 13px 30px;">
                            <div class="row">
                                <img src="img/53b9c6469c5b76c007b96ff6.jpg" class="im-1" width="100%" height="190px" alt="">
                                <img src="img/star.gif" width="20px" height="20px" alt="">
                                <p style="font-size: 11px;" class="mt-1">۵.۰</p>
                                <div class="col-md-12 m-0 p-0"><h6>جنگل ابر، <small style="font-size: 11px;color: #c6c6c6;">شاهرود</small></h6></div>
                                <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=cactus&time=day">جزئیات و رزرو</a></div>
                            </div>
                        </div>
                    </div>
            
                    <div class="col-md-3 col-12 mb-2">
                        <div class="container-fluid codr-1-r text-right" style="padding: 13px 30px;">
                            <div class="row">
                                <img src="img/Articlee14fe676-9263-4e65-920e-357d46501de9_mihmansho.jpg" class="im-1" width="100%" height="190px" alt="">
                                <img src="img/star.gif" width="20px" height="20px" alt="">
                                <p style="font-size: 11px;" class="mt-1">۵.۰</p>
                                <div class="col-md-12 m-0 p-0"><h6>کویر زردگاه، <small style="font-size: 11px;color: #c6c6c6;">استان خراسان جنوبی</small></h6></div>
                                <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=cactus&time=day">جزئیات و رزرو</a></div>
                            </div>
                        </div>
                    </div>
            
                    <div class="col-md-3 col-12 mb-2">
                        <div class="container-fluid codr-1-r text-right" style="padding: 13px 30px;">
                            <div class="row">
                                <img src="img/Google-Maps-11-1.jpg" class="im-1" width="100%" height="190px" alt="">
                                <img src="img/star.gif" width="20px" height="20px" alt="">
                                <p style="font-size: 11px;" class="mt-1">۵.۰</p>
                                <div class="col-md-12 m-0 p-0"><h6>جنگل راش سنگده، <small style="font-size: 11px;color: #c6c6c6;">استان مازندران</small></h6></div>
                                <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=cactus&time=day">جزئیات و رزرو</a></div>
                            </div>
                        </div>
                    </div>
            
                    <div class="col-md-3 col-12 mb-2">
                        <div class="container-fluid codr-1-r text-right" style="padding: 13px 30px;">
                            <div class="row">
                                <img src="img/hirkani-jungle.webp" class="im-1" width="100%" height="190px" alt="">
                                <img src="img/star.gif" width="20px" height="20px" alt="">
                                <p style="font-size: 11px;" class="mt-1">۵.۰</p>
                                <div class="col-md-12 m-0 p-0"><h6>جنگل سیاه بیشه، <small style="font-size: 11px;color: #c6c6c6;">استان مازندران</small></h6></div>
                                <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=cactus&time=day">جزئیات و رزرو</a></div>
                            </div>
                        </div>
                    </div>
                </div>
        </div>

        <!-- نقشه ایران -->
        <div class="container-fluid text-center mt-5 map-desktop">
            <h2>از روی نقشه انتخاب کنید</h2>
            <div style="background-image: url(img/dayere-posht-naghshe-r.png); width: 100%;height: 1460px;">
                    <img src="img/ir_map.png" usemap="#image-map">
                    <map name="image-map">
                        <area target="_blank" alt="خراسان شمالی" title="خراسان شمالی" href="ali.php" coords="813,172,821,170,832,178,845,177,848,168,854,172,855,184,863,196,879,196,907,206,926,218,929,211,938,225,922,259,931,270,913,282,915,300,898,300,861,278,837,281,813,296,781,285,784,264,767,247,796,222,790,214,785,189,804,172" shape="poly">
                        <area target="_blank" alt="خراسان رضوی" title="خراسان رضوی" href="ali.php" coords="931,213,979,224,989,244,1028,254,1043,285,1092,282,1095,302,1107,360,1097,393,1093,437,1078,440,1089,454,1067,473,1068,489,1048,497,1031,484,1011,488,995,478,951,481,939,464,908,461,884,434,893,420,862,408,820,431,796,438,827,406,840,391,854,373,825,340,825,317,827,303,815,299,840,278,863,282,905,305,915,299,909,285,932,270,920,259,938,232" shape="poly">
                        <area target="_blank" alt="خراسان جنوبی" title="خراسان جنوبی" href="ali.php" coords="1067,490,1067,513,1097,519,1074,551,1096,625,1097,669,1117,676,1111,717,1117,751,1102,755,1089,736,1070,729,1014,748,991,706,827,638,811,623,804,600,763,573,740,538,746,520,749,469,774,469,793,441,857,407,893,419,885,435,902,458,938,461,952,482,992,477,1011,488,1031,483,1045,496" shape="poly">
                        <area target="_blank" alt="سیستان و بلوچستان" title="سیستان و بلوچستان" href="ali.php" coords="1117,676,1160,679,1163,719,1110,795,1144,831,1167,875,1185,890,1224,901,1228,908,1242,908,1252,966,1250,981,1279,983,1289,989,1279,1025,1234,1037,1197,1066,1183,1147,1167,1153,1115,1142,1014,1139,1007,1115,984,1100,990,1045,979,1004,986,936,993,923,983,911,1016,888,1007,863,1013,852,1013,822,1004,811,1014,748,1070,732,1092,739,1101,751,1117,748,1109,718" shape="poly">
                        <area target="_blank" alt="گلستان" title="گلستان" href="ali.php" coords="782,187,763,182,744,185,725,199,705,213,703,230,692,235,667,244,645,244,658,276,650,284,668,299,675,313,693,308,719,287,751,288,761,248,775,232,798,223,787,215" shape="poly">
                        <area target="_blank" alt="مازندران" title="مازندران" href="ali.php" coords="673,308,667,297,650,289,635,283,627,278,582,290,532,300,504,297,479,289,448,270,440,272,431,285,464,317,481,323,497,334,520,340,534,355,549,360,567,346,582,358,588,348,604,358,631,354,654,325,657,314" shape="poly">
                        <area target="_blank" alt="گیلان" title="گیلان" href="ali.php" coords="449,269,440,264,431,254,426,236,409,230,378,225,358,211,349,197,346,176,346,153,332,155,337,164,332,178,327,201,335,222,344,237,344,248,364,275,390,295,432,289,437,277" shape="poly">
                        <area target="_blank" alt="اردبیل" title="اردبیل" href="ali.php" coords="341,244,339,231,325,199,334,164,321,141,301,124,303,111,319,108,305,88,320,79,301,55,291,54,241,84,246,109,264,97,267,112,260,121,267,131,254,154,269,166,281,162,285,190,296,193,293,218,304,231,307,243,316,247,332,254" shape="poly">
                        <area target="_blank" alt="آذربایجان شرقی" title="آذربایجان شرقی" href="ali.php" coords="238,84,227,93,211,112,187,112,150,100,140,107,140,120,123,143,129,160,127,187,134,201,137,220,157,235,187,256,197,250,207,246,219,261,216,273,238,276,257,252,279,247,298,252,308,247,302,232,298,196,285,189,279,162,269,166,255,154,266,130,257,124,268,114,263,97,244,106" shape="poly">
                        <area target="_blank" alt="آذربایجان غربی" title="آذربایجان غربی" href="ali.php" coords="145,95,139,80,128,73,119,57,100,35,87,46,86,59,63,54,69,73,75,123,80,142,66,169,84,189,84,207,96,224,93,239,99,247,93,255,107,269,107,284,117,294,121,312,121,321,132,323,143,307,163,302,166,292,208,293,222,302,240,299,244,289,237,276,222,274,219,259,207,246,186,254,139,221,128,188,123,141,138,120" shape="poly">
                        <area target="_blank" alt="کردستان" title="کردستان" href="ali.php" coords="239,305,244,291,267,300,281,314,278,341,288,350,272,356,278,377,291,397,270,407,250,396,229,408,223,419,199,423,184,389,167,382,160,363,162,353,181,341,156,343,134,326,138,307,160,303,168,291,204,291,223,300" shape="poly">
                        <area target="_blank" alt="زنجان" title="زنجان" href="ali.php" coords="345,248,327,252,311,244,305,249,276,246,260,255,239,275,241,290,274,300,280,319,279,337,290,350,309,361,337,364,331,343,339,338,364,338,370,317,348,291,363,279,360,269" shape="poly">
                        <area target="_blank" alt="قزوین " title="قزوین " href="ali.php" coords="369,306,352,297,350,285,362,275,378,287,399,293,435,290,469,314,438,313,448,326,443,340,425,350,421,361,408,366,392,372,378,376,362,376,346,369,340,361,332,349,340,337,356,342,369,335,373,323" shape="poly">
                        <area target="_blank" alt="همدان" title="همدان" href="ali.php" coords="341,369,325,365,308,361,291,361,275,360,276,377,288,390,288,405,276,406,269,411,268,423,261,430,278,442,269,446,269,459,282,471,302,477,322,477,334,485,346,476,345,459,337,441,345,434,350,423,354,417,364,417,372,431,378,426,372,413,362,408,369,405,369,394,375,382,363,375" shape="poly">
                        <area target="_blank" alt="کرمانشاه " title="کرمانشاه " href="ali.php" coords="266,406,247,397,235,405,221,419,202,422,182,384,168,387,149,400,134,420,119,449,127,461,114,477,132,504,139,476,161,476,180,485,194,494,229,488,243,467,255,459,268,449,278,441,260,428" shape="poly">
                        <area target="_blank" alt="ایلام" title="ایلام" href="ali.php" coords="195,491,171,478,147,473,134,500,159,537,153,555,175,564,218,599,229,599,241,624,252,617,252,608,267,587,258,561,232,534,221,531,209,507,222,502,241,495,244,483" shape="poly">
                        <area target="_blank" alt="اراک" title="اراک" href="ali.php" coords="449,419,462,377,449,367,421,364,377,373,363,406,378,424,373,434,362,422,348,428,338,438,345,467,337,488,338,506,355,506,363,495,374,497,377,510,392,516,403,523,461,502,468,485,457,477,444,478,432,467,415,471,407,447,413,428,437,420" shape="poly">
                        <area target="_blank" alt="فارسی" title="فارسی" href="ali.php" coords="769,241,754,266,754,284,713,287,696,308,673,309,656,314,654,334,628,356,604,360,605,375,596,389,573,395,533,382,525,382,534,403,523,422,521,447,544,459,560,457,585,471,746,469,775,467,852,373,826,343,827,302,811,295,785,287,782,260" shape="poly">
                        <area target="_blank" alt="تهران" title="تهران" href="ali.php" coords="601,372,603,356,587,349,583,357,568,347,550,359,528,355,525,342,498,336,492,342,483,353,462,355,451,366,462,377,457,396,467,400,524,421,533,407,525,384,532,376,546,387,573,394,597,388" shape="poly">
                        <area target="_blank" alt="البرز" title="البرز" href="ali.php" coords="492,334,481,324,464,317,445,314,443,320,446,331,440,344,428,350,422,356,429,365,454,369,461,355,481,354,488,342" shape="poly">
                        <area target="_blank" alt="قم" title="قم" href="ali.php" coords="523,419,460,397,449,417,415,430,410,447,416,469,431,466,445,478,468,473,473,458,522,448,525,431" shape="poly">
                        <area target="_blank" alt="اصفهان" title="اصفهان" href="ali.php" coords="748,471,584,473,564,456,542,462,521,454,472,460,467,477,472,486,402,523,398,548,368,576,382,586,384,597,407,592,420,602,452,594,464,623,480,641,474,667,481,701,474,711,505,733,517,694,508,683,534,668,544,682,584,674,587,611,609,596,645,600,707,576,726,542,742,539,746,521" shape="poly">
                        <area target="_blank" alt="لرستان" title="لرستان" href="ali.php" coords="369,572,374,566,385,554,405,531,382,514,376,495,364,496,351,507,337,502,335,485,316,479,293,477,262,452,247,464,233,479,245,484,240,493,211,506,222,531,235,532,257,561,264,584,284,558,298,560,315,557,327,564,339,564,350,576,358,577" shape="poly">
                        <area target="_blank" alt="خوزستان" title="خوزستان" href="ali.php" coords="243,624,254,614,252,602,280,557,302,559,313,557,340,563,364,577,384,589,390,625,410,653,419,669,413,681,392,695,394,714,404,724,420,742,415,759,419,777,398,771,388,779,362,795,354,783,337,781,329,771,325,787,309,788,290,788,280,766,266,752,269,714,245,708,251,678,257,654" shape="poly">
                        <area target="_blank" alt="چهارمحال بختیاری" title="چهارمحال بختیاری" href="ali.php" coords="404,638,390,623,382,601,408,591,415,596,448,593,468,611,479,638,479,667,481,693,475,706,457,712,438,693,413,678,420,667" shape="poly">
                        <area target="_blank" alt="یزد" title="یزد" href="ali.php" coords="582,670,582,652,588,638,584,610,607,598,643,599,711,575,723,540,739,538,757,569,802,600,811,623,827,638,810,657,770,673,769,712,704,722,684,739,696,770,698,792,697,804,681,805,656,795,658,775,640,748,608,685" shape="poly">
                        <area target="_blank" alt="کهکیوره و بویر احمد" title="کهکیوره و بویر احمد" href="ali.php" coords="502,731,501,743,488,751,464,742,468,763,464,775,448,779,433,781,421,777,414,760,417,739,402,730,391,698,413,682,432,688,452,710,474,701" shape="poly">
                        <area target="_blank" alt="بوشهر" title="بوشهر" href="ali.php" coords="391,778,397,770,426,776,439,805,469,810,478,832,495,841,502,864,521,894,524,917,541,933,555,970,579,993,563,1000,556,982,543,976,521,963,501,962,477,948,460,913,460,899,448,888,448,863,433,835,402,800" shape="poly">
                        <area target="_blank" alt="فارس" title="فارس" href="ali.php" coords="431,779,469,770,466,745,501,754,515,687,534,669,544,678,591,677,613,695,655,770,655,790,680,804,698,835,723,842,733,878,734,893,755,914,752,940,760,955,739,965,720,987,696,984,664,988,650,998,654,1008,640,1011,605,1002,580,993,558,971,542,933,520,916,520,890,501,864,497,845,480,833,472,808,433,804" shape="poly">
                        <area target="_blank" alt="کرمان" title="کرمان" href="ali.php" coords="685,808,696,803,701,778,689,742,701,719,770,712,770,666,811,655,823,641,986,705,1013,746,1005,805,1011,818,1010,850,1008,858,1014,888,984,907,990,923,976,999,987,1041,951,1049,934,1023,916,1029,889,1019,881,962,858,943,857,923,846,920,828,936,797,925,795,879,782,877,762,888,752,877,729,868,725,843,692,835" shape="poly">
                        <area target="_blank" alt="هرمزگان" title="هرمزگان" href="ali.php" coords="563,1000,582,989,648,1011,656,1006,654,996,703,984,725,988,732,966,761,956,752,941,756,914,734,891,735,874,760,888,781,879,796,879,796,919,825,936,846,920,856,923,856,942,881,956,887,1018,914,1026,932,1023,946,1043,985,1040,987,1097,1007,1115,1011,1137,989,1130,940,1132,922,1123,889,1115,866,1067,852,1021,826,1009,793,1009,774,1026,745,1043,710,1064,684,1055,656,1048,627,1047,620,1026,590,1021" shape="poly">
                        <area target="_blank" alt="قشم" title="قشم" href="ali.php" coords="742,1070,742,1058,774,1047,770,1035,789,1036,805,1029,816,1031,804,1037,801,1049,790,1054,779,1052" shape="poly">
                    </map>
            </div>
        </div>
        <!-- نقشه ایران -->
        <div class="container-fluid text-center mt-5 map-mobile">
            <h5>از روی نقشه انتخاب کنید</h5>
            <div style="background-image: url(img/dayere-posht-naghshe-r.png); width: 100px;height: 500px;">
                    <img src="img/ir_map.png" usemap="#image-map" style="width: 400px;">
                    <map name="image-map">
                        <area target="_blank" alt="خراسان شمالی" title="خراسان شمالی" href="ali.php" coords="813,172,821,170,832,178,845,177,848,168,854,172,855,184,863,196,879,196,907,206,926,218,929,211,938,225,922,259,931,270,913,282,915,300,898,300,861,278,837,281,813,296,781,285,784,264,767,247,796,222,790,214,785,189,804,172" shape="poly">
                        <area target="_blank" alt="خراسان رضوی" title="خراسان رضوی" href="ali.php" coords="931,213,979,224,989,244,1028,254,1043,285,1092,282,1095,302,1107,360,1097,393,1093,437,1078,440,1089,454,1067,473,1068,489,1048,497,1031,484,1011,488,995,478,951,481,939,464,908,461,884,434,893,420,862,408,820,431,796,438,827,406,840,391,854,373,825,340,825,317,827,303,815,299,840,278,863,282,905,305,915,299,909,285,932,270,920,259,938,232" shape="poly">
                        <area target="_blank" alt="خراسان جنوبی" title="خراسان جنوبی" href="ali.php" coords="1067,490,1067,513,1097,519,1074,551,1096,625,1097,669,1117,676,1111,717,1117,751,1102,755,1089,736,1070,729,1014,748,991,706,827,638,811,623,804,600,763,573,740,538,746,520,749,469,774,469,793,441,857,407,893,419,885,435,902,458,938,461,952,482,992,477,1011,488,1031,483,1045,496" shape="poly">
                        <area target="_blank" alt="سیستان و بلوچستان" title="سیستان و بلوچستان" href="ali.php" coords="1117,676,1160,679,1163,719,1110,795,1144,831,1167,875,1185,890,1224,901,1228,908,1242,908,1252,966,1250,981,1279,983,1289,989,1279,1025,1234,1037,1197,1066,1183,1147,1167,1153,1115,1142,1014,1139,1007,1115,984,1100,990,1045,979,1004,986,936,993,923,983,911,1016,888,1007,863,1013,852,1013,822,1004,811,1014,748,1070,732,1092,739,1101,751,1117,748,1109,718" shape="poly">
                        <area target="_blank" alt="گلستان" title="گلستان" href="ali.php" coords="782,187,763,182,744,185,725,199,705,213,703,230,692,235,667,244,645,244,658,276,650,284,668,299,675,313,693,308,719,287,751,288,761,248,775,232,798,223,787,215" shape="poly">
                        <area target="_blank" alt="مازندران" title="مازندران" href="ali.php" coords="673,308,667,297,650,289,635,283,627,278,582,290,532,300,504,297,479,289,448,270,440,272,431,285,464,317,481,323,497,334,520,340,534,355,549,360,567,346,582,358,588,348,604,358,631,354,654,325,657,314" shape="poly">
                        <area target="_blank" alt="گیلان" title="گیلان" href="ali.php" coords="449,269,440,264,431,254,426,236,409,230,378,225,358,211,349,197,346,176,346,153,332,155,337,164,332,178,327,201,335,222,344,237,344,248,364,275,390,295,432,289,437,277" shape="poly">
                        <area target="_blank" alt="اردبیل" title="اردبیل" href="ali.php" coords="341,244,339,231,325,199,334,164,321,141,301,124,303,111,319,108,305,88,320,79,301,55,291,54,241,84,246,109,264,97,267,112,260,121,267,131,254,154,269,166,281,162,285,190,296,193,293,218,304,231,307,243,316,247,332,254" shape="poly">
                        <area target="_blank" alt="آذربایجان شرقی" title="آذربایجان شرقی" href="ali.php" coords="238,84,227,93,211,112,187,112,150,100,140,107,140,120,123,143,129,160,127,187,134,201,137,220,157,235,187,256,197,250,207,246,219,261,216,273,238,276,257,252,279,247,298,252,308,247,302,232,298,196,285,189,279,162,269,166,255,154,266,130,257,124,268,114,263,97,244,106" shape="poly">
                        <area target="_blank" alt="آذربایجان غربی" title="آذربایجان غربی" href="ali.php" coords="145,95,139,80,128,73,119,57,100,35,87,46,86,59,63,54,69,73,75,123,80,142,66,169,84,189,84,207,96,224,93,239,99,247,93,255,107,269,107,284,117,294,121,312,121,321,132,323,143,307,163,302,166,292,208,293,222,302,240,299,244,289,237,276,222,274,219,259,207,246,186,254,139,221,128,188,123,141,138,120" shape="poly">
                        <area target="_blank" alt="کردستان" title="کردستان" href="ali.php" coords="239,305,244,291,267,300,281,314,278,341,288,350,272,356,278,377,291,397,270,407,250,396,229,408,223,419,199,423,184,389,167,382,160,363,162,353,181,341,156,343,134,326,138,307,160,303,168,291,204,291,223,300" shape="poly">
                        <area target="_blank" alt="زنجان" title="زنجان" href="ali.php" coords="345,248,327,252,311,244,305,249,276,246,260,255,239,275,241,290,274,300,280,319,279,337,290,350,309,361,337,364,331,343,339,338,364,338,370,317,348,291,363,279,360,269" shape="poly">
                        <area target="_blank" alt="قزوین " title="قزوین " href="ali.php" coords="369,306,352,297,350,285,362,275,378,287,399,293,435,290,469,314,438,313,448,326,443,340,425,350,421,361,408,366,392,372,378,376,362,376,346,369,340,361,332,349,340,337,356,342,369,335,373,323" shape="poly">
                        <area target="_blank" alt="همدان" title="همدان" href="ali.php" coords="341,369,325,365,308,361,291,361,275,360,276,377,288,390,288,405,276,406,269,411,268,423,261,430,278,442,269,446,269,459,282,471,302,477,322,477,334,485,346,476,345,459,337,441,345,434,350,423,354,417,364,417,372,431,378,426,372,413,362,408,369,405,369,394,375,382,363,375" shape="poly">
                        <area target="_blank" alt="کرمانشاه " title="کرمانشاه " href="ali.php" coords="266,406,247,397,235,405,221,419,202,422,182,384,168,387,149,400,134,420,119,449,127,461,114,477,132,504,139,476,161,476,180,485,194,494,229,488,243,467,255,459,268,449,278,441,260,428" shape="poly">
                        <area target="_blank" alt="ایلام" title="ایلام" href="ali.php" coords="195,491,171,478,147,473,134,500,159,537,153,555,175,564,218,599,229,599,241,624,252,617,252,608,267,587,258,561,232,534,221,531,209,507,222,502,241,495,244,483" shape="poly">
                        <area target="_blank" alt="اراک" title="اراک" href="ali.php" coords="449,419,462,377,449,367,421,364,377,373,363,406,378,424,373,434,362,422,348,428,338,438,345,467,337,488,338,506,355,506,363,495,374,497,377,510,392,516,403,523,461,502,468,485,457,477,444,478,432,467,415,471,407,447,413,428,437,420" shape="poly">
                        <area target="_blank" alt="فارسی" title="فارسی" href="ali.php" coords="769,241,754,266,754,284,713,287,696,308,673,309,656,314,654,334,628,356,604,360,605,375,596,389,573,395,533,382,525,382,534,403,523,422,521,447,544,459,560,457,585,471,746,469,775,467,852,373,826,343,827,302,811,295,785,287,782,260" shape="poly">
                        <area target="_blank" alt="تهران" title="تهران" href="ali.php" coords="601,372,603,356,587,349,583,357,568,347,550,359,528,355,525,342,498,336,492,342,483,353,462,355,451,366,462,377,457,396,467,400,524,421,533,407,525,384,532,376,546,387,573,394,597,388" shape="poly">
                        <area target="_blank" alt="البرز" title="البرز" href="ali.php" coords="492,334,481,324,464,317,445,314,443,320,446,331,440,344,428,350,422,356,429,365,454,369,461,355,481,354,488,342" shape="poly">
                        <area target="_blank" alt="قم" title="قم" href="ali.php" coords="523,419,460,397,449,417,415,430,410,447,416,469,431,466,445,478,468,473,473,458,522,448,525,431" shape="poly">
                        <area target="_blank" alt="اصفهان" title="اصفهان" href="ali.php" coords="748,471,584,473,564,456,542,462,521,454,472,460,467,477,472,486,402,523,398,548,368,576,382,586,384,597,407,592,420,602,452,594,464,623,480,641,474,667,481,701,474,711,505,733,517,694,508,683,534,668,544,682,584,674,587,611,609,596,645,600,707,576,726,542,742,539,746,521" shape="poly">
                        <area target="_blank" alt="لرستان" title="لرستان" href="ali.php" coords="369,572,374,566,385,554,405,531,382,514,376,495,364,496,351,507,337,502,335,485,316,479,293,477,262,452,247,464,233,479,245,484,240,493,211,506,222,531,235,532,257,561,264,584,284,558,298,560,315,557,327,564,339,564,350,576,358,577" shape="poly">
                        <area target="_blank" alt="خوزستان" title="خوزستان" href="ali.php" coords="243,624,254,614,252,602,280,557,302,559,313,557,340,563,364,577,384,589,390,625,410,653,419,669,413,681,392,695,394,714,404,724,420,742,415,759,419,777,398,771,388,779,362,795,354,783,337,781,329,771,325,787,309,788,290,788,280,766,266,752,269,714,245,708,251,678,257,654" shape="poly">
                        <area target="_blank" alt="چهارمحال بختیاری" title="چهارمحال بختیاری" href="ali.php" coords="404,638,390,623,382,601,408,591,415,596,448,593,468,611,479,638,479,667,481,693,475,706,457,712,438,693,413,678,420,667" shape="poly">
                        <area target="_blank" alt="یزد" title="یزد" href="ali.php" coords="582,670,582,652,588,638,584,610,607,598,643,599,711,575,723,540,739,538,757,569,802,600,811,623,827,638,810,657,770,673,769,712,704,722,684,739,696,770,698,792,697,804,681,805,656,795,658,775,640,748,608,685" shape="poly">
                        <area target="_blank" alt="کهکیوره و بویر احمد" title="کهکیوره و بویر احمد" href="ali.php" coords="502,731,501,743,488,751,464,742,468,763,464,775,448,779,433,781,421,777,414,760,417,739,402,730,391,698,413,682,432,688,452,710,474,701" shape="poly">
                        <area target="_blank" alt="بوشهر" title="بوشهر" href="ali.php" coords="391,778,397,770,426,776,439,805,469,810,478,832,495,841,502,864,521,894,524,917,541,933,555,970,579,993,563,1000,556,982,543,976,521,963,501,962,477,948,460,913,460,899,448,888,448,863,433,835,402,800" shape="poly">
                        <area target="_blank" alt="فارس" title="فارس" href="ali.php" coords="431,779,469,770,466,745,501,754,515,687,534,669,544,678,591,677,613,695,655,770,655,790,680,804,698,835,723,842,733,878,734,893,755,914,752,940,760,955,739,965,720,987,696,984,664,988,650,998,654,1008,640,1011,605,1002,580,993,558,971,542,933,520,916,520,890,501,864,497,845,480,833,472,808,433,804" shape="poly">
                        <area target="_blank" alt="کرمان" title="کرمان" href="ali.php" coords="685,808,696,803,701,778,689,742,701,719,770,712,770,666,811,655,823,641,986,705,1013,746,1005,805,1011,818,1010,850,1008,858,1014,888,984,907,990,923,976,999,987,1041,951,1049,934,1023,916,1029,889,1019,881,962,858,943,857,923,846,920,828,936,797,925,795,879,782,877,762,888,752,877,729,868,725,843,692,835" shape="poly">
                        <area target="_blank" alt="هرمزگان" title="هرمزگان" href="ali.php" coords="563,1000,582,989,648,1011,656,1006,654,996,703,984,725,988,732,966,761,956,752,941,756,914,734,891,735,874,760,888,781,879,796,879,796,919,825,936,846,920,856,923,856,942,881,956,887,1018,914,1026,932,1023,946,1043,985,1040,987,1097,1007,1115,1011,1137,989,1130,940,1132,922,1123,889,1115,866,1067,852,1021,826,1009,793,1009,774,1026,745,1043,710,1064,684,1055,656,1048,627,1047,620,1026,590,1021" shape="poly">
                        <area target="_blank" alt="قشم" title="قشم" href="ali.php" coords="742,1070,742,1058,774,1047,770,1035,789,1036,805,1029,816,1031,804,1037,801,1049,790,1054,779,1052" shape="poly">
                    </map>
            </div>
        </div>
        
        <!-- فوتر  -->
        <div class="container-fluid pb-5" style="margin-top: 100px; background-color: #ff6b01;color: #fff;">
            <div class="container text-center">
                <div class="row">
                    <div class="col-md-3 text-right pr-4 pt-5">
                        <h3><b>ارتباط با ما</b></h3>
                        <h5 style="margin-top: 40px;">درباره ما</h5>
                        <h5 style="margin-top: 40px;">همکاری باما</h5>
                        <h5 style="margin-top: 40px;">تماس باما</h5>
                    </div>
                    <div class="col-md-3 text-right pr-4 pt-5">
                        <h3><b>مجوز های قانونی</b></h3>
                        <h5 style="margin-top: 40px;">مجوز اقامت</h5>
                        <h5 style="margin-top: 40px;">مجوز کمپینگ</h5>
                        <h5 style="margin-top: 40px;">مجوز افراد</h5>
                    </div>            
                    <div class="col-md-6 pt-5 text-right">
                        <h3><b>فضای مجازی</b></h3>
                        <div class="row">
                            <div class="col-md-6  pr-5">
                                <img src="img/telk.webp" width="60px" alt="">
                                <img src="img/Instagram-Logo.png" width="80px" alt="">
                                <img src="img/bale_200_200_c1.png" width="60px" alt="">
                            </div>
                            <div class="col-md-6">
                                <img src="img/i namad a.png" width="123px" alt="">
                                <img src="img/i namad ta.png" width="123px" alt="">
                            </div>
                            <h6 class="mb-2 pb-2 mt-4" style="border-bottom: 2px #ffc107 solid;">ثبت نام درخبرنامه</h6>
                            <p>برای اطلاع از تخفیف کمپینگ پست الکتریکی خود را در باکس زیر وارد کنید</p>
                            <input type="text" class="inp-et" style="width: 400px;height: 45px;border-radius: 15px;padding: 10px;" placeholder="آدرس ایمیل">
                        </div>
                    </div>
                </div>
            </div>
        </div>

</div>

<!-- کاکتوث شب -->
<div id="cactus-night" class="content-section">

    <!-- مرحله ها -->
    <div class="container-fluid">
        <div class="row mt-4">
            <div class="col-md-1"></div>
            <!-- لیست اول (تصاویر) -->
            <ul class="col-11 col-md-10 nav navbar pb-0 d-flex justify-content-center flex-wrap mr-2">
                <li><img src="img/1R.png" width="45px" class="navbar-brand" alt=""></li>
                <li><img src="img/titir.png" width="300px" class="navbar-brand" height="25px" alt=""></li>
                <li><img src="img/2.2r.png" width="45px" class="navbar-brand" alt=""></li>
                <li><img src="img/titir.png" width="300px" class="navbar-brand" height="25px" alt=""></li>
                <li><img src="img/3.2r.png" width="45px" class="navbar-brand" alt=""></li>
                <li><img src="img/titir.png" width="300px" class="navbar-brand" height="25px" alt=""></li>
                <li><img src="img/4.2r.png" width="45px" class="navbar-brand" alt=""></li>
            </ul>
            
            <!-- لیست دوم (متن‌ها) -->
            <div class="col-md-3 pr-5 text-center text-light">
                <h6>انتخاب محل کمپ</h6>
            </div>
            <div class="col-md-3 text-center pr-5 text-light">
                <h6>انتخاب منطقه</h6>
            </div>
            <div class="col-md-3 text-center pr-5 text-light">
                <h6>اجاره ابزارآلات</h6>
            </div>
            <div class="col-md-3 text-center pr-5 text-light">
                <h6>پرداخت</h6>
            </div>
        </div>
    </div>

    <!-- جستوجو -->
    <div class="container mt-5">
        <div class="row">
            <div class="col-sm-10 col-md-12 text-center">
                <input id="search-4" type="text" class="in-serg-r" placeholder="اسم منطقه کمپ، شهر، روستا، جنگل، کویر و ..." style="width: 100%;">
            </div>
        </div>
    </div>

    <!-- پربازدید ها -->
    <div class="container-fluid text-center p-5">
        <div class="row text-right cor-1">
            <h5>برترین های جنگل</h5>
        </div>
        <div class="row mt-4">

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1-r text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/pictures-template-2(17).jpg" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۴.۶</p>
                        <div class="col-md-12 m-0 p-0"><h6>جنگل المیستان ، <small style="font-size: 11px;color: #c6c6c6;">استان مازندران - بابل</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=cactus&time=night">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1-r text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/53b9c6469c5b76c007b96ff6.jpg" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۵.۰</p>
                        <div class="col-md-12 m-0 p-0"><h6>جنگل ابر، <small style="font-size: 11px;color: #c6c6c6;">شاهرود</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=cactus&time=night">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1-r text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/ییلاق-ماسال-1.webp" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۴.۲</p>
                        <div class="col-md-12 m-0 p-0"><h6>جنگل ییلاقات ماسال، <small style="font-size: 11px;color: #c6c6c6;">استان مازندران - گیلان</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=cactus&time=night">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1-r text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/جنگل-دالخانی.webp" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۴.۵</p>
                        <div class="col-md-12 m-0 p-0"><h6>جنگل دالخانی، <small style="font-size: 11px;color: #c6c6c6;">رامسر</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=cactus&time=night">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>
            
        </div>

        <!-- برترین های کویر -->
        <div class="row text-right cor-1 mt-4">
            <h5>برترین های کویر</h5>
        </div>
        <div class="row mt-4">

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1-r text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/The-Maranjab-Desert-ezgif.com-optiwebp.webp" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۴.۸</p>
                        <div class="col-md-12 m-0 p-0"><h6>کویر مرنجاب، <small style="font-size: 11px;color: #c6c6c6;">استان اصفهان</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=cactus&time=night">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1-r text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/loot-sh.jpg_34xzfheh.uqc.jpg" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۵.۰</p>
                        <div class="col-md-12 m-0 p-0"><h6>کویر لوت، <small style="font-size: 11px;color: #c6c6c6;">استان‌های کرمان</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=cactus&time=night">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1-r text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/Articlee14fe676-9263-4e65-920e-357d46501de9_mihmansho.jpg" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۵.۰</p>
                        <div class="col-md-12 m-0 p-0"><h6>کویر زردگاه، <small style="font-size: 11px;color: #c6c6c6;">استان خراسان جنوبی</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=cactus&time=night">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1-r text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/1195fa02-fae7-461b-944a-e76b9e1c789c.webp" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۴.۵</p>
                        <div class="col-md-12 m-0 p-0"><h6>کویر ریگ جن، <small style="font-size: 11px;color: #c6c6c6;">استان‌های سمنان</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=cactus&time=night">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>
            
        </div>

        <!-- برترین های کوهستانی -->
        <div class="row text-right cor-1 mt-4">
            <h5>برترین های کوهستانی</h5>
        </div>
        <div class="row mt-4">

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1-r text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/981012-Damavand-South-IMG_9861-2.jpg" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۴.۳</p>
                        <div class="col-md-12 m-0 p-0"><h6>کوه دماوند، <small style="font-size: 11px;color: #c6c6c6;">استان البرز</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=cactus&time=night">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1-r text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/رشته-کوه-زاگرس.jpg" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۴.۱</p>
                        <div class="col-md-12 m-0 p-0"><h6>رشته کوه زاگرس، <small style="font-size: 11px;color: #c6c6c6;">استان‌ کردستان</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=cactus&time=night">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1-r text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/114839.jpg" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۳.۲</p>
                        <div class="col-md-12 m-0 p-0"><h6>قله الوند، <small style="font-size: 11px;color: #c6c6c6;">استان همدان</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=cactus&time=night">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1-r text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/c2461595-3144-4b98-9116-d96359d4a7b1.webp" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۲.۹</p>
                        <div class="col-md-12 m-0 p-0"><h6>قلهٔ بینالود، <small style="font-size: 11px;color: #c6c6c6;">استان خراسان رضوی</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=cactus&time=night">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>
            
        </div>

            <!-- پرطرفدار ترین -->
            <div class="row text-right cor-1 mt-4">
                <h5>پرطرفدار ترین</h5>
            </div>
            <div class="row mt-4">
        
                <div class="col-md-3 col-12 mb-2">
                    <div class="container-fluid codr-1-r text-right" style="padding: 13px 30px;">
                        <div class="row">
                            <img src="img/چالوس-جاده-1.jpg" class="im-1" width="100%" height="190px" alt="">
                            <img src="img/star.gif" width="20px" height="20px" alt="">
                            <p style="font-size: 11px;" class="mt-1">۴.۶</p>
                            <div class="col-md-12 m-0 p-0"><h6>فین چالوس، <small style="font-size: 11px;color: #c6c6c6;">استان مازندران</small></h6></div>
                            <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=cactus&time=night">جزئیات و رزرو</a></div>
                        </div>
                    </div>
                </div>
        
                <div class="col-md-3 col-12 mb-2">
                    <div class="container-fluid codr-1-r text-right" style="padding: 13px 30px;">
                        <div class="row">
                            <img src="img/خارا.jpg" class="im-1" width="100%" height="190px" alt="">
                            <img src="img/star.gif" width="20px" height="20px" alt="">
                            <p style="font-size: 11px;" class="mt-1">۴.۶</p>
                            <div class="col-md-12 m-0 p-0"><h6>کویر خارا، <small style="font-size: 11px;color: #c6c6c6;">استان‌ اصفهان</small></h6></div>
                            <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=cactus&time=night">جزئیات و رزرو</a></div>
                        </div>
                    </div>
                </div>
        
                <div class="col-md-3 col-12 mb-2">
                    <div class="container-fluid codr-1-r text-right" style="padding: 13px 30px;">
                        <div class="row">
                            <img src="img/981012-Damavand-South-IMG_9861-2.jpg" class="im-1" width="100%" height="190px" alt="">
                            <img src="img/star.gif" width="20px" height="20px" alt="">
                            <p style="font-size: 11px;" class="mt-1">۴.۳</p>
                            <div class="col-md-12 m-0 p-0"><h6>کوه دماوند، <small style="font-size: 11px;color: #c6c6c6;">استان البرز</small></h6></div>
                            <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=cactus&time=night">جزئیات و رزرو</a></div>
                        </div>
                    </div>
                </div>
        
                <div class="col-md-3 col-12 mb-2">
                    <div class="container-fluid codr-1-r text-right" style="padding: 13px 30px;">
                        <div class="row">
                            <img src="img/WhatsApp_Image_2021-12-13_at_12.06.25.jpg " class="im-1" width="100%" height="190px" alt="">
                            <img src="img/star.gif" width="20px" height="20px" alt="">
                            <p style="font-size: 11px;" class="mt-1">۴.۶</p>
                            <div class="col-md-12 m-0 p-0"><h6>ساحل گیسوم ، <small style="font-size: 11px;color: #c6c6c6;">استان هرمزگان</small></h6></div>
                            <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=cactus&time=night">جزئیات و رزرو</a></div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- بالاترین نمره -->
            <div class="row text-right cor-1 mt-4">
                <h5>بالاترین نمره</h5>
            </div>
            <div class="row mt-4">
        
                <div class="col-md-3 col-12 mb-2">
                    <div class="container-fluid codr-1-r text-right" style="padding: 13px 30px;">
                        <div class="row">
                            <img src="img/53b9c6469c5b76c007b96ff6.jpg" class="im-1" width="100%" height="190px" alt="">
                            <img src="img/star.gif" width="20px" height="20px" alt="">
                            <p style="font-size: 11px;" class="mt-1">۵.۰</p>
                            <div class="col-md-12 m-0 p-0"><h6>جنگل ابر، <small style="font-size: 11px;color: #c6c6c6;">شاهرود</small></h6></div>
                            <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=cactus&time=night">جزئیات و رزرو</a></div>
                        </div>
                    </div>
                </div>
        
                <div class="col-md-3 col-12 mb-2">
                    <div class="container-fluid codr-1-r text-right" style="padding: 13px 30px;">
                        <div class="row">
                            <img src="img/Articlee14fe676-9263-4e65-920e-357d46501de9_mihmansho.jpg" class="im-1" width="100%" height="190px" alt="">
                            <img src="img/star.gif" width="20px" height="20px" alt="">
                            <p style="font-size: 11px;" class="mt-1">۵.۰</p>
                            <div class="col-md-12 m-0 p-0"><h6>کویر زردگاه، <small style="font-size: 11px;color: #c6c6c6;">استان خراسان جنوبی</small></h6></div>
                            <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=cactus&time=night">جزئیات و رزرو</a></div>
                        </div>
                    </div>
                </div>
        
                <div class="col-md-3 col-12 mb-2">
                    <div class="container-fluid codr-1-r text-right" style="padding: 13px 30px;">
                        <div class="row">
                            <img src="img/Google-Maps-11-1.jpg" class="im-1" width="100%" height="190px" alt="">
                            <img src="img/star.gif" width="20px" height="20px" alt="">
                            <p style="font-size: 11px;" class="mt-1">۵.۰</p>
                            <div class="col-md-12 m-0 p-0"><h6>جنگل راش سنگده، <small style="font-size: 11px;color: #c6c6c6;">استان مازندران</small></h6></div>
                            <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=cactus&time=night">جزئیات و رزرو</a></div>
                        </div>
                    </div>
                </div>
        
                <div class="col-md-3 col-12 mb-2">
                    <div class="container-fluid codr-1-r text-right" style="padding: 13px 30px;">
                        <div class="row">
                            <img src="img/hirkani-jungle.webp" class="im-1" width="100%" height="190px" alt="">
                            <img src="img/star.gif" width="20px" height="20px" alt="">
                            <p style="font-size: 11px;" class="mt-1">۵.۰</p>
                            <div class="col-md-12 m-0 p-0"><h6>جنگل سیاه بیشه، <small style="font-size: 11px;color: #c6c6c6;">استان مازندران</small></h6></div>
                            <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=cactus&time=night">جزئیات و رزرو</a></div>
                        </div>
                    </div>
                </div>
            </div>
    </div>

    <!-- نقشه ایران -->
    <div class="container-fluid text-center mt-5 map-desktop">
        <h2>از روی نقشه انتخاب کنید</h2>
        <div style="background-image: url(img/dayere-posht-naghshe-r.png); width: 100%;height: 1460px;">
                <img src="img/ir_map.png" usemap="#image-map">
                <map name="image-map">
                    <area target="_blank" alt="خراسان شمالی" title="خراسان شمالی" href="ali.php" coords="813,172,821,170,832,178,845,177,848,168,854,172,855,184,863,196,879,196,907,206,926,218,929,211,938,225,922,259,931,270,913,282,915,300,898,300,861,278,837,281,813,296,781,285,784,264,767,247,796,222,790,214,785,189,804,172" shape="poly">
                    <area target="_blank" alt="خراسان رضوی" title="خراسان رضوی" href="ali.php" coords="931,213,979,224,989,244,1028,254,1043,285,1092,282,1095,302,1107,360,1097,393,1093,437,1078,440,1089,454,1067,473,1068,489,1048,497,1031,484,1011,488,995,478,951,481,939,464,908,461,884,434,893,420,862,408,820,431,796,438,827,406,840,391,854,373,825,340,825,317,827,303,815,299,840,278,863,282,905,305,915,299,909,285,932,270,920,259,938,232" shape="poly">
                    <area target="_blank" alt="خراسان جنوبی" title="خراسان جنوبی" href="ali.php" coords="1067,490,1067,513,1097,519,1074,551,1096,625,1097,669,1117,676,1111,717,1117,751,1102,755,1089,736,1070,729,1014,748,991,706,827,638,811,623,804,600,763,573,740,538,746,520,749,469,774,469,793,441,857,407,893,419,885,435,902,458,938,461,952,482,992,477,1011,488,1031,483,1045,496" shape="poly">
                    <area target="_blank" alt="سیستان و بلوچستان" title="سیستان و بلوچستان" href="ali.php" coords="1117,676,1160,679,1163,719,1110,795,1144,831,1167,875,1185,890,1224,901,1228,908,1242,908,1252,966,1250,981,1279,983,1289,989,1279,1025,1234,1037,1197,1066,1183,1147,1167,1153,1115,1142,1014,1139,1007,1115,984,1100,990,1045,979,1004,986,936,993,923,983,911,1016,888,1007,863,1013,852,1013,822,1004,811,1014,748,1070,732,1092,739,1101,751,1117,748,1109,718" shape="poly">
                    <area target="_blank" alt="گلستان" title="گلستان" href="ali.php" coords="782,187,763,182,744,185,725,199,705,213,703,230,692,235,667,244,645,244,658,276,650,284,668,299,675,313,693,308,719,287,751,288,761,248,775,232,798,223,787,215" shape="poly">
                    <area target="_blank" alt="مازندران" title="مازندران" href="ali.php" coords="673,308,667,297,650,289,635,283,627,278,582,290,532,300,504,297,479,289,448,270,440,272,431,285,464,317,481,323,497,334,520,340,534,355,549,360,567,346,582,358,588,348,604,358,631,354,654,325,657,314" shape="poly">
                    <area target="_blank" alt="گیلان" title="گیلان" href="ali.php" coords="449,269,440,264,431,254,426,236,409,230,378,225,358,211,349,197,346,176,346,153,332,155,337,164,332,178,327,201,335,222,344,237,344,248,364,275,390,295,432,289,437,277" shape="poly">
                    <area target="_blank" alt="اردبیل" title="اردبیل" href="ali.php" coords="341,244,339,231,325,199,334,164,321,141,301,124,303,111,319,108,305,88,320,79,301,55,291,54,241,84,246,109,264,97,267,112,260,121,267,131,254,154,269,166,281,162,285,190,296,193,293,218,304,231,307,243,316,247,332,254" shape="poly">
                    <area target="_blank" alt="آذربایجان شرقی" title="آذربایجان شرقی" href="ali.php" coords="238,84,227,93,211,112,187,112,150,100,140,107,140,120,123,143,129,160,127,187,134,201,137,220,157,235,187,256,197,250,207,246,219,261,216,273,238,276,257,252,279,247,298,252,308,247,302,232,298,196,285,189,279,162,269,166,255,154,266,130,257,124,268,114,263,97,244,106" shape="poly">
                    <area target="_blank" alt="آذربایجان غربی" title="آذربایجان غربی" href="ali.php" coords="145,95,139,80,128,73,119,57,100,35,87,46,86,59,63,54,69,73,75,123,80,142,66,169,84,189,84,207,96,224,93,239,99,247,93,255,107,269,107,284,117,294,121,312,121,321,132,323,143,307,163,302,166,292,208,293,222,302,240,299,244,289,237,276,222,274,219,259,207,246,186,254,139,221,128,188,123,141,138,120" shape="poly">
                    <area target="_blank" alt="کردستان" title="کردستان" href="ali.php" coords="239,305,244,291,267,300,281,314,278,341,288,350,272,356,278,377,291,397,270,407,250,396,229,408,223,419,199,423,184,389,167,382,160,363,162,353,181,341,156,343,134,326,138,307,160,303,168,291,204,291,223,300" shape="poly">
                    <area target="_blank" alt="زنجان" title="زنجان" href="ali.php" coords="345,248,327,252,311,244,305,249,276,246,260,255,239,275,241,290,274,300,280,319,279,337,290,350,309,361,337,364,331,343,339,338,364,338,370,317,348,291,363,279,360,269" shape="poly">
                    <area target="_blank" alt="قزوین " title="قزوین " href="ali.php" coords="369,306,352,297,350,285,362,275,378,287,399,293,435,290,469,314,438,313,448,326,443,340,425,350,421,361,408,366,392,372,378,376,362,376,346,369,340,361,332,349,340,337,356,342,369,335,373,323" shape="poly">
                    <area target="_blank" alt="همدان" title="همدان" href="ali.php" coords="341,369,325,365,308,361,291,361,275,360,276,377,288,390,288,405,276,406,269,411,268,423,261,430,278,442,269,446,269,459,282,471,302,477,322,477,334,485,346,476,345,459,337,441,345,434,350,423,354,417,364,417,372,431,378,426,372,413,362,408,369,405,369,394,375,382,363,375" shape="poly">
                    <area target="_blank" alt="کرمانشاه " title="کرمانشاه " href="ali.php" coords="266,406,247,397,235,405,221,419,202,422,182,384,168,387,149,400,134,420,119,449,127,461,114,477,132,504,139,476,161,476,180,485,194,494,229,488,243,467,255,459,268,449,278,441,260,428" shape="poly">
                    <area target="_blank" alt="ایلام" title="ایلام" href="ali.php" coords="195,491,171,478,147,473,134,500,159,537,153,555,175,564,218,599,229,599,241,624,252,617,252,608,267,587,258,561,232,534,221,531,209,507,222,502,241,495,244,483" shape="poly">
                    <area target="_blank" alt="اراک" title="اراک" href="ali.php" coords="449,419,462,377,449,367,421,364,377,373,363,406,378,424,373,434,362,422,348,428,338,438,345,467,337,488,338,506,355,506,363,495,374,497,377,510,392,516,403,523,461,502,468,485,457,477,444,478,432,467,415,471,407,447,413,428,437,420" shape="poly">
                    <area target="_blank" alt="فارسی" title="فارسی" href="ali.php" coords="769,241,754,266,754,284,713,287,696,308,673,309,656,314,654,334,628,356,604,360,605,375,596,389,573,395,533,382,525,382,534,403,523,422,521,447,544,459,560,457,585,471,746,469,775,467,852,373,826,343,827,302,811,295,785,287,782,260" shape="poly">
                    <area target="_blank" alt="تهران" title="تهران" href="ali.php" coords="601,372,603,356,587,349,583,357,568,347,550,359,528,355,525,342,498,336,492,342,483,353,462,355,451,366,462,377,457,396,467,400,524,421,533,407,525,384,532,376,546,387,573,394,597,388" shape="poly">
                    <area target="_blank" alt="البرز" title="البرز" href="ali.php" coords="492,334,481,324,464,317,445,314,443,320,446,331,440,344,428,350,422,356,429,365,454,369,461,355,481,354,488,342" shape="poly">
                    <area target="_blank" alt="قم" title="قم" href="ali.php" coords="523,419,460,397,449,417,415,430,410,447,416,469,431,466,445,478,468,473,473,458,522,448,525,431" shape="poly">
                    <area target="_blank" alt="اصفهان" title="اصفهان" href="ali.php" coords="748,471,584,473,564,456,542,462,521,454,472,460,467,477,472,486,402,523,398,548,368,576,382,586,384,597,407,592,420,602,452,594,464,623,480,641,474,667,481,701,474,711,505,733,517,694,508,683,534,668,544,682,584,674,587,611,609,596,645,600,707,576,726,542,742,539,746,521" shape="poly">
                    <area target="_blank" alt="لرستان" title="لرستان" href="ali.php" coords="369,572,374,566,385,554,405,531,382,514,376,495,364,496,351,507,337,502,335,485,316,479,293,477,262,452,247,464,233,479,245,484,240,493,211,506,222,531,235,532,257,561,264,584,284,558,298,560,315,557,327,564,339,564,350,576,358,577" shape="poly">
                    <area target="_blank" alt="خوزستان" title="خوزستان" href="ali.php" coords="243,624,254,614,252,602,280,557,302,559,313,557,340,563,364,577,384,589,390,625,410,653,419,669,413,681,392,695,394,714,404,724,420,742,415,759,419,777,398,771,388,779,362,795,354,783,337,781,329,771,325,787,309,788,290,788,280,766,266,752,269,714,245,708,251,678,257,654" shape="poly">
                    <area target="_blank" alt="چهارمحال بختیاری" title="چهارمحال بختیاری" href="ali.php" coords="404,638,390,623,382,601,408,591,415,596,448,593,468,611,479,638,479,667,481,693,475,706,457,712,438,693,413,678,420,667" shape="poly">
                    <area target="_blank" alt="یزد" title="یزد" href="ali.php" coords="582,670,582,652,588,638,584,610,607,598,643,599,711,575,723,540,739,538,757,569,802,600,811,623,827,638,810,657,770,673,769,712,704,722,684,739,696,770,698,792,697,804,681,805,656,795,658,775,640,748,608,685" shape="poly">
                    <area target="_blank" alt="کهکیوره و بویر احمد" title="کهکیوره و بویر احمد" href="ali.php" coords="502,731,501,743,488,751,464,742,468,763,464,775,448,779,433,781,421,777,414,760,417,739,402,730,391,698,413,682,432,688,452,710,474,701" shape="poly">
                    <area target="_blank" alt="بوشهر" title="بوشهر" href="ali.php" coords="391,778,397,770,426,776,439,805,469,810,478,832,495,841,502,864,521,894,524,917,541,933,555,970,579,993,563,1000,556,982,543,976,521,963,501,962,477,948,460,913,460,899,448,888,448,863,433,835,402,800" shape="poly">
                    <area target="_blank" alt="فارس" title="فارس" href="ali.php" coords="431,779,469,770,466,745,501,754,515,687,534,669,544,678,591,677,613,695,655,770,655,790,680,804,698,835,723,842,733,878,734,893,755,914,752,940,760,955,739,965,720,987,696,984,664,988,650,998,654,1008,640,1011,605,1002,580,993,558,971,542,933,520,916,520,890,501,864,497,845,480,833,472,808,433,804" shape="poly">
                    <area target="_blank" alt="کرمان" title="کرمان" href="ali.php" coords="685,808,696,803,701,778,689,742,701,719,770,712,770,666,811,655,823,641,986,705,1013,746,1005,805,1011,818,1010,850,1008,858,1014,888,984,907,990,923,976,999,987,1041,951,1049,934,1023,916,1029,889,1019,881,962,858,943,857,923,846,920,828,936,797,925,795,879,782,877,762,888,752,877,729,868,725,843,692,835" shape="poly">
                    <area target="_blank" alt="هرمزگان" title="هرمزگان" href="ali.php" coords="563,1000,582,989,648,1011,656,1006,654,996,703,984,725,988,732,966,761,956,752,941,756,914,734,891,735,874,760,888,781,879,796,879,796,919,825,936,846,920,856,923,856,942,881,956,887,1018,914,1026,932,1023,946,1043,985,1040,987,1097,1007,1115,1011,1137,989,1130,940,1132,922,1123,889,1115,866,1067,852,1021,826,1009,793,1009,774,1026,745,1043,710,1064,684,1055,656,1048,627,1047,620,1026,590,1021" shape="poly">
                    <area target="_blank" alt="قشم" title="قشم" href="ali.php" coords="742,1070,742,1058,774,1047,770,1035,789,1036,805,1029,816,1031,804,1037,801,1049,790,1054,779,1052" shape="poly">
                </map>
        </div>
    </div>
    <!-- نقشه ایران -->
    <div class="container-fluid text-center mt-5 map-mobile">
        <h5>از روی نقشه انتخاب کنید</h5>
        <div style="background-image: url(img/dayere-posht-naghshe-r.png); width: 100px;height: 500px;">
                <img src="img/ir_map.png" usemap="#image-map" style="width: 400px;">
                <map name="image-map">
                    <area target="_blank" alt="خراسان شمالی" title="خراسان شمالی" href="ali.php" coords="813,172,821,170,832,178,845,177,848,168,854,172,855,184,863,196,879,196,907,206,926,218,929,211,938,225,922,259,931,270,913,282,915,300,898,300,861,278,837,281,813,296,781,285,784,264,767,247,796,222,790,214,785,189,804,172" shape="poly">
                    <area target="_blank" alt="خراسان رضوی" title="خراسان رضوی" href="ali.php" coords="931,213,979,224,989,244,1028,254,1043,285,1092,282,1095,302,1107,360,1097,393,1093,437,1078,440,1089,454,1067,473,1068,489,1048,497,1031,484,1011,488,995,478,951,481,939,464,908,461,884,434,893,420,862,408,820,431,796,438,827,406,840,391,854,373,825,340,825,317,827,303,815,299,840,278,863,282,905,305,915,299,909,285,932,270,920,259,938,232" shape="poly">
                    <area target="_blank" alt="خراسان جنوبی" title="خراسان جنوبی" href="ali.php" coords="1067,490,1067,513,1097,519,1074,551,1096,625,1097,669,1117,676,1111,717,1117,751,1102,755,1089,736,1070,729,1014,748,991,706,827,638,811,623,804,600,763,573,740,538,746,520,749,469,774,469,793,441,857,407,893,419,885,435,902,458,938,461,952,482,992,477,1011,488,1031,483,1045,496" shape="poly">
                    <area target="_blank" alt="سیستان و بلوچستان" title="سیستان و بلوچستان" href="ali.php" coords="1117,676,1160,679,1163,719,1110,795,1144,831,1167,875,1185,890,1224,901,1228,908,1242,908,1252,966,1250,981,1279,983,1289,989,1279,1025,1234,1037,1197,1066,1183,1147,1167,1153,1115,1142,1014,1139,1007,1115,984,1100,990,1045,979,1004,986,936,993,923,983,911,1016,888,1007,863,1013,852,1013,822,1004,811,1014,748,1070,732,1092,739,1101,751,1117,748,1109,718" shape="poly">
                    <area target="_blank" alt="گلستان" title="گلستان" href="ali.php" coords="782,187,763,182,744,185,725,199,705,213,703,230,692,235,667,244,645,244,658,276,650,284,668,299,675,313,693,308,719,287,751,288,761,248,775,232,798,223,787,215" shape="poly">
                    <area target="_blank" alt="مازندران" title="مازندران" href="ali.php" coords="673,308,667,297,650,289,635,283,627,278,582,290,532,300,504,297,479,289,448,270,440,272,431,285,464,317,481,323,497,334,520,340,534,355,549,360,567,346,582,358,588,348,604,358,631,354,654,325,657,314" shape="poly">
                    <area target="_blank" alt="گیلان" title="گیلان" href="ali.php" coords="449,269,440,264,431,254,426,236,409,230,378,225,358,211,349,197,346,176,346,153,332,155,337,164,332,178,327,201,335,222,344,237,344,248,364,275,390,295,432,289,437,277" shape="poly">
                    <area target="_blank" alt="اردبیل" title="اردبیل" href="ali.php" coords="341,244,339,231,325,199,334,164,321,141,301,124,303,111,319,108,305,88,320,79,301,55,291,54,241,84,246,109,264,97,267,112,260,121,267,131,254,154,269,166,281,162,285,190,296,193,293,218,304,231,307,243,316,247,332,254" shape="poly">
                    <area target="_blank" alt="آذربایجان شرقی" title="آذربایجان شرقی" href="ali.php" coords="238,84,227,93,211,112,187,112,150,100,140,107,140,120,123,143,129,160,127,187,134,201,137,220,157,235,187,256,197,250,207,246,219,261,216,273,238,276,257,252,279,247,298,252,308,247,302,232,298,196,285,189,279,162,269,166,255,154,266,130,257,124,268,114,263,97,244,106" shape="poly">
                    <area target="_blank" alt="آذربایجان غربی" title="آذربایجان غربی" href="ali.php" coords="145,95,139,80,128,73,119,57,100,35,87,46,86,59,63,54,69,73,75,123,80,142,66,169,84,189,84,207,96,224,93,239,99,247,93,255,107,269,107,284,117,294,121,312,121,321,132,323,143,307,163,302,166,292,208,293,222,302,240,299,244,289,237,276,222,274,219,259,207,246,186,254,139,221,128,188,123,141,138,120" shape="poly">
                    <area target="_blank" alt="کردستان" title="کردستان" href="ali.php" coords="239,305,244,291,267,300,281,314,278,341,288,350,272,356,278,377,291,397,270,407,250,396,229,408,223,419,199,423,184,389,167,382,160,363,162,353,181,341,156,343,134,326,138,307,160,303,168,291,204,291,223,300" shape="poly">
                    <area target="_blank" alt="زنجان" title="زنجان" href="ali.php" coords="345,248,327,252,311,244,305,249,276,246,260,255,239,275,241,290,274,300,280,319,279,337,290,350,309,361,337,364,331,343,339,338,364,338,370,317,348,291,363,279,360,269" shape="poly">
                    <area target="_blank" alt="قزوین " title="قزوین " href="ali.php" coords="369,306,352,297,350,285,362,275,378,287,399,293,435,290,469,314,438,313,448,326,443,340,425,350,421,361,408,366,392,372,378,376,362,376,346,369,340,361,332,349,340,337,356,342,369,335,373,323" shape="poly">
                    <area target="_blank" alt="همدان" title="همدان" href="ali.php" coords="341,369,325,365,308,361,291,361,275,360,276,377,288,390,288,405,276,406,269,411,268,423,261,430,278,442,269,446,269,459,282,471,302,477,322,477,334,485,346,476,345,459,337,441,345,434,350,423,354,417,364,417,372,431,378,426,372,413,362,408,369,405,369,394,375,382,363,375" shape="poly">
                    <area target="_blank" alt="کرمانشاه " title="کرمانشاه " href="ali.php" coords="266,406,247,397,235,405,221,419,202,422,182,384,168,387,149,400,134,420,119,449,127,461,114,477,132,504,139,476,161,476,180,485,194,494,229,488,243,467,255,459,268,449,278,441,260,428" shape="poly">
                    <area target="_blank" alt="ایلام" title="ایلام" href="ali.php" coords="195,491,171,478,147,473,134,500,159,537,153,555,175,564,218,599,229,599,241,624,252,617,252,608,267,587,258,561,232,534,221,531,209,507,222,502,241,495,244,483" shape="poly">
                    <area target="_blank" alt="اراک" title="اراک" href="ali.php" coords="449,419,462,377,449,367,421,364,377,373,363,406,378,424,373,434,362,422,348,428,338,438,345,467,337,488,338,506,355,506,363,495,374,497,377,510,392,516,403,523,461,502,468,485,457,477,444,478,432,467,415,471,407,447,413,428,437,420" shape="poly">
                    <area target="_blank" alt="فارسی" title="فارسی" href="ali.php" coords="769,241,754,266,754,284,713,287,696,308,673,309,656,314,654,334,628,356,604,360,605,375,596,389,573,395,533,382,525,382,534,403,523,422,521,447,544,459,560,457,585,471,746,469,775,467,852,373,826,343,827,302,811,295,785,287,782,260" shape="poly">
                    <area target="_blank" alt="تهران" title="تهران" href="ali.php" coords="601,372,603,356,587,349,583,357,568,347,550,359,528,355,525,342,498,336,492,342,483,353,462,355,451,366,462,377,457,396,467,400,524,421,533,407,525,384,532,376,546,387,573,394,597,388" shape="poly">
                    <area target="_blank" alt="البرز" title="البرز" href="ali.php" coords="492,334,481,324,464,317,445,314,443,320,446,331,440,344,428,350,422,356,429,365,454,369,461,355,481,354,488,342" shape="poly">
                    <area target="_blank" alt="قم" title="قم" href="ali.php" coords="523,419,460,397,449,417,415,430,410,447,416,469,431,466,445,478,468,473,473,458,522,448,525,431" shape="poly">
                    <area target="_blank" alt="اصفهان" title="اصفهان" href="ali.php" coords="748,471,584,473,564,456,542,462,521,454,472,460,467,477,472,486,402,523,398,548,368,576,382,586,384,597,407,592,420,602,452,594,464,623,480,641,474,667,481,701,474,711,505,733,517,694,508,683,534,668,544,682,584,674,587,611,609,596,645,600,707,576,726,542,742,539,746,521" shape="poly">
                    <area target="_blank" alt="لرستان" title="لرستان" href="ali.php" coords="369,572,374,566,385,554,405,531,382,514,376,495,364,496,351,507,337,502,335,485,316,479,293,477,262,452,247,464,233,479,245,484,240,493,211,506,222,531,235,532,257,561,264,584,284,558,298,560,315,557,327,564,339,564,350,576,358,577" shape="poly">
                    <area target="_blank" alt="خوزستان" title="خوزستان" href="ali.php" coords="243,624,254,614,252,602,280,557,302,559,313,557,340,563,364,577,384,589,390,625,410,653,419,669,413,681,392,695,394,714,404,724,420,742,415,759,419,777,398,771,388,779,362,795,354,783,337,781,329,771,325,787,309,788,290,788,280,766,266,752,269,714,245,708,251,678,257,654" shape="poly">
                    <area target="_blank" alt="چهارمحال بختیاری" title="چهارمحال بختیاری" href="ali.php" coords="404,638,390,623,382,601,408,591,415,596,448,593,468,611,479,638,479,667,481,693,475,706,457,712,438,693,413,678,420,667" shape="poly">
                    <area target="_blank" alt="یزد" title="یزد" href="ali.php" coords="582,670,582,652,588,638,584,610,607,598,643,599,711,575,723,540,739,538,757,569,802,600,811,623,827,638,810,657,770,673,769,712,704,722,684,739,696,770,698,792,697,804,681,805,656,795,658,775,640,748,608,685" shape="poly">
                    <area target="_blank" alt="کهکیوره و بویر احمد" title="کهکیوره و بویر احمد" href="ali.php" coords="502,731,501,743,488,751,464,742,468,763,464,775,448,779,433,781,421,777,414,760,417,739,402,730,391,698,413,682,432,688,452,710,474,701" shape="poly">
                    <area target="_blank" alt="بوشهر" title="بوشهر" href="ali.php" coords="391,778,397,770,426,776,439,805,469,810,478,832,495,841,502,864,521,894,524,917,541,933,555,970,579,993,563,1000,556,982,543,976,521,963,501,962,477,948,460,913,460,899,448,888,448,863,433,835,402,800" shape="poly">
                    <area target="_blank" alt="فارس" title="فارس" href="ali.php" coords="431,779,469,770,466,745,501,754,515,687,534,669,544,678,591,677,613,695,655,770,655,790,680,804,698,835,723,842,733,878,734,893,755,914,752,940,760,955,739,965,720,987,696,984,664,988,650,998,654,1008,640,1011,605,1002,580,993,558,971,542,933,520,916,520,890,501,864,497,845,480,833,472,808,433,804" shape="poly">
                    <area target="_blank" alt="کرمان" title="کرمان" href="ali.php" coords="685,808,696,803,701,778,689,742,701,719,770,712,770,666,811,655,823,641,986,705,1013,746,1005,805,1011,818,1010,850,1008,858,1014,888,984,907,990,923,976,999,987,1041,951,1049,934,1023,916,1029,889,1019,881,962,858,943,857,923,846,920,828,936,797,925,795,879,782,877,762,888,752,877,729,868,725,843,692,835" shape="poly">
                    <area target="_blank" alt="هرمزگان" title="هرمزگان" href="ali.php" coords="563,1000,582,989,648,1011,656,1006,654,996,703,984,725,988,732,966,761,956,752,941,756,914,734,891,735,874,760,888,781,879,796,879,796,919,825,936,846,920,856,923,856,942,881,956,887,1018,914,1026,932,1023,946,1043,985,1040,987,1097,1007,1115,1011,1137,989,1130,940,1132,922,1123,889,1115,866,1067,852,1021,826,1009,793,1009,774,1026,745,1043,710,1064,684,1055,656,1048,627,1047,620,1026,590,1021" shape="poly">
                    <area target="_blank" alt="قشم" title="قشم" href="ali.php" coords="742,1070,742,1058,774,1047,770,1035,789,1036,805,1029,816,1031,804,1037,801,1049,790,1054,779,1052" shape="poly">
                </map>
        </div>
    </div>
    
    <!-- فوتر  -->
    <div class="container-fluid pb-5" style="margin-top: 100px; background-color: #ff6b01;color: #fff;">
        <div class="container text-center">
            <div class="row">
                <div class="col-md-3 text-right pr-4 pt-5">
                    <h3><b>ارتباط با ما</b></h3>
                    <h5 style="margin-top: 40px;">درباره ما</h5>
                    <h5 style="margin-top: 40px;">همکاری باما</h5>
                    <h5 style="margin-top: 40px;">تماس باما</h5>
                </div>
                <div class="col-md-3 text-right pr-4 pt-5">
                    <h3><b>مجوز های قانونی</b></h3>
                    <h5 style="margin-top: 40px;">مجوز اقامت</h5>
                    <h5 style="margin-top: 40px;">مجوز کمپینگ</h5>
                    <h5 style="margin-top: 40px;">مجوز افراد</h5>
                </div>            
                <div class="col-md-6 pt-5 text-right">
                    <h3><b>فضای مجازی</b></h3>
                    <div class="row">
                        <div class="col-md-6  pr-5">
                            <img src="img/telk.webp" width="60px" alt="">
                            <img src="img/Instagram-Logo.png" width="80px" alt="">
                            <img src="img/bale_200_200_c1.png" width="60px" alt="">
                        </div>
                        <div class="col-md-6">
                            <img src="img/i namad a.png" width="123px" alt="">
                            <img src="img/i namad ta.png" width="123px" alt="">
                        </div>
                        <h6 class="mb-2 pb-2 mt-4" style="border-bottom: 2px #ffc107 solid;">ثبت نام درخبرنامه</h6>
                        <p>برای اطلاع از تخفیف کمپینگ پست الکتریکی خود را در باکس زیر وارد کنید</p>
                        <input type="text" class="inp-et" style="width: 400px;height: 45px;border-radius: 15px;padding: 10px;" placeholder="آدرس ایمیل">
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

<!-- کوه روز -->
<div id="mountain-day" class="content-section">

    <!-- مرحله ها -->
    <div class="container-fluid">
        <div class="row mt-4">
            <div class="col-md-1"></div>
            <!-- لیست اول (تصاویر) -->
            <ul class="col-11 col-md-10 nav navbar pb-0 d-flex justify-content-center flex-wrap mr-2">
                <li><img src="img/1b.png" width="45px" class="navbar-brand" alt=""></li>
                <li><img src="img/titib.png" width="300px" class="navbar-brand" height="25px" alt=""></li>
                <li><img src="img/2.2b.png" width="45px" class="navbar-brand" alt=""></li>
                <li><img src="img/titib.png" width="300px" class="navbar-brand" height="25px" alt=""></li>
                <li><img src="img/3.2b.png" width="45px" class="navbar-brand" alt=""></li>
                <li><img src="img/titib.png" width="300px" class="navbar-brand" height="25px" alt=""></li>
                <li><img src="img/4.2b.png" width="45px" class="navbar-brand" alt=""></li>
            </ul>
            
            <!-- لیست دوم (متن‌ها) -->
            <div class="col-md-3 pr-5 text-center">
                <h6>انتخاب محل کمپ</h6>
            </div>
            <div class="col-md-3 text-center pr-5">
                <h6>انتخاب منطقه</h6>
            </div>
            <div class="col-md-3 text-center pr-5">
                <h6>اجاره ابزارآلات</h6>
            </div>
            <div class="col-md-3 text-center pr-5">
                <h6>پرداخت</h6>
            </div>
        </div>
    </div>

    <!-- جستوجو -->
    <div class="container mt-5">
        <div class="row">
            <div class="col-sm-10 col-md-12 text-center">
                <input id="search-5" type="text" class="in-serg-b" placeholder="اسم منطقه کمپ، شهر، روستا، جنگل، کویر و ..." style="width: 100%;">
            </div>
        </div>
    </div>

    <!-- پربازدید ها -->
    <div class="container-fluid text-center p-5">
        <div class="row text-right cor-1">
            <h5>برترین های جنگل</h5>
        </div>
        <div class="row mt-4">

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1-b text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/pictures-template-2(17).jpg" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۴.۶</p>
                        <div class="col-md-12 m-0 p-0"><h6>جنگل المیستان ، <small style="font-size: 11px;color: #c6c6c6;">استان مازندران - بابل</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=mountain&time=day">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1-b text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/53b9c6469c5b76c007b96ff6.jpg" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۵.۰</p>
                        <div class="col-md-12 m-0 p-0"><h6>جنگل ابر، <small style="font-size: 11px;color: #c6c6c6;">شاهرود</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=mountain&time=day">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1-b text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/ییلاق-ماسال-1.webp" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۴.۲</p>
                        <div class="col-md-12 m-0 p-0"><h6>جنگل ییلاقات ماسال، <small style="font-size: 11px;color: #c6c6c6;">استان مازندران - گیلان</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=mountain&time=day">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1-b text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/جنگل-دالخانی.webp" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۴.۵</p>
                        <div class="col-md-12 m-0 p-0"><h6>جنگل دالخانی، <small style="font-size: 11px;color: #c6c6c6;">رامسر</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=mountain&time=day">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>
            
        </div>

        <!-- برترین های کویر -->
        <div class="row text-right cor-1 mt-4">
            <h5>برترین های کویر</h5>
        </div>
        <div class="row mt-4">

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1-b text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/The-Maranjab-Desert-ezgif.com-optiwebp.webp" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۴.۸</p>
                        <div class="col-md-12 m-0 p-0"><h6>کویر مرنجاب، <small style="font-size: 11px;color: #c6c6c6;">استان اصفهان</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=mountain&time=day">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1-b text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/loot-sh.jpg_34xzfheh.uqc.jpg" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۵.۰</p>
                        <div class="col-md-12 m-0 p-0"><h6>کویر لوت، <small style="font-size: 11px;color: #c6c6c6;">استان‌های کرمان</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=mountain&time=day">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1-b text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/Articlee14fe676-9263-4e65-920e-357d46501de9_mihmansho.jpg" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۵.۰</p>
                        <div class="col-md-12 m-0 p-0"><h6>کویر زردگاه، <small style="font-size: 11px;color: #c6c6c6;">استان خراسان جنوبی</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=mountain&time=day">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1-b text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/1195fa02-fae7-461b-944a-e76b9e1c789c.webp" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۴.۵</p>
                        <div class="col-md-12 m-0 p-0"><h6>کویر ریگ جن، <small style="font-size: 11px;color: #c6c6c6;">استان‌های سمنان</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=mountain&time=day">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>
            
        </div>

        <!-- برترین های کوهستانی -->
        <div class="row text-right cor-1 mt-4">
            <h5>برترین های کوهستانی</h5>
        </div>
        <div class="row mt-4">

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1-b text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/981012-Damavand-South-IMG_9861-2.jpg" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۴.۳</p>
                        <div class="col-md-12 m-0 p-0"><h6>کوه دماوند، <small style="font-size: 11px;color: #c6c6c6;">استان البرز</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=mountain&time=day">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1-b text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/رشته-کوه-زاگرس.jpg" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۴.۱</p>
                        <div class="col-md-12 m-0 p-0"><h6>رشته کوه زاگرس، <small style="font-size: 11px;color: #c6c6c6;">استان‌ کردستان</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=mountain&time=day">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1-b text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/114839.jpg" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۳.۲</p>
                        <div class="col-md-12 m-0 p-0"><h6>قله الوند، <small style="font-size: 11px;color: #c6c6c6;">استان همدان</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=mountain&time=day">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1-b text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/c2461595-3144-4b98-9116-d96359d4a7b1.webp" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۲.۹</p>
                        <div class="col-md-12 m-0 p-0"><h6>قلهٔ بینالود، <small style="font-size: 11px;color: #c6c6c6;">استان خراسان رضوی</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=mountain&time=day">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>
            
        </div>

            <!-- پرطرفدار ترین -->
            <div class="row text-right cor-1 mt-4">
                <h5>پرطرفدار ترین</h5>
            </div>
            <div class="row mt-4">
        
                <div class="col-md-3 col-12 mb-2">
                    <div class="container-fluid codr-1-b text-right" style="padding: 13px 30px;">
                        <div class="row">
                            <img src="img/چالوس-جاده-1.jpg" class="im-1" width="100%" height="190px" alt="">
                            <img src="img/star.gif" width="20px" height="20px" alt="">
                            <p style="font-size: 11px;" class="mt-1">۴.۶</p>
                            <div class="col-md-12 m-0 p-0"><h6>فین چالوس، <small style="font-size: 11px;color: #c6c6c6;">استان مازندران</small></h6></div>
                            <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=mountain&time=day">جزئیات و رزرو</a></div>
                        </div>
                    </div>
                </div>
        
                <div class="col-md-3 col-12 mb-2">
                    <div class="container-fluid codr-1-b text-right" style="padding: 13px 30px;">
                        <div class="row">
                            <img src="img/خارا.jpg" class="im-1" width="100%" height="190px" alt="">
                            <img src="img/star.gif" width="20px" height="20px" alt="">
                            <p style="font-size: 11px;" class="mt-1">۴.۶</p>
                            <div class="col-md-12 m-0 p-0"><h6>کویر خارا، <small style="font-size: 11px;color: #c6c6c6;">استان‌ اصفهان</small></h6></div>
                            <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=mountain&time=day">جزئیات و رزرو</a></div>
                        </div>
                    </div>
                </div>
        
                <div class="col-md-3 col-12 mb-2">
                    <div class="container-fluid codr-1-b text-right" style="padding: 13px 30px;">
                        <div class="row">
                            <img src="img/981012-Damavand-South-IMG_9861-2.jpg" class="im-1" width="100%" height="190px" alt="">
                            <img src="img/star.gif" width="20px" height="20px" alt="">
                            <p style="font-size: 11px;" class="mt-1">۴.۳</p>
                            <div class="col-md-12 m-0 p-0"><h6>کوه دماوند، <small style="font-size: 11px;color: #c6c6c6;">استان البرز</small></h6></div>
                            <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=mountain&time=day">جزئیات و رزرو</a></div>
                        </div>
                    </div>
                </div>
        
                <div class="col-md-3 col-12 mb-2">
                    <div class="container-fluid codr-1-b text-right" style="padding: 13px 30px;">
                        <div class="row">
                            <img src="img/WhatsApp_Image_2021-12-13_at_12.06.25.jpg " class="im-1" width="100%" height="190px" alt="">
                            <img src="img/star.gif" width="20px" height="20px" alt="">
                            <p style="font-size: 11px;" class="mt-1">۴.۶</p>
                            <div class="col-md-12 m-0 p-0"><h6>ساحل گیسوم ، <small style="font-size: 11px;color: #c6c6c6;">استان هرمزگان</small></h6></div>
                            <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=mountain&time=day">جزئیات و رزرو</a></div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- بالاترین نمره -->
            <div class="row text-right cor-1 mt-4">
                <h5>بالاترین نمره</h5>
            </div>
            <div class="row mt-4">
        
                <div class="col-md-3 col-12 mb-2">
                    <div class="container-fluid codr-1-b text-right" style="padding: 13px 30px;">
                        <div class="row">
                            <img src="img/53b9c6469c5b76c007b96ff6.jpg" class="im-1" width="100%" height="190px" alt="">
                            <img src="img/star.gif" width="20px" height="20px" alt="">
                            <p style="font-size: 11px;" class="mt-1">۵.۰</p>
                            <div class="col-md-12 m-0 p-0"><h6>جنگل ابر، <small style="font-size: 11px;color: #c6c6c6;">شاهرود</small></h6></div>
                            <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=mountain&time=day">جزئیات و رزرو</a></div>
                        </div>
                    </div>
                </div>
        
                <div class="col-md-3 col-12 mb-2">
                    <div class="container-fluid codr-1-b text-right" style="padding: 13px 30px;">
                        <div class="row">
                            <img src="img/Articlee14fe676-9263-4e65-920e-357d46501de9_mihmansho.jpg" class="im-1" width="100%" height="190px" alt="">
                            <img src="img/star.gif" width="20px" height="20px" alt="">
                            <p style="font-size: 11px;" class="mt-1">۵.۰</p>
                            <div class="col-md-12 m-0 p-0"><h6>کویر زردگاه، <small style="font-size: 11px;color: #c6c6c6;">استان خراسان جنوبی</small></h6></div>
                            <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=mountain&time=day">جزئیات و رزرو</a></div>
                        </div>
                    </div>
                </div>
        
                <div class="col-md-3 col-12 mb-2">
                    <div class="container-fluid codr-1-b text-right" style="padding: 13px 30px;">
                        <div class="row">
                            <img src="img/Google-Maps-11-1.jpg" class="im-1" width="100%" height="190px" alt="">
                            <img src="img/star.gif" width="20px" height="20px" alt="">
                            <p style="font-size: 11px;" class="mt-1">۵.۰</p>
                            <div class="col-md-12 m-0 p-0"><h6>جنگل راش سنگده، <small style="font-size: 11px;color: #c6c6c6;">استان مازندران</small></h6></div>
                            <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=mountain&time=day">جزئیات و رزرو</a></div>
                        </div>
                    </div>
                </div>
        
                <div class="col-md-3 col-12 mb-2">
                    <div class="container-fluid codr-1-b text-right" style="padding: 13px 30px;">
                        <div class="row">
                            <img src="img/hirkani-jungle.webp" class="im-1" width="100%" height="190px" alt="">
                            <img src="img/star.gif" width="20px" height="20px" alt="">
                            <p style="font-size: 11px;" class="mt-1">۵.۰</p>
                            <div class="col-md-12 m-0 p-0"><h6>جنگل سیاه بیشه، <small style="font-size: 11px;color: #c6c6c6;">استان مازندران</small></h6></div>
                            <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=mountain&time=day">جزئیات و رزرو</a></div>
                        </div>
                    </div>
                </div>
            </div>
    </div>

    <!-- نقشه ایران -->
    <div class="container-fluid text-center mt-5 map-desktop">
        <h2>از روی نقشه انتخاب کنید</h2>
        <div style="background-image: url(img/dayere-posht-naghshe-b.png); width: 100%;height: 1460px;">
                <img src="img/ir_map.png" usemap="#image-map">
                <map name="image-map">
                    <area target="_blank" alt="خراسان شمالی" title="خراسان شمالی" href="ali.php" coords="813,172,821,170,832,178,845,177,848,168,854,172,855,184,863,196,879,196,907,206,926,218,929,211,938,225,922,259,931,270,913,282,915,300,898,300,861,278,837,281,813,296,781,285,784,264,767,247,796,222,790,214,785,189,804,172" shape="poly">
                    <area target="_blank" alt="خراسان رضوی" title="خراسان رضوی" href="ali.php" coords="931,213,979,224,989,244,1028,254,1043,285,1092,282,1095,302,1107,360,1097,393,1093,437,1078,440,1089,454,1067,473,1068,489,1048,497,1031,484,1011,488,995,478,951,481,939,464,908,461,884,434,893,420,862,408,820,431,796,438,827,406,840,391,854,373,825,340,825,317,827,303,815,299,840,278,863,282,905,305,915,299,909,285,932,270,920,259,938,232" shape="poly">
                    <area target="_blank" alt="خراسان جنوبی" title="خراسان جنوبی" href="ali.php" coords="1067,490,1067,513,1097,519,1074,551,1096,625,1097,669,1117,676,1111,717,1117,751,1102,755,1089,736,1070,729,1014,748,991,706,827,638,811,623,804,600,763,573,740,538,746,520,749,469,774,469,793,441,857,407,893,419,885,435,902,458,938,461,952,482,992,477,1011,488,1031,483,1045,496" shape="poly">
                    <area target="_blank" alt="سیستان و بلوچستان" title="سیستان و بلوچستان" href="ali.php" coords="1117,676,1160,679,1163,719,1110,795,1144,831,1167,875,1185,890,1224,901,1228,908,1242,908,1252,966,1250,981,1279,983,1289,989,1279,1025,1234,1037,1197,1066,1183,1147,1167,1153,1115,1142,1014,1139,1007,1115,984,1100,990,1045,979,1004,986,936,993,923,983,911,1016,888,1007,863,1013,852,1013,822,1004,811,1014,748,1070,732,1092,739,1101,751,1117,748,1109,718" shape="poly">
                    <area target="_blank" alt="گلستان" title="گلستان" href="ali.php" coords="782,187,763,182,744,185,725,199,705,213,703,230,692,235,667,244,645,244,658,276,650,284,668,299,675,313,693,308,719,287,751,288,761,248,775,232,798,223,787,215" shape="poly">
                    <area target="_blank" alt="مازندران" title="مازندران" href="ali.php" coords="673,308,667,297,650,289,635,283,627,278,582,290,532,300,504,297,479,289,448,270,440,272,431,285,464,317,481,323,497,334,520,340,534,355,549,360,567,346,582,358,588,348,604,358,631,354,654,325,657,314" shape="poly">
                    <area target="_blank" alt="گیلان" title="گیلان" href="ali.php" coords="449,269,440,264,431,254,426,236,409,230,378,225,358,211,349,197,346,176,346,153,332,155,337,164,332,178,327,201,335,222,344,237,344,248,364,275,390,295,432,289,437,277" shape="poly">
                    <area target="_blank" alt="اردبیل" title="اردبیل" href="ali.php" coords="341,244,339,231,325,199,334,164,321,141,301,124,303,111,319,108,305,88,320,79,301,55,291,54,241,84,246,109,264,97,267,112,260,121,267,131,254,154,269,166,281,162,285,190,296,193,293,218,304,231,307,243,316,247,332,254" shape="poly">
                    <area target="_blank" alt="آذربایجان شرقی" title="آذربایجان شرقی" href="ali.php" coords="238,84,227,93,211,112,187,112,150,100,140,107,140,120,123,143,129,160,127,187,134,201,137,220,157,235,187,256,197,250,207,246,219,261,216,273,238,276,257,252,279,247,298,252,308,247,302,232,298,196,285,189,279,162,269,166,255,154,266,130,257,124,268,114,263,97,244,106" shape="poly">
                    <area target="_blank" alt="آذربایجان غربی" title="آذربایجان غربی" href="ali.php" coords="145,95,139,80,128,73,119,57,100,35,87,46,86,59,63,54,69,73,75,123,80,142,66,169,84,189,84,207,96,224,93,239,99,247,93,255,107,269,107,284,117,294,121,312,121,321,132,323,143,307,163,302,166,292,208,293,222,302,240,299,244,289,237,276,222,274,219,259,207,246,186,254,139,221,128,188,123,141,138,120" shape="poly">
                    <area target="_blank" alt="کردستان" title="کردستان" href="ali.php" coords="239,305,244,291,267,300,281,314,278,341,288,350,272,356,278,377,291,397,270,407,250,396,229,408,223,419,199,423,184,389,167,382,160,363,162,353,181,341,156,343,134,326,138,307,160,303,168,291,204,291,223,300" shape="poly">
                    <area target="_blank" alt="زنجان" title="زنجان" href="ali.php" coords="345,248,327,252,311,244,305,249,276,246,260,255,239,275,241,290,274,300,280,319,279,337,290,350,309,361,337,364,331,343,339,338,364,338,370,317,348,291,363,279,360,269" shape="poly">
                    <area target="_blank" alt="قزوین " title="قزوین " href="ali.php" coords="369,306,352,297,350,285,362,275,378,287,399,293,435,290,469,314,438,313,448,326,443,340,425,350,421,361,408,366,392,372,378,376,362,376,346,369,340,361,332,349,340,337,356,342,369,335,373,323" shape="poly">
                    <area target="_blank" alt="همدان" title="همدان" href="ali.php" coords="341,369,325,365,308,361,291,361,275,360,276,377,288,390,288,405,276,406,269,411,268,423,261,430,278,442,269,446,269,459,282,471,302,477,322,477,334,485,346,476,345,459,337,441,345,434,350,423,354,417,364,417,372,431,378,426,372,413,362,408,369,405,369,394,375,382,363,375" shape="poly">
                    <area target="_blank" alt="کرمانشاه " title="کرمانشاه " href="ali.php" coords="266,406,247,397,235,405,221,419,202,422,182,384,168,387,149,400,134,420,119,449,127,461,114,477,132,504,139,476,161,476,180,485,194,494,229,488,243,467,255,459,268,449,278,441,260,428" shape="poly">
                    <area target="_blank" alt="ایلام" title="ایلام" href="ali.php" coords="195,491,171,478,147,473,134,500,159,537,153,555,175,564,218,599,229,599,241,624,252,617,252,608,267,587,258,561,232,534,221,531,209,507,222,502,241,495,244,483" shape="poly">
                    <area target="_blank" alt="اراک" title="اراک" href="ali.php" coords="449,419,462,377,449,367,421,364,377,373,363,406,378,424,373,434,362,422,348,428,338,438,345,467,337,488,338,506,355,506,363,495,374,497,377,510,392,516,403,523,461,502,468,485,457,477,444,478,432,467,415,471,407,447,413,428,437,420" shape="poly">
                    <area target="_blank" alt="فارسی" title="فارسی" href="ali.php" coords="769,241,754,266,754,284,713,287,696,308,673,309,656,314,654,334,628,356,604,360,605,375,596,389,573,395,533,382,525,382,534,403,523,422,521,447,544,459,560,457,585,471,746,469,775,467,852,373,826,343,827,302,811,295,785,287,782,260" shape="poly">
                    <area target="_blank" alt="تهران" title="تهران" href="ali.php" coords="601,372,603,356,587,349,583,357,568,347,550,359,528,355,525,342,498,336,492,342,483,353,462,355,451,366,462,377,457,396,467,400,524,421,533,407,525,384,532,376,546,387,573,394,597,388" shape="poly">
                    <area target="_blank" alt="البرز" title="البرز" href="ali.php" coords="492,334,481,324,464,317,445,314,443,320,446,331,440,344,428,350,422,356,429,365,454,369,461,355,481,354,488,342" shape="poly">
                    <area target="_blank" alt="قم" title="قم" href="ali.php" coords="523,419,460,397,449,417,415,430,410,447,416,469,431,466,445,478,468,473,473,458,522,448,525,431" shape="poly">
                    <area target="_blank" alt="اصفهان" title="اصفهان" href="ali.php" coords="748,471,584,473,564,456,542,462,521,454,472,460,467,477,472,486,402,523,398,548,368,576,382,586,384,597,407,592,420,602,452,594,464,623,480,641,474,667,481,701,474,711,505,733,517,694,508,683,534,668,544,682,584,674,587,611,609,596,645,600,707,576,726,542,742,539,746,521" shape="poly">
                    <area target="_blank" alt="لرستان" title="لرستان" href="ali.php" coords="369,572,374,566,385,554,405,531,382,514,376,495,364,496,351,507,337,502,335,485,316,479,293,477,262,452,247,464,233,479,245,484,240,493,211,506,222,531,235,532,257,561,264,584,284,558,298,560,315,557,327,564,339,564,350,576,358,577" shape="poly">
                    <area target="_blank" alt="خوزستان" title="خوزستان" href="ali.php" coords="243,624,254,614,252,602,280,557,302,559,313,557,340,563,364,577,384,589,390,625,410,653,419,669,413,681,392,695,394,714,404,724,420,742,415,759,419,777,398,771,388,779,362,795,354,783,337,781,329,771,325,787,309,788,290,788,280,766,266,752,269,714,245,708,251,678,257,654" shape="poly">
                    <area target="_blank" alt="چهارمحال بختیاری" title="چهارمحال بختیاری" href="ali.php" coords="404,638,390,623,382,601,408,591,415,596,448,593,468,611,479,638,479,667,481,693,475,706,457,712,438,693,413,678,420,667" shape="poly">
                    <area target="_blank" alt="یزد" title="یزد" href="ali.php" coords="582,670,582,652,588,638,584,610,607,598,643,599,711,575,723,540,739,538,757,569,802,600,811,623,827,638,810,657,770,673,769,712,704,722,684,739,696,770,698,792,697,804,681,805,656,795,658,775,640,748,608,685" shape="poly">
                    <area target="_blank" alt="کهکیوره و بویر احمد" title="کهکیوره و بویر احمد" href="ali.php" coords="502,731,501,743,488,751,464,742,468,763,464,775,448,779,433,781,421,777,414,760,417,739,402,730,391,698,413,682,432,688,452,710,474,701" shape="poly">
                    <area target="_blank" alt="بوشهر" title="بوشهر" href="ali.php" coords="391,778,397,770,426,776,439,805,469,810,478,832,495,841,502,864,521,894,524,917,541,933,555,970,579,993,563,1000,556,982,543,976,521,963,501,962,477,948,460,913,460,899,448,888,448,863,433,835,402,800" shape="poly">
                    <area target="_blank" alt="فارس" title="فارس" href="ali.php" coords="431,779,469,770,466,745,501,754,515,687,534,669,544,678,591,677,613,695,655,770,655,790,680,804,698,835,723,842,733,878,734,893,755,914,752,940,760,955,739,965,720,987,696,984,664,988,650,998,654,1008,640,1011,605,1002,580,993,558,971,542,933,520,916,520,890,501,864,497,845,480,833,472,808,433,804" shape="poly">
                    <area target="_blank" alt="کرمان" title="کرمان" href="ali.php" coords="685,808,696,803,701,778,689,742,701,719,770,712,770,666,811,655,823,641,986,705,1013,746,1005,805,1011,818,1010,850,1008,858,1014,888,984,907,990,923,976,999,987,1041,951,1049,934,1023,916,1029,889,1019,881,962,858,943,857,923,846,920,828,936,797,925,795,879,782,877,762,888,752,877,729,868,725,843,692,835" shape="poly">
                    <area target="_blank" alt="هرمزگان" title="هرمزگان" href="ali.php" coords="563,1000,582,989,648,1011,656,1006,654,996,703,984,725,988,732,966,761,956,752,941,756,914,734,891,735,874,760,888,781,879,796,879,796,919,825,936,846,920,856,923,856,942,881,956,887,1018,914,1026,932,1023,946,1043,985,1040,987,1097,1007,1115,1011,1137,989,1130,940,1132,922,1123,889,1115,866,1067,852,1021,826,1009,793,1009,774,1026,745,1043,710,1064,684,1055,656,1048,627,1047,620,1026,590,1021" shape="poly">
                    <area target="_blank" alt="قشم" title="قشم" href="ali.php" coords="742,1070,742,1058,774,1047,770,1035,789,1036,805,1029,816,1031,804,1037,801,1049,790,1054,779,1052" shape="poly">
                </map>
        </div>
    </div>
    <!-- نقشه ایران -->
    <div class="container-fluid text-center mt-5 map-mobile">
        <h5>از روی نقشه انتخاب کنید</h5>
        <div style="background-image: url(img/dayere-posht-naghshe-b.png); width: 100px;height: 500px;">
                <img src="img/ir_map.png" usemap="#image-map" style="width: 400px;">
                <map name="image-map">
                    <area target="_blank" alt="خراسان شمالی" title="خراسان شمالی" href="ali.php" coords="813,172,821,170,832,178,845,177,848,168,854,172,855,184,863,196,879,196,907,206,926,218,929,211,938,225,922,259,931,270,913,282,915,300,898,300,861,278,837,281,813,296,781,285,784,264,767,247,796,222,790,214,785,189,804,172" shape="poly">
                    <area target="_blank" alt="خراسان رضوی" title="خراسان رضوی" href="ali.php" coords="931,213,979,224,989,244,1028,254,1043,285,1092,282,1095,302,1107,360,1097,393,1093,437,1078,440,1089,454,1067,473,1068,489,1048,497,1031,484,1011,488,995,478,951,481,939,464,908,461,884,434,893,420,862,408,820,431,796,438,827,406,840,391,854,373,825,340,825,317,827,303,815,299,840,278,863,282,905,305,915,299,909,285,932,270,920,259,938,232" shape="poly">
                    <area target="_blank" alt="خراسان جنوبی" title="خراسان جنوبی" href="ali.php" coords="1067,490,1067,513,1097,519,1074,551,1096,625,1097,669,1117,676,1111,717,1117,751,1102,755,1089,736,1070,729,1014,748,991,706,827,638,811,623,804,600,763,573,740,538,746,520,749,469,774,469,793,441,857,407,893,419,885,435,902,458,938,461,952,482,992,477,1011,488,1031,483,1045,496" shape="poly">
                    <area target="_blank" alt="سیستان و بلوچستان" title="سیستان و بلوچستان" href="ali.php" coords="1117,676,1160,679,1163,719,1110,795,1144,831,1167,875,1185,890,1224,901,1228,908,1242,908,1252,966,1250,981,1279,983,1289,989,1279,1025,1234,1037,1197,1066,1183,1147,1167,1153,1115,1142,1014,1139,1007,1115,984,1100,990,1045,979,1004,986,936,993,923,983,911,1016,888,1007,863,1013,852,1013,822,1004,811,1014,748,1070,732,1092,739,1101,751,1117,748,1109,718" shape="poly">
                    <area target="_blank" alt="گلستان" title="گلستان" href="ali.php" coords="782,187,763,182,744,185,725,199,705,213,703,230,692,235,667,244,645,244,658,276,650,284,668,299,675,313,693,308,719,287,751,288,761,248,775,232,798,223,787,215" shape="poly">
                    <area target="_blank" alt="مازندران" title="مازندران" href="ali.php" coords="673,308,667,297,650,289,635,283,627,278,582,290,532,300,504,297,479,289,448,270,440,272,431,285,464,317,481,323,497,334,520,340,534,355,549,360,567,346,582,358,588,348,604,358,631,354,654,325,657,314" shape="poly">
                    <area target="_blank" alt="گیلان" title="گیلان" href="ali.php" coords="449,269,440,264,431,254,426,236,409,230,378,225,358,211,349,197,346,176,346,153,332,155,337,164,332,178,327,201,335,222,344,237,344,248,364,275,390,295,432,289,437,277" shape="poly">
                    <area target="_blank" alt="اردبیل" title="اردبیل" href="ali.php" coords="341,244,339,231,325,199,334,164,321,141,301,124,303,111,319,108,305,88,320,79,301,55,291,54,241,84,246,109,264,97,267,112,260,121,267,131,254,154,269,166,281,162,285,190,296,193,293,218,304,231,307,243,316,247,332,254" shape="poly">
                    <area target="_blank" alt="آذربایجان شرقی" title="آذربایجان شرقی" href="ali.php" coords="238,84,227,93,211,112,187,112,150,100,140,107,140,120,123,143,129,160,127,187,134,201,137,220,157,235,187,256,197,250,207,246,219,261,216,273,238,276,257,252,279,247,298,252,308,247,302,232,298,196,285,189,279,162,269,166,255,154,266,130,257,124,268,114,263,97,244,106" shape="poly">
                    <area target="_blank" alt="آذربایجان غربی" title="آذربایجان غربی" href="ali.php" coords="145,95,139,80,128,73,119,57,100,35,87,46,86,59,63,54,69,73,75,123,80,142,66,169,84,189,84,207,96,224,93,239,99,247,93,255,107,269,107,284,117,294,121,312,121,321,132,323,143,307,163,302,166,292,208,293,222,302,240,299,244,289,237,276,222,274,219,259,207,246,186,254,139,221,128,188,123,141,138,120" shape="poly">
                    <area target="_blank" alt="کردستان" title="کردستان" href="ali.php" coords="239,305,244,291,267,300,281,314,278,341,288,350,272,356,278,377,291,397,270,407,250,396,229,408,223,419,199,423,184,389,167,382,160,363,162,353,181,341,156,343,134,326,138,307,160,303,168,291,204,291,223,300" shape="poly">
                    <area target="_blank" alt="زنجان" title="زنجان" href="ali.php" coords="345,248,327,252,311,244,305,249,276,246,260,255,239,275,241,290,274,300,280,319,279,337,290,350,309,361,337,364,331,343,339,338,364,338,370,317,348,291,363,279,360,269" shape="poly">
                    <area target="_blank" alt="قزوین " title="قزوین " href="ali.php" coords="369,306,352,297,350,285,362,275,378,287,399,293,435,290,469,314,438,313,448,326,443,340,425,350,421,361,408,366,392,372,378,376,362,376,346,369,340,361,332,349,340,337,356,342,369,335,373,323" shape="poly">
                    <area target="_blank" alt="همدان" title="همدان" href="ali.php" coords="341,369,325,365,308,361,291,361,275,360,276,377,288,390,288,405,276,406,269,411,268,423,261,430,278,442,269,446,269,459,282,471,302,477,322,477,334,485,346,476,345,459,337,441,345,434,350,423,354,417,364,417,372,431,378,426,372,413,362,408,369,405,369,394,375,382,363,375" shape="poly">
                    <area target="_blank" alt="کرمانشاه " title="کرمانشاه " href="ali.php" coords="266,406,247,397,235,405,221,419,202,422,182,384,168,387,149,400,134,420,119,449,127,461,114,477,132,504,139,476,161,476,180,485,194,494,229,488,243,467,255,459,268,449,278,441,260,428" shape="poly">
                    <area target="_blank" alt="ایلام" title="ایلام" href="ali.php" coords="195,491,171,478,147,473,134,500,159,537,153,555,175,564,218,599,229,599,241,624,252,617,252,608,267,587,258,561,232,534,221,531,209,507,222,502,241,495,244,483" shape="poly">
                    <area target="_blank" alt="اراک" title="اراک" href="ali.php" coords="449,419,462,377,449,367,421,364,377,373,363,406,378,424,373,434,362,422,348,428,338,438,345,467,337,488,338,506,355,506,363,495,374,497,377,510,392,516,403,523,461,502,468,485,457,477,444,478,432,467,415,471,407,447,413,428,437,420" shape="poly">
                    <area target="_blank" alt="فارسی" title="فارسی" href="ali.php" coords="769,241,754,266,754,284,713,287,696,308,673,309,656,314,654,334,628,356,604,360,605,375,596,389,573,395,533,382,525,382,534,403,523,422,521,447,544,459,560,457,585,471,746,469,775,467,852,373,826,343,827,302,811,295,785,287,782,260" shape="poly">
                    <area target="_blank" alt="تهران" title="تهران" href="ali.php" coords="601,372,603,356,587,349,583,357,568,347,550,359,528,355,525,342,498,336,492,342,483,353,462,355,451,366,462,377,457,396,467,400,524,421,533,407,525,384,532,376,546,387,573,394,597,388" shape="poly">
                    <area target="_blank" alt="البرز" title="البرز" href="ali.php" coords="492,334,481,324,464,317,445,314,443,320,446,331,440,344,428,350,422,356,429,365,454,369,461,355,481,354,488,342" shape="poly">
                    <area target="_blank" alt="قم" title="قم" href="ali.php" coords="523,419,460,397,449,417,415,430,410,447,416,469,431,466,445,478,468,473,473,458,522,448,525,431" shape="poly">
                    <area target="_blank" alt="اصفهان" title="اصفهان" href="ali.php" coords="748,471,584,473,564,456,542,462,521,454,472,460,467,477,472,486,402,523,398,548,368,576,382,586,384,597,407,592,420,602,452,594,464,623,480,641,474,667,481,701,474,711,505,733,517,694,508,683,534,668,544,682,584,674,587,611,609,596,645,600,707,576,726,542,742,539,746,521" shape="poly">
                    <area target="_blank" alt="لرستان" title="لرستان" href="ali.php" coords="369,572,374,566,385,554,405,531,382,514,376,495,364,496,351,507,337,502,335,485,316,479,293,477,262,452,247,464,233,479,245,484,240,493,211,506,222,531,235,532,257,561,264,584,284,558,298,560,315,557,327,564,339,564,350,576,358,577" shape="poly">
                    <area target="_blank" alt="خوزستان" title="خوزستان" href="ali.php" coords="243,624,254,614,252,602,280,557,302,559,313,557,340,563,364,577,384,589,390,625,410,653,419,669,413,681,392,695,394,714,404,724,420,742,415,759,419,777,398,771,388,779,362,795,354,783,337,781,329,771,325,787,309,788,290,788,280,766,266,752,269,714,245,708,251,678,257,654" shape="poly">
                    <area target="_blank" alt="چهارمحال بختیاری" title="چهارمحال بختیاری" href="ali.php" coords="404,638,390,623,382,601,408,591,415,596,448,593,468,611,479,638,479,667,481,693,475,706,457,712,438,693,413,678,420,667" shape="poly">
                    <area target="_blank" alt="یزد" title="یزد" href="ali.php" coords="582,670,582,652,588,638,584,610,607,598,643,599,711,575,723,540,739,538,757,569,802,600,811,623,827,638,810,657,770,673,769,712,704,722,684,739,696,770,698,792,697,804,681,805,656,795,658,775,640,748,608,685" shape="poly">
                    <area target="_blank" alt="کهکیوره و بویر احمد" title="کهکیوره و بویر احمد" href="ali.php" coords="502,731,501,743,488,751,464,742,468,763,464,775,448,779,433,781,421,777,414,760,417,739,402,730,391,698,413,682,432,688,452,710,474,701" shape="poly">
                    <area target="_blank" alt="بوشهر" title="بوشهر" href="ali.php" coords="391,778,397,770,426,776,439,805,469,810,478,832,495,841,502,864,521,894,524,917,541,933,555,970,579,993,563,1000,556,982,543,976,521,963,501,962,477,948,460,913,460,899,448,888,448,863,433,835,402,800" shape="poly">
                    <area target="_blank" alt="فارس" title="فارس" href="ali.php" coords="431,779,469,770,466,745,501,754,515,687,534,669,544,678,591,677,613,695,655,770,655,790,680,804,698,835,723,842,733,878,734,893,755,914,752,940,760,955,739,965,720,987,696,984,664,988,650,998,654,1008,640,1011,605,1002,580,993,558,971,542,933,520,916,520,890,501,864,497,845,480,833,472,808,433,804" shape="poly">
                    <area target="_blank" alt="کرمان" title="کرمان" href="ali.php" coords="685,808,696,803,701,778,689,742,701,719,770,712,770,666,811,655,823,641,986,705,1013,746,1005,805,1011,818,1010,850,1008,858,1014,888,984,907,990,923,976,999,987,1041,951,1049,934,1023,916,1029,889,1019,881,962,858,943,857,923,846,920,828,936,797,925,795,879,782,877,762,888,752,877,729,868,725,843,692,835" shape="poly">
                    <area target="_blank" alt="هرمزگان" title="هرمزگان" href="ali.php" coords="563,1000,582,989,648,1011,656,1006,654,996,703,984,725,988,732,966,761,956,752,941,756,914,734,891,735,874,760,888,781,879,796,879,796,919,825,936,846,920,856,923,856,942,881,956,887,1018,914,1026,932,1023,946,1043,985,1040,987,1097,1007,1115,1011,1137,989,1130,940,1132,922,1123,889,1115,866,1067,852,1021,826,1009,793,1009,774,1026,745,1043,710,1064,684,1055,656,1048,627,1047,620,1026,590,1021" shape="poly">
                    <area target="_blank" alt="قشم" title="قشم" href="ali.php" coords="742,1070,742,1058,774,1047,770,1035,789,1036,805,1029,816,1031,804,1037,801,1049,790,1054,779,1052" shape="poly">
                </map>
        </div>
    </div>
    
    <!-- فوتر  -->
    <div class="container-fluid pb-5" style="margin-top: 100px; background-color: #365ee2;color: #fff;">
        <div class="container text-center">
            <div class="row">
                <div class="col-md-3 text-right pr-4 pt-5">
                    <h3><b>ارتباط با ما</b></h3>
                    <h5 style="margin-top: 40px;">درباره ما</h5>
                    <h5 style="margin-top: 40px;">همکاری باما</h5>
                    <h5 style="margin-top: 40px;">تماس باما</h5>
                </div>
                <div class="col-md-3 text-right pr-4 pt-5">
                    <h3><b>مجوز های قانونی</b></h3>
                    <h5 style="margin-top: 40px;">مجوز اقامت</h5>
                    <h5 style="margin-top: 40px;">مجوز کمپینگ</h5>
                    <h5 style="margin-top: 40px;">مجوز افراد</h5>
                </div>            
                <div class="col-md-6 pt-5 text-right">
                    <h3><b>فضای مجازی</b></h3>
                    <div class="row">
                        <div class="col-md-6  pr-5">
                            <img src="img/telk.webp" width="60px" alt="">
                            <img src="img/Instagram-Logo.png" width="80px" alt="">
                            <img src="img/bale_200_200_c1.png" width="60px" alt="">
                        </div>
                        <div class="col-md-6">
                            <img src="img/i namad a.png" width="123px" alt="">
                            <img src="img/i namad ta.png" width="123px" alt="">
                        </div>
                        <h6 class="mb-2 pb-2 mt-4" style="border-bottom: 2px #ffc107 solid;">ثبت نام درخبرنامه</h6>
                        <p>برای اطلاع از تخفیف کمپینگ پست الکتریکی خود را در باکس زیر وارد کنید</p>
                        <input type="text" class="inp-et" style="width: 400px;height: 45px;border-radius: 15px;padding: 10px;" placeholder="آدرس ایمیل">
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

<!-- کوه شب -->
<div id="mountain-night" class="content-section">

    <!-- مرحله ها -->
    <div class="container-fluid">
        <div class="row mt-4">
            <div class="col-md-1"></div>
            <!-- لیست اول (تصاویر) -->
            <ul class="col-11 col-md-10 nav navbar pb-0 d-flex justify-content-center flex-wrap mr-2">
                <li><img src="img/1b.png" width="45px" class="navbar-brand" alt=""></li>
                <li><img src="img/titib.png" width="300px" class="navbar-brand" height="25px" alt=""></li>
                <li><img src="img/2.2b.png" width="45px" class="navbar-brand" alt=""></li>
                <li><img src="img/titib.png" width="300px" class="navbar-brand" height="25px" alt=""></li>
                <li><img src="img/3.2b.png" width="45px" class="navbar-brand" alt=""></li>
                <li><img src="img/titib.png" width="300px" class="navbar-brand" height="25px" alt=""></li>
                <li><img src="img/4.2b.png" width="45px" class="navbar-brand" alt=""></li>
            </ul>
            
            <!-- لیست دوم (متن‌ها) -->
            <div class="col-md-3 pr-5 text-center text-light">
                <h6>انتخاب محل کمپ</h6>
            </div>
            <div class="col-md-3 text-center pr-5 text-light">
                <h6>انتخاب منطقه</h6>
            </div>
            <div class="col-md-3 text-center pr-5 text-light">
                <h6>اجاره ابزارآلات</h6>
            </div>
            <div class="col-md-3 text-center pr-5 text-light">
                <h6>پرداخت</h6>
            </div>
        </div>
    </div>

    <!-- جستوجو -->
    <div class="container mt-5">
        <div class="row">
            <div class="col-sm-10 col-md-12 text-center">
                <input id="search-6" type="text" class="in-serg-b" placeholder="اسم منطقه کمپ، شهر، روستا، جنگل، کویر و ..." style="width: 100%;">
            </div>
        </div>
    </div>

    <!-- پربازدید ها -->
    <div class="container-fluid text-center p-5">
        <div class="row text-right cor-1">
            <h5>برترین های جنگل</h5>
        </div>
        <div class="row mt-4">

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1-b text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/pictures-template-2(17).jpg" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۴.۶</p>
                        <div class="col-md-12 m-0 p-0"><h6>جنگل المیستان ، <small style="font-size: 11px;color: #c6c6c6;">استان مازندران - بابل</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=mountain&time=night">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1-b text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/53b9c6469c5b76c007b96ff6.jpg" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۵.۰</p>
                        <div class="col-md-12 m-0 p-0"><h6>جنگل ابر، <small style="font-size: 11px;color: #c6c6c6;">شاهرود</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=mountain&time=night">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1-b text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/ییلاق-ماسال-1.webp" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۴.۲</p>
                        <div class="col-md-12 m-0 p-0"><h6>جنگل ییلاقات ماسال، <small style="font-size: 11px;color: #c6c6c6;">استان مازندران - گیلان</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=mountain&time=night">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1-b text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/جنگل-دالخانی.webp" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۴.۵</p>
                        <div class="col-md-12 m-0 p-0"><h6>جنگل دالخانی، <small style="font-size: 11px;color: #c6c6c6;">رامسر</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=mountain&time=night">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>
            
        </div>

        <!-- برترین های کویر -->
        <div class="row text-right cor-1 mt-4">
            <h5>برترین های کویر</h5>
        </div>
        <div class="row mt-4">

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1-b text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/The-Maranjab-Desert-ezgif.com-optiwebp.webp" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۴.۸</p>
                        <div class="col-md-12 m-0 p-0"><h6>کویر مرنجاب، <small style="font-size: 11px;color: #c6c6c6;">استان اصفهان</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=mountain&time=night">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1-b text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/loot-sh.jpg_34xzfheh.uqc.jpg" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۵.۰</p>
                        <div class="col-md-12 m-0 p-0"><h6>کویر لوت، <small style="font-size: 11px;color: #c6c6c6;">استان‌های کرمان</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=mountain&time=night">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1-b text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/Articlee14fe676-9263-4e65-920e-357d46501de9_mihmansho.jpg" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۵.۰</p>
                        <div class="col-md-12 m-0 p-0"><h6>کویر زردگاه، <small style="font-size: 11px;color: #c6c6c6;">استان خراسان جنوبی</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=mountain&time=night">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1-b text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/1195fa02-fae7-461b-944a-e76b9e1c789c.webp" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۴.۵</p>
                        <div class="col-md-12 m-0 p-0"><h6>کویر ریگ جن، <small style="font-size: 11px;color: #c6c6c6;">استان‌های سمنان</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=mountain&time=night">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>
            
        </div>

        <!-- برترین های کوهستانی -->
        <div class="row text-right cor-1 mt-4">
            <h5>برترین های کوهستانی</h5>
        </div>
        <div class="row mt-4">

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1-b text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/981012-Damavand-South-IMG_9861-2.jpg" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۴.۳</p>
                        <div class="col-md-12 m-0 p-0"><h6>کوه دماوند، <small style="font-size: 11px;color: #c6c6c6;">استان البرز</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=mountain&time=night">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1-b text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/رشته-کوه-زاگرس.jpg" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۴.۱</p>
                        <div class="col-md-12 m-0 p-0"><h6>رشته کوه زاگرس، <small style="font-size: 11px;color: #c6c6c6;">استان‌ کردستان</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=mountain&time=night">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1-b text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/114839.jpg" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۳.۲</p>
                        <div class="col-md-12 m-0 p-0"><h6>قله الوند، <small style="font-size: 11px;color: #c6c6c6;">استان همدان</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=mountain&time=night">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-12 mb-2">
                <div class="container-fluid codr-1-b text-right" style="padding: 13px 30px;">
                    <div class="row">
                        <img src="img/c2461595-3144-4b98-9116-d96359d4a7b1.webp" class="im-1" width="100%" height="190px" alt="">
                        <img src="img/star.gif" width="20px" height="20px" alt="">
                        <p style="font-size: 11px;" class="mt-1">۲.۹</p>
                        <div class="col-md-12 m-0 p-0"><h6>قلهٔ بینالود، <small style="font-size: 11px;color: #c6c6c6;">استان خراسان رضوی</small></h6></div>
                        <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=mountain&time=night">جزئیات و رزرو</a></div>
                    </div>
                </div>
            </div>
            
        </div>

            <!-- پرطرفدار ترین -->
            <div class="row text-right cor-1 mt-4">
                <h5>پرطرفدار ترین</h5>
            </div>
            <div class="row mt-4">
        
                <div class="col-md-3 col-12 mb-2">
                    <div class="container-fluid codr-1-b text-right" style="padding: 13px 30px;">
                        <div class="row">
                            <img src="img/چالوس-جاده-1.jpg" class="im-1" width="100%" height="190px" alt="">
                            <img src="img/star.gif" width="20px" height="20px" alt="">
                            <p style="font-size: 11px;" class="mt-1">۴.۶</p>
                            <div class="col-md-12 m-0 p-0"><h6>فین چالوس، <small style="font-size: 11px;color: #c6c6c6;">استان مازندران</small></h6></div>
                            <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=mountain&time=night">جزئیات و رزرو</a></div>
                        </div>
                    </div>
                </div>
        
                <div class="col-md-3 col-12 mb-2">
                    <div class="container-fluid codr-1-b text-right" style="padding: 13px 30px;">
                        <div class="row">
                            <img src="img/خارا.jpg" class="im-1" width="100%" height="190px" alt="">
                            <img src="img/star.gif" width="20px" height="20px" alt="">
                            <p style="font-size: 11px;" class="mt-1">۴.۶</p>
                            <div class="col-md-12 m-0 p-0"><h6>کویر خارا، <small style="font-size: 11px;color: #c6c6c6;">استان‌ اصفهان</small></h6></div>
                            <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=mountain&time=night">جزئیات و رزرو</a></div>
                        </div>
                    </div>
                </div>
        
                <div class="col-md-3 col-12 mb-2">
                    <div class="container-fluid codr-1-b text-right" style="padding: 13px 30px;">
                        <div class="row">
                            <img src="img/981012-Damavand-South-IMG_9861-2.jpg" class="im-1" width="100%" height="190px" alt="">
                            <img src="img/star.gif" width="20px" height="20px" alt="">
                            <p style="font-size: 11px;" class="mt-1">۴.۳</p>
                            <div class="col-md-12 m-0 p-0"><h6>کوه دماوند، <small style="font-size: 11px;color: #c6c6c6;">استان البرز</small></h6></div>
                            <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=mountain&time=night">جزئیات و رزرو</a></div>
                        </div>
                    </div>
                </div>
        
                <div class="col-md-3 col-12 mb-2">
                    <div class="container-fluid codr-1-b text-right" style="padding: 13px 30px;">
                        <div class="row">
                            <img src="img/WhatsApp_Image_2021-12-13_at_12.06.25.jpg " class="im-1" width="100%" height="190px" alt="">
                            <img src="img/star.gif" width="20px" height="20px" alt="">
                            <p style="font-size: 11px;" class="mt-1">۴.۶</p>
                            <div class="col-md-12 m-0 p-0"><h6>ساحل گیسوم ، <small style="font-size: 11px;color: #c6c6c6;">استان هرمزگان</small></h6></div>
                            <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=mountain&time=night">جزئیات و رزرو</a></div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- بالاترین نمره -->
            <div class="row text-right cor-1 mt-4">
                <h5>بالاترین نمره</h5>
            </div>
            <div class="row mt-4">
        
                <div class="col-md-3 col-12 mb-2">
                    <div class="container-fluid codr-1-b text-right" style="padding: 13px 30px;">
                        <div class="row">
                            <img src="img/53b9c6469c5b76c007b96ff6.jpg" class="im-1" width="100%" height="190px" alt="">
                            <img src="img/star.gif" width="20px" height="20px" alt="">
                            <p style="font-size: 11px;" class="mt-1">۵.۰</p>
                            <div class="col-md-12 m-0 p-0"><h6>جنگل ابر، <small style="font-size: 11px;color: #c6c6c6;">شاهرود</small></h6></div>
                            <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=mountain&time=night">جزئیات و رزرو</a></div>
                        </div>
                    </div>
                </div>
        
                <div class="col-md-3 col-12 mb-2">
                    <div class="container-fluid codr-1-b text-right" style="padding: 13px 30px;">
                        <div class="row">
                            <img src="img/Articlee14fe676-9263-4e65-920e-357d46501de9_mihmansho.jpg" class="im-1" width="100%" height="190px" alt="">
                            <img src="img/star.gif" width="20px" height="20px" alt="">
                            <p style="font-size: 11px;" class="mt-1">۵.۰</p>
                            <div class="col-md-12 m-0 p-0"><h6>کویر زردگاه، <small style="font-size: 11px;color: #c6c6c6;">استان خراسان جنوبی</small></h6></div>
                            <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=mountain&time=night">جزئیات و رزرو</a></div>
                        </div>
                    </div>
                </div>
        
                <div class="col-md-3 col-12 mb-2">
                    <div class="container-fluid codr-1-b text-right" style="padding: 13px 30px;">
                        <div class="row">
                            <img src="img/Google-Maps-11-1.jpg" class="im-1" width="100%" height="190px" alt="">
                            <img src="img/star.gif" width="20px" height="20px" alt="">
                            <p style="font-size: 11px;" class="mt-1">۵.۰</p>
                            <div class="col-md-12 m-0 p-0"><h6>جنگل راش سنگده، <small style="font-size: 11px;color: #c6c6c6;">استان مازندران</small></h6></div>
                            <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=mountain&time=night">جزئیات و رزرو</a></div>
                        </div>
                    </div>
                </div>
        
                <div class="col-md-3 col-12 mb-2">
                    <div class="container-fluid codr-1-b text-right" style="padding: 13px 30px;">
                        <div class="row">
                            <img src="img/hirkani-jungle.webp" class="im-1" width="100%" height="190px" alt="">
                            <img src="img/star.gif" width="20px" height="20px" alt="">
                            <p style="font-size: 11px;" class="mt-1">۵.۰</p>
                            <div class="col-md-12 m-0 p-0"><h6>جنگل سیاه بیشه، <small style="font-size: 11px;color: #c6c6c6;">استان مازندران</small></h6></div>
                            <div class="col-md-12 btn btn-primary" style="font-family: YekanLight;font-size: 12px;"><a href="mantagi.php?item=mountain&time=night">جزئیات و رزرو</a></div>
                        </div>
                    </div>
                </div>
            </div>
    </div>

    <!-- نقشه ایران -->
    <div class="container-fluid text-center mt-5 map-desktop">
        <h2>از روی نقشه انتخاب کنید</h2>
        <div style="background-image: url(img/dayere-posht-naghshe-b.png); width: 100%;height: 1460px;">
                <img src="img/ir_map.png" usemap="#image-map">
                <map name="image-map">
                    <area target="_blank" alt="خراسان شمالی" title="خراسان شمالی" href="ali.php" coords="813,172,821,170,832,178,845,177,848,168,854,172,855,184,863,196,879,196,907,206,926,218,929,211,938,225,922,259,931,270,913,282,915,300,898,300,861,278,837,281,813,296,781,285,784,264,767,247,796,222,790,214,785,189,804,172" shape="poly">
                    <area target="_blank" alt="خراسان رضوی" title="خراسان رضوی" href="ali.php" coords="931,213,979,224,989,244,1028,254,1043,285,1092,282,1095,302,1107,360,1097,393,1093,437,1078,440,1089,454,1067,473,1068,489,1048,497,1031,484,1011,488,995,478,951,481,939,464,908,461,884,434,893,420,862,408,820,431,796,438,827,406,840,391,854,373,825,340,825,317,827,303,815,299,840,278,863,282,905,305,915,299,909,285,932,270,920,259,938,232" shape="poly">
                    <area target="_blank" alt="خراسان جنوبی" title="خراسان جنوبی" href="ali.php" coords="1067,490,1067,513,1097,519,1074,551,1096,625,1097,669,1117,676,1111,717,1117,751,1102,755,1089,736,1070,729,1014,748,991,706,827,638,811,623,804,600,763,573,740,538,746,520,749,469,774,469,793,441,857,407,893,419,885,435,902,458,938,461,952,482,992,477,1011,488,1031,483,1045,496" shape="poly">
                    <area target="_blank" alt="سیستان و بلوچستان" title="سیستان و بلوچستان" href="ali.php" coords="1117,676,1160,679,1163,719,1110,795,1144,831,1167,875,1185,890,1224,901,1228,908,1242,908,1252,966,1250,981,1279,983,1289,989,1279,1025,1234,1037,1197,1066,1183,1147,1167,1153,1115,1142,1014,1139,1007,1115,984,1100,990,1045,979,1004,986,936,993,923,983,911,1016,888,1007,863,1013,852,1013,822,1004,811,1014,748,1070,732,1092,739,1101,751,1117,748,1109,718" shape="poly">
                    <area target="_blank" alt="گلستان" title="گلستان" href="ali.php" coords="782,187,763,182,744,185,725,199,705,213,703,230,692,235,667,244,645,244,658,276,650,284,668,299,675,313,693,308,719,287,751,288,761,248,775,232,798,223,787,215" shape="poly">
                    <area target="_blank" alt="مازندران" title="مازندران" href="ali.php" coords="673,308,667,297,650,289,635,283,627,278,582,290,532,300,504,297,479,289,448,270,440,272,431,285,464,317,481,323,497,334,520,340,534,355,549,360,567,346,582,358,588,348,604,358,631,354,654,325,657,314" shape="poly">
                    <area target="_blank" alt="گیلان" title="گیلان" href="ali.php" coords="449,269,440,264,431,254,426,236,409,230,378,225,358,211,349,197,346,176,346,153,332,155,337,164,332,178,327,201,335,222,344,237,344,248,364,275,390,295,432,289,437,277" shape="poly">
                    <area target="_blank" alt="اردبیل" title="اردبیل" href="ali.php" coords="341,244,339,231,325,199,334,164,321,141,301,124,303,111,319,108,305,88,320,79,301,55,291,54,241,84,246,109,264,97,267,112,260,121,267,131,254,154,269,166,281,162,285,190,296,193,293,218,304,231,307,243,316,247,332,254" shape="poly">
                    <area target="_blank" alt="آذربایجان شرقی" title="آذربایجان شرقی" href="ali.php" coords="238,84,227,93,211,112,187,112,150,100,140,107,140,120,123,143,129,160,127,187,134,201,137,220,157,235,187,256,197,250,207,246,219,261,216,273,238,276,257,252,279,247,298,252,308,247,302,232,298,196,285,189,279,162,269,166,255,154,266,130,257,124,268,114,263,97,244,106" shape="poly">
                    <area target="_blank" alt="آذربایجان غربی" title="آذربایجان غربی" href="ali.php" coords="145,95,139,80,128,73,119,57,100,35,87,46,86,59,63,54,69,73,75,123,80,142,66,169,84,189,84,207,96,224,93,239,99,247,93,255,107,269,107,284,117,294,121,312,121,321,132,323,143,307,163,302,166,292,208,293,222,302,240,299,244,289,237,276,222,274,219,259,207,246,186,254,139,221,128,188,123,141,138,120" shape="poly">
                    <area target="_blank" alt="کردستان" title="کردستان" href="ali.php" coords="239,305,244,291,267,300,281,314,278,341,288,350,272,356,278,377,291,397,270,407,250,396,229,408,223,419,199,423,184,389,167,382,160,363,162,353,181,341,156,343,134,326,138,307,160,303,168,291,204,291,223,300" shape="poly">
                    <area target="_blank" alt="زنجان" title="زنجان" href="ali.php" coords="345,248,327,252,311,244,305,249,276,246,260,255,239,275,241,290,274,300,280,319,279,337,290,350,309,361,337,364,331,343,339,338,364,338,370,317,348,291,363,279,360,269" shape="poly">
                    <area target="_blank" alt="قزوین " title="قزوین " href="ali.php" coords="369,306,352,297,350,285,362,275,378,287,399,293,435,290,469,314,438,313,448,326,443,340,425,350,421,361,408,366,392,372,378,376,362,376,346,369,340,361,332,349,340,337,356,342,369,335,373,323" shape="poly">
                    <area target="_blank" alt="همدان" title="همدان" href="ali.php" coords="341,369,325,365,308,361,291,361,275,360,276,377,288,390,288,405,276,406,269,411,268,423,261,430,278,442,269,446,269,459,282,471,302,477,322,477,334,485,346,476,345,459,337,441,345,434,350,423,354,417,364,417,372,431,378,426,372,413,362,408,369,405,369,394,375,382,363,375" shape="poly">
                    <area target="_blank" alt="کرمانشاه " title="کرمانشاه " href="ali.php" coords="266,406,247,397,235,405,221,419,202,422,182,384,168,387,149,400,134,420,119,449,127,461,114,477,132,504,139,476,161,476,180,485,194,494,229,488,243,467,255,459,268,449,278,441,260,428" shape="poly">
                    <area target="_blank" alt="ایلام" title="ایلام" href="ali.php" coords="195,491,171,478,147,473,134,500,159,537,153,555,175,564,218,599,229,599,241,624,252,617,252,608,267,587,258,561,232,534,221,531,209,507,222,502,241,495,244,483" shape="poly">
                    <area target="_blank" alt="اراک" title="اراک" href="ali.php" coords="449,419,462,377,449,367,421,364,377,373,363,406,378,424,373,434,362,422,348,428,338,438,345,467,337,488,338,506,355,506,363,495,374,497,377,510,392,516,403,523,461,502,468,485,457,477,444,478,432,467,415,471,407,447,413,428,437,420" shape="poly">
                    <area target="_blank" alt="فارسی" title="فارسی" href="ali.php" coords="769,241,754,266,754,284,713,287,696,308,673,309,656,314,654,334,628,356,604,360,605,375,596,389,573,395,533,382,525,382,534,403,523,422,521,447,544,459,560,457,585,471,746,469,775,467,852,373,826,343,827,302,811,295,785,287,782,260" shape="poly">
                    <area target="_blank" alt="تهران" title="تهران" href="ali.php" coords="601,372,603,356,587,349,583,357,568,347,550,359,528,355,525,342,498,336,492,342,483,353,462,355,451,366,462,377,457,396,467,400,524,421,533,407,525,384,532,376,546,387,573,394,597,388" shape="poly">
                    <area target="_blank" alt="البرز" title="البرز" href="ali.php" coords="492,334,481,324,464,317,445,314,443,320,446,331,440,344,428,350,422,356,429,365,454,369,461,355,481,354,488,342" shape="poly">
                    <area target="_blank" alt="قم" title="قم" href="ali.php" coords="523,419,460,397,449,417,415,430,410,447,416,469,431,466,445,478,468,473,473,458,522,448,525,431" shape="poly">
                    <area target="_blank" alt="اصفهان" title="اصفهان" href="ali.php" coords="748,471,584,473,564,456,542,462,521,454,472,460,467,477,472,486,402,523,398,548,368,576,382,586,384,597,407,592,420,602,452,594,464,623,480,641,474,667,481,701,474,711,505,733,517,694,508,683,534,668,544,682,584,674,587,611,609,596,645,600,707,576,726,542,742,539,746,521" shape="poly">
                    <area target="_blank" alt="لرستان" title="لرستان" href="ali.php" coords="369,572,374,566,385,554,405,531,382,514,376,495,364,496,351,507,337,502,335,485,316,479,293,477,262,452,247,464,233,479,245,484,240,493,211,506,222,531,235,532,257,561,264,584,284,558,298,560,315,557,327,564,339,564,350,576,358,577" shape="poly">
                    <area target="_blank" alt="خوزستان" title="خوزستان" href="ali.php" coords="243,624,254,614,252,602,280,557,302,559,313,557,340,563,364,577,384,589,390,625,410,653,419,669,413,681,392,695,394,714,404,724,420,742,415,759,419,777,398,771,388,779,362,795,354,783,337,781,329,771,325,787,309,788,290,788,280,766,266,752,269,714,245,708,251,678,257,654" shape="poly">
                    <area target="_blank" alt="چهارمحال بختیاری" title="چهارمحال بختیاری" href="ali.php" coords="404,638,390,623,382,601,408,591,415,596,448,593,468,611,479,638,479,667,481,693,475,706,457,712,438,693,413,678,420,667" shape="poly">
                    <area target="_blank" alt="یزد" title="یزد" href="ali.php" coords="582,670,582,652,588,638,584,610,607,598,643,599,711,575,723,540,739,538,757,569,802,600,811,623,827,638,810,657,770,673,769,712,704,722,684,739,696,770,698,792,697,804,681,805,656,795,658,775,640,748,608,685" shape="poly">
                    <area target="_blank" alt="کهکیوره و بویر احمد" title="کهکیوره و بویر احمد" href="ali.php" coords="502,731,501,743,488,751,464,742,468,763,464,775,448,779,433,781,421,777,414,760,417,739,402,730,391,698,413,682,432,688,452,710,474,701" shape="poly">
                    <area target="_blank" alt="بوشهر" title="بوشهر" href="ali.php" coords="391,778,397,770,426,776,439,805,469,810,478,832,495,841,502,864,521,894,524,917,541,933,555,970,579,993,563,1000,556,982,543,976,521,963,501,962,477,948,460,913,460,899,448,888,448,863,433,835,402,800" shape="poly">
                    <area target="_blank" alt="فارس" title="فارس" href="ali.php" coords="431,779,469,770,466,745,501,754,515,687,534,669,544,678,591,677,613,695,655,770,655,790,680,804,698,835,723,842,733,878,734,893,755,914,752,940,760,955,739,965,720,987,696,984,664,988,650,998,654,1008,640,1011,605,1002,580,993,558,971,542,933,520,916,520,890,501,864,497,845,480,833,472,808,433,804" shape="poly">
                    <area target="_blank" alt="کرمان" title="کرمان" href="ali.php" coords="685,808,696,803,701,778,689,742,701,719,770,712,770,666,811,655,823,641,986,705,1013,746,1005,805,1011,818,1010,850,1008,858,1014,888,984,907,990,923,976,999,987,1041,951,1049,934,1023,916,1029,889,1019,881,962,858,943,857,923,846,920,828,936,797,925,795,879,782,877,762,888,752,877,729,868,725,843,692,835" shape="poly">
                    <area target="_blank" alt="هرمزگان" title="هرمزگان" href="ali.php" coords="563,1000,582,989,648,1011,656,1006,654,996,703,984,725,988,732,966,761,956,752,941,756,914,734,891,735,874,760,888,781,879,796,879,796,919,825,936,846,920,856,923,856,942,881,956,887,1018,914,1026,932,1023,946,1043,985,1040,987,1097,1007,1115,1011,1137,989,1130,940,1132,922,1123,889,1115,866,1067,852,1021,826,1009,793,1009,774,1026,745,1043,710,1064,684,1055,656,1048,627,1047,620,1026,590,1021" shape="poly">
                    <area target="_blank" alt="قشم" title="قشم" href="ali.php" coords="742,1070,742,1058,774,1047,770,1035,789,1036,805,1029,816,1031,804,1037,801,1049,790,1054,779,1052" shape="poly">
                </map>
        </div>
    </div>
    <!-- نقشه ایران -->
    <div class="container-fluid text-center mt-5 map-mobile">
        <h5>از روی نقشه انتخاب کنید</h5>
        <div style="background-image: url(img/dayere-posht-naghshe-b.png); width: 100px;height: 500px;">
                <img src="img/ir_map.png" usemap="#image-map" style="width: 400px;">
                <map name="image-map">
                    <area target="_blank" alt="خراسان شمالی" title="خراسان شمالی" href="ali.php" coords="813,172,821,170,832,178,845,177,848,168,854,172,855,184,863,196,879,196,907,206,926,218,929,211,938,225,922,259,931,270,913,282,915,300,898,300,861,278,837,281,813,296,781,285,784,264,767,247,796,222,790,214,785,189,804,172" shape="poly">
                    <area target="_blank" alt="خراسان رضوی" title="خراسان رضوی" href="ali.php" coords="931,213,979,224,989,244,1028,254,1043,285,1092,282,1095,302,1107,360,1097,393,1093,437,1078,440,1089,454,1067,473,1068,489,1048,497,1031,484,1011,488,995,478,951,481,939,464,908,461,884,434,893,420,862,408,820,431,796,438,827,406,840,391,854,373,825,340,825,317,827,303,815,299,840,278,863,282,905,305,915,299,909,285,932,270,920,259,938,232" shape="poly">
                    <area target="_blank" alt="خراسان جنوبی" title="خراسان جنوبی" href="ali.php" coords="1067,490,1067,513,1097,519,1074,551,1096,625,1097,669,1117,676,1111,717,1117,751,1102,755,1089,736,1070,729,1014,748,991,706,827,638,811,623,804,600,763,573,740,538,746,520,749,469,774,469,793,441,857,407,893,419,885,435,902,458,938,461,952,482,992,477,1011,488,1031,483,1045,496" shape="poly">
                    <area target="_blank" alt="سیستان و بلوچستان" title="سیستان و بلوچستان" href="ali.php" coords="1117,676,1160,679,1163,719,1110,795,1144,831,1167,875,1185,890,1224,901,1228,908,1242,908,1252,966,1250,981,1279,983,1289,989,1279,1025,1234,1037,1197,1066,1183,1147,1167,1153,1115,1142,1014,1139,1007,1115,984,1100,990,1045,979,1004,986,936,993,923,983,911,1016,888,1007,863,1013,852,1013,822,1004,811,1014,748,1070,732,1092,739,1101,751,1117,748,1109,718" shape="poly">
                    <area target="_blank" alt="گلستان" title="گلستان" href="ali.php" coords="782,187,763,182,744,185,725,199,705,213,703,230,692,235,667,244,645,244,658,276,650,284,668,299,675,313,693,308,719,287,751,288,761,248,775,232,798,223,787,215" shape="poly">
                    <area target="_blank" alt="مازندران" title="مازندران" href="ali.php" coords="673,308,667,297,650,289,635,283,627,278,582,290,532,300,504,297,479,289,448,270,440,272,431,285,464,317,481,323,497,334,520,340,534,355,549,360,567,346,582,358,588,348,604,358,631,354,654,325,657,314" shape="poly">
                    <area target="_blank" alt="گیلان" title="گیلان" href="ali.php" coords="449,269,440,264,431,254,426,236,409,230,378,225,358,211,349,197,346,176,346,153,332,155,337,164,332,178,327,201,335,222,344,237,344,248,364,275,390,295,432,289,437,277" shape="poly">
                    <area target="_blank" alt="اردبیل" title="اردبیل" href="ali.php" coords="341,244,339,231,325,199,334,164,321,141,301,124,303,111,319,108,305,88,320,79,301,55,291,54,241,84,246,109,264,97,267,112,260,121,267,131,254,154,269,166,281,162,285,190,296,193,293,218,304,231,307,243,316,247,332,254" shape="poly">
                    <area target="_blank" alt="آذربایجان شرقی" title="آذربایجان شرقی" href="ali.php" coords="238,84,227,93,211,112,187,112,150,100,140,107,140,120,123,143,129,160,127,187,134,201,137,220,157,235,187,256,197,250,207,246,219,261,216,273,238,276,257,252,279,247,298,252,308,247,302,232,298,196,285,189,279,162,269,166,255,154,266,130,257,124,268,114,263,97,244,106" shape="poly">
                    <area target="_blank" alt="آذربایجان غربی" title="آذربایجان غربی" href="ali.php" coords="145,95,139,80,128,73,119,57,100,35,87,46,86,59,63,54,69,73,75,123,80,142,66,169,84,189,84,207,96,224,93,239,99,247,93,255,107,269,107,284,117,294,121,312,121,321,132,323,143,307,163,302,166,292,208,293,222,302,240,299,244,289,237,276,222,274,219,259,207,246,186,254,139,221,128,188,123,141,138,120" shape="poly">
                    <area target="_blank" alt="کردستان" title="کردستان" href="ali.php" coords="239,305,244,291,267,300,281,314,278,341,288,350,272,356,278,377,291,397,270,407,250,396,229,408,223,419,199,423,184,389,167,382,160,363,162,353,181,341,156,343,134,326,138,307,160,303,168,291,204,291,223,300" shape="poly">
                    <area target="_blank" alt="زنجان" title="زنجان" href="ali.php" coords="345,248,327,252,311,244,305,249,276,246,260,255,239,275,241,290,274,300,280,319,279,337,290,350,309,361,337,364,331,343,339,338,364,338,370,317,348,291,363,279,360,269" shape="poly">
                    <area target="_blank" alt="قزوین " title="قزوین " href="ali.php" coords="369,306,352,297,350,285,362,275,378,287,399,293,435,290,469,314,438,313,448,326,443,340,425,350,421,361,408,366,392,372,378,376,362,376,346,369,340,361,332,349,340,337,356,342,369,335,373,323" shape="poly">
                    <area target="_blank" alt="همدان" title="همدان" href="ali.php" coords="341,369,325,365,308,361,291,361,275,360,276,377,288,390,288,405,276,406,269,411,268,423,261,430,278,442,269,446,269,459,282,471,302,477,322,477,334,485,346,476,345,459,337,441,345,434,350,423,354,417,364,417,372,431,378,426,372,413,362,408,369,405,369,394,375,382,363,375" shape="poly">
                    <area target="_blank" alt="کرمانشاه " title="کرمانشاه " href="ali.php" coords="266,406,247,397,235,405,221,419,202,422,182,384,168,387,149,400,134,420,119,449,127,461,114,477,132,504,139,476,161,476,180,485,194,494,229,488,243,467,255,459,268,449,278,441,260,428" shape="poly">
                    <area target="_blank" alt="ایلام" title="ایلام" href="ali.php" coords="195,491,171,478,147,473,134,500,159,537,153,555,175,564,218,599,229,599,241,624,252,617,252,608,267,587,258,561,232,534,221,531,209,507,222,502,241,495,244,483" shape="poly">
                    <area target="_blank" alt="اراک" title="اراک" href="ali.php" coords="449,419,462,377,449,367,421,364,377,373,363,406,378,424,373,434,362,422,348,428,338,438,345,467,337,488,338,506,355,506,363,495,374,497,377,510,392,516,403,523,461,502,468,485,457,477,444,478,432,467,415,471,407,447,413,428,437,420" shape="poly">
                    <area target="_blank" alt="فارسی" title="فارسی" href="ali.php" coords="769,241,754,266,754,284,713,287,696,308,673,309,656,314,654,334,628,356,604,360,605,375,596,389,573,395,533,382,525,382,534,403,523,422,521,447,544,459,560,457,585,471,746,469,775,467,852,373,826,343,827,302,811,295,785,287,782,260" shape="poly">
                    <area target="_blank" alt="تهران" title="تهران" href="ali.php" coords="601,372,603,356,587,349,583,357,568,347,550,359,528,355,525,342,498,336,492,342,483,353,462,355,451,366,462,377,457,396,467,400,524,421,533,407,525,384,532,376,546,387,573,394,597,388" shape="poly">
                    <area target="_blank" alt="البرز" title="البرز" href="ali.php" coords="492,334,481,324,464,317,445,314,443,320,446,331,440,344,428,350,422,356,429,365,454,369,461,355,481,354,488,342" shape="poly">
                    <area target="_blank" alt="قم" title="قم" href="ali.php" coords="523,419,460,397,449,417,415,430,410,447,416,469,431,466,445,478,468,473,473,458,522,448,525,431" shape="poly">
                    <area target="_blank" alt="اصفهان" title="اصفهان" href="ali.php" coords="748,471,584,473,564,456,542,462,521,454,472,460,467,477,472,486,402,523,398,548,368,576,382,586,384,597,407,592,420,602,452,594,464,623,480,641,474,667,481,701,474,711,505,733,517,694,508,683,534,668,544,682,584,674,587,611,609,596,645,600,707,576,726,542,742,539,746,521" shape="poly">
                    <area target="_blank" alt="لرستان" title="لرستان" href="ali.php" coords="369,572,374,566,385,554,405,531,382,514,376,495,364,496,351,507,337,502,335,485,316,479,293,477,262,452,247,464,233,479,245,484,240,493,211,506,222,531,235,532,257,561,264,584,284,558,298,560,315,557,327,564,339,564,350,576,358,577" shape="poly">
                    <area target="_blank" alt="خوزستان" title="خوزستان" href="ali.php" coords="243,624,254,614,252,602,280,557,302,559,313,557,340,563,364,577,384,589,390,625,410,653,419,669,413,681,392,695,394,714,404,724,420,742,415,759,419,777,398,771,388,779,362,795,354,783,337,781,329,771,325,787,309,788,290,788,280,766,266,752,269,714,245,708,251,678,257,654" shape="poly">
                    <area target="_blank" alt="چهارمحال بختیاری" title="چهارمحال بختیاری" href="ali.php" coords="404,638,390,623,382,601,408,591,415,596,448,593,468,611,479,638,479,667,481,693,475,706,457,712,438,693,413,678,420,667" shape="poly">
                    <area target="_blank" alt="یزد" title="یزد" href="ali.php" coords="582,670,582,652,588,638,584,610,607,598,643,599,711,575,723,540,739,538,757,569,802,600,811,623,827,638,810,657,770,673,769,712,704,722,684,739,696,770,698,792,697,804,681,805,656,795,658,775,640,748,608,685" shape="poly">
                    <area target="_blank" alt="کهکیوره و بویر احمد" title="کهکیوره و بویر احمد" href="ali.php" coords="502,731,501,743,488,751,464,742,468,763,464,775,448,779,433,781,421,777,414,760,417,739,402,730,391,698,413,682,432,688,452,710,474,701" shape="poly">
                    <area target="_blank" alt="بوشهر" title="بوشهر" href="ali.php" coords="391,778,397,770,426,776,439,805,469,810,478,832,495,841,502,864,521,894,524,917,541,933,555,970,579,993,563,1000,556,982,543,976,521,963,501,962,477,948,460,913,460,899,448,888,448,863,433,835,402,800" shape="poly">
                    <area target="_blank" alt="فارس" title="فارس" href="ali.php" coords="431,779,469,770,466,745,501,754,515,687,534,669,544,678,591,677,613,695,655,770,655,790,680,804,698,835,723,842,733,878,734,893,755,914,752,940,760,955,739,965,720,987,696,984,664,988,650,998,654,1008,640,1011,605,1002,580,993,558,971,542,933,520,916,520,890,501,864,497,845,480,833,472,808,433,804" shape="poly">
                    <area target="_blank" alt="کرمان" title="کرمان" href="ali.php" coords="685,808,696,803,701,778,689,742,701,719,770,712,770,666,811,655,823,641,986,705,1013,746,1005,805,1011,818,1010,850,1008,858,1014,888,984,907,990,923,976,999,987,1041,951,1049,934,1023,916,1029,889,1019,881,962,858,943,857,923,846,920,828,936,797,925,795,879,782,877,762,888,752,877,729,868,725,843,692,835" shape="poly">
                    <area target="_blank" alt="هرمزگان" title="هرمزگان" href="ali.php" coords="563,1000,582,989,648,1011,656,1006,654,996,703,984,725,988,732,966,761,956,752,941,756,914,734,891,735,874,760,888,781,879,796,879,796,919,825,936,846,920,856,923,856,942,881,956,887,1018,914,1026,932,1023,946,1043,985,1040,987,1097,1007,1115,1011,1137,989,1130,940,1132,922,1123,889,1115,866,1067,852,1021,826,1009,793,1009,774,1026,745,1043,710,1064,684,1055,656,1048,627,1047,620,1026,590,1021" shape="poly">
                    <area target="_blank" alt="قشم" title="قشم" href="ali.php" coords="742,1070,742,1058,774,1047,770,1035,789,1036,805,1029,816,1031,804,1037,801,1049,790,1054,779,1052" shape="poly">
                </map>
        </div>
    </div>
    
    <!-- فوتر  -->
    <div class="container-fluid pb-5" style="margin-top: 100px; background-color: #365ee2;color: #fff;">
        <div class="container text-center">
            <div class="row">
                <div class="col-md-3 text-right pr-4 pt-5">
                    <h3><b>ارتباط با ما</b></h3>
                    <h5 style="margin-top: 40px;">درباره ما</h5>
                    <h5 style="margin-top: 40px;">همکاری باما</h5>
                    <h5 style="margin-top: 40px;">تماس باما</h5>
                </div>
                <div class="col-md-3 text-right pr-4 pt-5">
                    <h3><b>مجوز های قانونی</b></h3>
                    <h5 style="margin-top: 40px;">مجوز اقامت</h5>
                    <h5 style="margin-top: 40px;">مجوز کمپینگ</h5>
                    <h5 style="margin-top: 40px;">مجوز افراد</h5>
                </div>            
                <div class="col-md-6 pt-5 text-right">
                    <h3><b>فضای مجازی</b></h3>
                    <div class="row">
                        <div class="col-md-6  pr-5">
                            <img src="img/telk.webp" width="60px" alt="">
                            <img src="img/Instagram-Logo.png" width="80px" alt="">
                            <img src="img/bale_200_200_c1.png" width="60px" alt="">
                        </div>
                        <div class="col-md-6">
                            <img src="img/i namad a.png" width="123px" alt="">
                            <img src="img/i namad ta.png" width="123px" alt="">
                        </div>
                        <h6 class="mb-2 pb-2 mt-4" style="border-bottom: 2px #ffc107 solid;">ثبت نام درخبرنامه</h6>
                        <p>برای اطلاع از تخفیف کمپینگ پست الکتریکی خود را در باکس زیر وارد کنید</p>
                        <input type="text" class="inp-et" style="width: 400px;height: 45px;border-radius: 15px;padding: 10px;" placeholder="آدرس ایمیل">
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

</body>
<script>
     // بررسی URL برای گرفتن پارامتر مربوط به دکمه‌ای که کلیک شده
     window.onload = function() {
            const params = new URLSearchParams(window.location.search);  // گرفتن پارامترهای URL

            // گرفتن پارامتر مربوط به دکمه انتخابی (درخت، کاکتوث، یا کوه)
            const item = params.get('item');  
            const time = params.get('time');  // زمان (روز یا شب)

            // مخفی کردن همه بخش‌ها ابتدا
            document.querySelectorAll('.content-section').forEach((section) => {
                section.style.display = 'none';
            });

            // تغییر پس‌زمینه به رنگ شب در صورت انتخاب شب
            if (time === 'night') {
                document.body.style.backgroundColor = '#1b213b'; // تغییر پس‌زمینه به رنگ شب
            }

            // نمایش اطلاعات خاص بر اساس پارامترهای گرفته شده
            if (item && time) {
                const elementId = `${item}-${time}`;  // ترکیب دکمه و زمان (مثلا tree-day)
                const selectedElement = document.getElementById(elementId);
                if (selectedElement) {
                    selectedElement.style.display = 'block';
                }
            }
        };    

        // ورود و ثبت نام
    var modal = document.getElementById('id01');
    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }

    function ali_baba_vorod(op)
    {
        let x='';
        if(op == 'sabt')
        {
            x='<form action="" method="post"><h4 style="margin-top: 70px;">ثبت نام</h4><h6 class="text-right mt-3" style="margin-right: 80px;" required>تلفن همراه:</h6><input type="phone" name="phone" id="phone" class="in-pha in-ba-im text-right mt-0" placeholder="09123456789" required><h6 class="text-right mt-3" style="margin-right: 80px;" required>رمز دلخواه:</h6><input type="password" id="password" name="password" class="in-pha in-ba-im text-right mt-0"><h6 class="text-right mt-3" style="margin-right: 80px;">تکرار رمز عبور:</h6><input type="text" class="in-pha in-ba-im text-right mt-0"><input type="submit" name="acoontss" id="acoontss" class="btn btn-success mt-3" style="width: 170px;" value="ورود به پنل کاربری"></form>'
            document.getElementById('bendaz').innerHTML=x;
        }
    }

    // 
    // منوی همبرگری
    function toggleNav() {
        document.getElementById("mySidenav").style.width = "250px";
        document.getElementById("overlay").classList.add("show");
    }

    function closeNav() {
        document.getElementById("mySidenav").style.width = "0";
        document.getElementById("overlay").classList.remove("show");
    }
    //     
    // 
    // <!-- اسکریپت جست‌وجو پیشرفته -->

    
    $(document).ready(function () {
    const $cards = $(".col-md-3");

    // پیام "هیچ کمپی پیدا نشد"
    const $noResult = $('<div id="noResult" class="w-100 text-center mt-4" style="display:none;"><p>هیچ کمپی پیدا نشد 😢</p></div>');
    $cards.parent().append($noResult);

    // تابع جستجو برای هر ورودی
    function searchCards(input) {
        let value = input.val().trim().toLowerCase();
        let matchCount = 0;

        // بررسی برای تمام کارت‌ها
        $cards.each(function () {
            let text = $(this).text().toLowerCase();
            if (text.includes(value)) {
                $(this).show();
                matchCount++;
            } else {
                $(this).hide();
            }
        });

        // نمایش پیام "هیچ کمپی پیدا نشد"
        if (matchCount === 0 && value !== "") {
            $noResult.show();
        } else {
            $noResult.hide();
        }
    }

    // ایجاد یک آرایه از تمامی اینپوت‌ها
    const searchInputs = [
        $('#search-1'),
        $('#search-2'),
        $('#search-3'),
        $('#search-4'),
        $('#search-5'),
        $('#search-6')
    ];

    // برای هر اینپوت در آرایه، جستجو رو فعال کن
    searchInputs.forEach(function ($input) {
        // فعال‌سازی جستجو هنگام تایپ
        $input.on("input", function () { searchCards($input); });

        // فعال‌سازی Enter برای هر اینپوت
        $input.on("keypress", function (e) {
            if (e.which === 13) {
                e.preventDefault();  // جلوگیری از رفتار پیش‌فرض
                searchCards($input);
            }
        });
    });
});    
//    
// فارسی کردن عدد
function convertNumbersToPersian() {
    const persianNumbers = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
    document.querySelectorAll('.persian-number').forEach(el => {
        el.innerHTML = el.innerHTML.replace(/\d/g, d => persianNumbers[d]);
    });
}

// وقتی صفحه لود شد اعداد فارسی شوند
document.addEventListener("DOMContentLoaded", convertNumbersToPersian);     

// 
</script>
</html>